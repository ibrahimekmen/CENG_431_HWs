package menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import assembly.Assembled;
import assembly.Product;
import fileIO.JSONIO;
import idgenerator.ProductIDGenerator;
import idgenerator.UserPasswordGenerator;
import users.Admin;
import users.Employee;
import users.Manager;
import users.User;
import workplaces.Office;

public class MainMenu {

	
	private static List<User> users = new ArrayList<User>();
	private static List<Product> products = new ArrayList<Product>();
	
	private static User currentUser;
	
	private static void readChanges() {
		products = JSONIO.readProducts();
		users = JSONIO.readUsers();
		Office.checkAssembly(products);
	}
	
	public static void mainMenu() {
		
		int mainMenuChoice;
		while (true) {
			readChanges();
			System.out.println("Welcome to Iztech Factory app");
			System.out.println("1) Login");
			System.out.println("0 to EXIT the app");
			mainMenuChoice = getInput(1);
			if (mainMenuChoice == 0) {
				System.exit(0);
			} else if (mainMenuChoice == 1) {
				currentUser = loginMenu();
				menuChooser();
			} 
		}
		
	}
	
	public static void menuChooser() {
		if (currentUser instanceof Admin) {
			adminMenu();
		} else if (currentUser instanceof Manager) {
			managerMenu();
		} else if (currentUser instanceof Employee) {
			employeeMenu();
		}
	}
	
	
	private static void employeeMenu() {
		int employeeMenuChoice;
		while (true) {
			System.out.println("1) See the details of the part you are working on.");
			System.out.println("2) Work on your part");
			System.out.println("0 to save changes and LOG OUT");
			employeeMenuChoice = getInput(2);
			if (employeeMenuChoice == 0) {
				logout();
				break;
			} else if (employeeMenuChoice == 1) {
				currentUser.getProduct().showProductDetails(0);
				currentUser.getProduct().printStatus();
			} else if (employeeMenuChoice == 2) {
				currentUser.getProduct().nextState();
			} 
		}
		
	}

	private static void adminMenu() {
		int adminMenuChoice;
		
		while (true) {
			System.out.println("1) Add a new manager and its product");
			System.out.println("2) See all the managers and their product");
			System.out.println("3) See all the employees and their part");
			System.out.println("0 to save changes and LOG OUT");
			adminMenuChoice = getInput(3);
			if (adminMenuChoice == 0) {
				logout();
				break;
			} else if (adminMenuChoice == 1) {
				addManagerMenu();
			} else if (adminMenuChoice == 2) {
				Office.displayManagers(users);
			} else if (adminMenuChoice == 3) {
				Office.displayEmployees(users);
			} 
		}
		
	}
	
	private static void managerMenu() {
		int managerMenuChoice;
		
		while (true) {
			System.out.println("1) Choose the sub parts of your product and assign roles to employees");
			System.out.println("2) See all your employees and their product");
			System.out.println("0 to save changes and LOG OUT");
			managerMenuChoice = getInput(2);
			if (managerMenuChoice == 0) {
				logout();
				break;
			}else if(managerMenuChoice == 1) {
				Office.planTheProduct((Manager) currentUser,users,products);
			}else if(managerMenuChoice == 2) {
				Office.displayEmployeesForManager(users,currentUser);
			}
		}
		
	}

	private static void addManagerMenu() {
		String managerName;
		String productName;
		
		System.out.println("Enter the name of the manager.");
		managerName = getStringInput();
		User newManager = new Manager(managerName,UserPasswordGenerator.generatePassword());
		
		System.out.println("Enter the name of the product you want the manager to work on.");
		productName = getStringInput();
		Product newProduct = new Assembled(productName,ProductIDGenerator.generateID(),null,0);
		newManager.setProduct(newProduct);
		newManager.getProduct();
		
		users.add(newManager);
		products.add(newProduct);
	}

	

	public static User loginMenu() {
		String email;
		String password;
		
		boolean correctEmail = false;
		boolean correctPassword = false;
		
		while (true) {
			System.out.println("Enter Your Email: ");
			email = getStringInput();
			System.out.println("Enter Your Password: ");
			password = getStringInput();
			for (int i = 0; i < users.size(); i++) {
				correctEmail = false;
				correctPassword = false;
				if (users.get(i).getEmail().equals(email)) {
					correctEmail = true;
					if (users.get(i).getPassword().equals(password)) {
						correctPassword = true;
						System.out.println("SUCCESSFULLY LOGGED IN !");
						System.out.println("-----------------------");
						return users.get(i);
					}
					else break;
				}

			}
			if (correctEmail && !correctPassword) {
				System.out.println("Your password is incorrect!");
			} else if (!correctEmail) {
				System.out.println("We couldn't find an email matching: " + email);
			}
		}
	}
	
	private static int getInput(int upperLimit) {
		Scanner sc = new Scanner(System.in);
		int userChoice;
		while (true) {
			while (!sc.hasNextInt()) {
				System.out.println("Please enter an integer");
				sc.next();
			}
			userChoice = sc.nextInt();
			if (userChoice < 0 || userChoice > upperLimit) {
				System.out.println("Enter a valid choice!");
			}else 
				break;
		}
		
		return userChoice;
	}
	
	private static String getStringInput() {
		String userInput;
		Scanner sc = new Scanner(System.in);
		userInput = sc.nextLine();
		return userInput;
	}
	
	private static void logout() {
		JSONIO.writeUsers(users);
		JSONIO.writeProducts(products);
	}
	
}
