package fileIO;

import java.util.ArrayList;
import java.util.List;

import assembly.Assembled;
import assembly.CompleteProduct;
import assembly.InProgressProduct;
import assembly.NotStartedProduct;
import assembly.Part;
import assembly.Product;
import idgenerator.ProductIDGenerator;
import users.Admin;
import users.Employee;
import users.Manager;
import users.User;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSONIO {
	
	private static List<Product> productListArr = new ArrayList<Product>();
	private static JSONObject childParts = new JSONObject();
	
	private static JSONObject managerEmployees = new JSONObject();
	private static List<User> usersArr = new ArrayList<User>();
	
	
	@SuppressWarnings("unchecked")
	public static void writeProducts(List<Product> products) {
			
		JSONArray allProducts = new JSONArray();
		for (int i = 0; i < products.size(); i++) {
			JSONObject product = new JSONObject();
			JSONArray childParts = new JSONArray();
			JSONObject productObject = new JSONObject();
			product.put("name", products.get(i).getTitle());
			product.put("id", products.get(i).getId());
			product.put("height", products.get(i).getHeight());
			if(products.get(i).getState() instanceof NotStartedProduct) {
				product.put("state", "Not started");
			}else if(products.get(i).getState() instanceof InProgressProduct) {
				product.put("state", "In progress");
			}else if(products.get(i).getState() instanceof CompleteProduct) {
				product.put("state", "Complete");
			}
			
			if(products.get(i).getParent() == null) {
				product.put("parent", "null");
			}else{
				product.put("parent",products.get(i).getParent().getTitle());
			}
			Part tempPart;
			if(products.get(i) instanceof Part) {
				tempPart = (Part) products.get(i);
				product.put("maker", tempPart.getMaker().getName());
			}else if(products.get(i) instanceof Assembled) {
				Assembled temp = (Assembled) products.get(i);
				for (int j = 0; j < temp.getChildProducts().size(); j++) {
					JSONObject tempParts = new JSONObject();
					tempParts.put("childPartName", temp.getChildProducts().get(j).getTitle());
					childParts.add(tempParts);
				}
				product.put("childParts",childParts);
			}
			productObject.put("product", product);
			allProducts.add(productObject);
		}		
		
		try (FileWriter file = new FileWriter("products.json")) {
		    JSONArray sortedList = new JSONArray();
            long maxHeight = -1;
            for (int i = 0; i < allProducts.size(); i++) {
            	JSONObject temp = (JSONObject) ((JSONObject) allProducts.get(i)).get("product");
				if(((long )temp.get("height")) >= maxHeight ) {
					maxHeight = ((long )temp.get("height"));
				}
			}
            for (int i = 0; i <= maxHeight; i++) {
            	  for (int j = 0; j < allProducts.size(); j++) {
                  	  JSONObject tempObject = new JSONObject();
            		  JSONObject temp = (JSONObject) ((JSONObject) allProducts.get(j)).get("product");
            		  if(i == (long) temp.get("height")) {
            			  tempObject.put("product", temp);
            			  sortedList.add(tempObject);
            		  }
            	  }
			}
            if(maxHeight != 0) {
            	allProducts = sortedList;
            }
	        file.write(allProducts.toJSONString()); 
	        file.flush();
	    }catch (IOException e) {
	    	e.printStackTrace();
	    }
		productListArr.clear();
		usersArr.clear();
		childParts.clear();
		managerEmployees.clear();
	}
	
	@SuppressWarnings("unchecked")
	public static void writeUsers(List<User> users) {

		JSONArray userList = new JSONArray();
		
		for (int i = 0; i < users.size(); i++) {
			JSONObject user = new JSONObject();
			JSONArray employees = new JSONArray();
			JSONObject userObject = new JSONObject();
			user.put("name", users.get(i).getName());
			user.put("password", users.get(i).getPassword());
			if(users.get(i) instanceof Admin) {
				user.put("type", "Admin");
			}else if(users.get(i) instanceof Manager) {
				user.put("worksOn", users.get(i).getProduct().getTitle());
				user.put("type", "Manager");

				Manager tempManager = (Manager) users.get(i);
				for (int j = 0; j < tempManager.getEmployees().size(); j++) {
					JSONObject newEmployee = new JSONObject();
					newEmployee.put("managerEmployee", tempManager.getEmployees().get(j).getName());
					employees.add(newEmployee);
				}
				user.put("employees",employees);
			}else if(users.get(i) instanceof Employee) {
				Employee tempEmployee = (Employee) users.get(i);
				user.put("worksOn", users.get(i).getProduct().getTitle());
				user.put("type", "Employee");
				user.put("employeeOf", tempEmployee.getBoss().getName());
			}
			userObject.put("user", user);
			userList.add(userObject);
		}
		try (FileWriter file = new FileWriter("users.json")) {
	        file.write(userList.toJSONString()); 
	        file.flush();
	    }catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	
	
	
	@SuppressWarnings("unchecked")
	public static List<Product> readProducts(){
		JSONParser jsonParser = new JSONParser();
		try (FileReader reader = new FileReader("products.json"))
        {
            Object obj = jsonParser.parse(reader);
 
            JSONArray productList = (JSONArray) obj;
        
            System.out.println(productList);
            
            
            productList.forEach( product -> parseProductObject((JSONObject) product ));
            for (int i = 0; i < productListArr.size(); i++) {
            	JSONArray childHelper = new JSONArray();
            	JSONObject childObject = new JSONObject();
                Assembled temp;
            	if(childParts.containsKey(productListArr.get(i).getTitle())) {
            		temp = (Assembled) productListArr.get(i);
            		childHelper = (JSONArray) childParts.get(productListArr.get(i).getTitle());
            		for (int j = 0; j < childHelper.size(); j++) {
						for (int k = 0; k < productListArr.size(); k++) {
							childObject = (JSONObject) childHelper.get(j);
							if(childObject.get("childPartName").equals(productListArr.get(k).getTitle())) {
								temp.addProduct(productListArr.get(k));
							}
						}
					}
            	}
			}
            
            
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
		
//		for (int i = 0; i < productListArr.size(); i++) {
//			Assembled temp;
//			System.out.println("Çocuğum varmı?  " + productListArr.get(i).getTitle());
//			if(productListArr.get(i) instanceof Assembled) {
//				temp = (Assembled) productListArr.get(i);
//				for (int j = 0; j < temp.getChildProducts().size(); j++) {
//					System.out.println("Çocuğum: " + temp.getChildProducts().get(j));
//				}
//			}
//		}
		
		return productListArr;
    }
	
	
	
	@SuppressWarnings("unchecked")
	private static void parseProductObject(JSONObject product) {
        JSONObject productObject = (JSONObject) product.get("product");
        Product newProduct = null;
        if(productObject.containsKey("childParts") && ((String) productObject.get("parent")).equals("null")) {
        	newProduct = new Assembled((String) productObject.get("name"),(long) productObject.get("id"),null, (long) productObject.get("height"));
        	childParts.put(productObject.get("name"), productObject.get("childParts"));
        }else if(productObject.containsKey("childParts")){
        	childParts.put(productObject.get("name"), productObject.get("childParts"));
        	for (int i = 0; i < productListArr.size(); i++) {
				if(productListArr.get(i).getTitle().equals(productObject.get("parent"))) {
		        	newProduct = new Assembled((String) productObject.get("name"),(long) productObject.get("id"),productListArr.get(i), (long) productObject.get("height"));
		        	break;
				}
			}
        }else{
        	for (int i = 0; i < productListArr.size(); i++) {
				if(productListArr.get(i).getTitle().equals((String) productObject.get("parent"))) {
		        	newProduct = new Part((String) productObject.get("name"),(long) productObject.get("id"),productListArr.get(i), (long) productObject.get("height"));
		        	break;
				}
			}
        }
        
        if(((String)productObject.get("state")).equals("Not started")) {
    		newProduct.setState(new NotStartedProduct());
    	}else if(((String)productObject.get("state")).equals("In progress")) {
    		newProduct.setState(new InProgressProduct());
    	}else if(((String)productObject.get("state")).equals("Complete")) {
    		newProduct.setState(new CompleteProduct());
    	}
        
        
        
    	productListArr.add(newProduct);
	}

	@SuppressWarnings("unchecked")
	public static List<User> readUsers(){
		
		JSONParser jsonParser = new JSONParser();
		try (FileReader reader = new FileReader("users.json"))
        {
            Object obj = jsonParser.parse(reader);
 
            JSONArray employeeList = (JSONArray) obj;
            System.out.println(employeeList);
            employeeList.forEach( emp -> parseUserObject( (JSONObject) emp ) );


            System.out.println(managerEmployees.toJSONString());
        	for (int i = 0; i < usersArr.size(); i++) {
        		Manager temp;
                JSONArray employeeHelper = new JSONArray();
                JSONObject managerEmployee = new JSONObject();
            	if(managerEmployees.containsKey(usersArr.get(i).getName())) {
            		temp = (Manager) usersArr.get(i);
            		if(managerEmployees.get(usersArr.get(i).getName()) == null) {
            			continue;
            		}
            		employeeHelper = (JSONArray) managerEmployees.get(usersArr.get(i).getName());
            		for (int j = 0; j < employeeHelper.size(); j++) {
						for (int k = 0; k < usersArr.size(); k++) {
							managerEmployee = (JSONObject) employeeHelper.get(j);
							if(managerEmployee.get("managerEmployee") == null) {
								continue;
							}
							
							if(managerEmployee.get("managerEmployee").equals(usersArr.get(k).getName())) {
								temp.addEmployee((Employee) usersArr.get(k));
							}
						}
					}
            	}
			 }
        	
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
		
		return usersArr;
    }

	
	
	@SuppressWarnings("unchecked")
	private static void parseUserObject(JSONObject emp) {
		JSONObject userObject = (JSONObject) emp.get("user");
		User newUser = null;
		Product tempProduct = null;
		if(userObject.get("type").equals("Admin")) {
			newUser = new Admin((String) userObject.get("name"),(String) userObject.get("password"));
		}else if(userObject.get("type").equals("Manager")) {
			newUser = new Manager((String) userObject.get("name"),(String) userObject.get("password"));
			Manager temp = (Manager) newUser;
			for (int i = 0; i < productListArr.size(); i++) {
				if(((String)userObject.get("worksOn")).equals(productListArr.get(i).getTitle())) {
					temp.setProduct(productListArr.get(i));
				}
			}
			newUser = temp;
			managerEmployees.put((String) userObject.get("name") , userObject.get("employees"));
		}else if(userObject.get("type").equals("Employee")) {
			newUser = new Employee((String) userObject.get("name"),(String) userObject.get("password"),tempProduct);

			Employee temp = (Employee) newUser;
			Part tempPart;
			for (int i = 0; i < productListArr.size(); i++) {
				if(((String)userObject.get("worksOn")).equals(productListArr.get(i).getTitle())) {
					temp.setProduct(productListArr.get(i));
					tempPart = (Part) productListArr.get(i);
					tempPart.setMaker(temp);
					productListArr.set(i, tempPart);
				}
			}
			for (int i = 0; i < usersArr.size(); i++) {
				if(usersArr.get(i).getName().equals(userObject.get("employeeOf"))) {
					temp.setBoss((Manager) usersArr.get(i));;
		        	break;
				}
			}
			newUser = temp;
		}
		
		usersArr.add(newUser);
	}
		
}
