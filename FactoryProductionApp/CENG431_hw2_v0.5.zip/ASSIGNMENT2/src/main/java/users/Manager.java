package users;

import java.util.ArrayList;
import java.util.List;

import assembly.Assembled;
import assembly.CompleteProduct;
import assembly.Product;

public class Manager extends User {

	private Assembled product;
	private List<Employee> employees;
	
	public Manager(String name, String password) {
		super(name, password);
		employees = new ArrayList<Employee>();
	}
	
	public String toString() {
		return "Name: " + getName() + "\nEmail: " + getEmail();
	}
	
	@Override
	public Assembled getProduct() {
		return product;
	}
	
	@Override
	public void setProduct(Product p) {
		Assembled temp = (Assembled) p;
		product = temp;
	}
	
	public void addEmployee(Employee e) {
		employees.add(e);
	}
	
	public List<Employee> getEmployees(){
		return employees;
	}
	
}
