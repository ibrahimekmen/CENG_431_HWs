package users;

import assembly.Product;

public class Admin extends User{

	
	public Admin(String name, String password) {
		super(name, password);
	}

	
	// bu metod kalkıcak userla employee maanger arasına bir worker classı gelebilir
	@Override
	public Product getProduct() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void setProduct(Product p) {
		// TODO Auto-generated method stub
		
	}
	
	
}
