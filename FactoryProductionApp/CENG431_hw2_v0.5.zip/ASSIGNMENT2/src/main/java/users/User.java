package users;

import assembly.Assembled;
import assembly.Product;

public abstract class User {

	private String name;
	private String email;
	private String password;
	
	
	public User(String name, String password) {
		this.name = name;
		this.email = name + "@iyte.factory.com";
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public String getEmail() {
		return email;
	}


	public String getPassword() {
		return password;
	}
	
	public abstract Product getProduct();
	
	public abstract void setProduct(Product p);

	public boolean equals(Object o) {
		if(o == null) {
			return false;
		}
		
		if(!(o instanceof User)) {
			return false;
		}
		
		User temp = (User) o;
		if(temp.getEmail().equals(this.email) && temp.getPassword().equals(this.password)) {
			return true;
		}
		return false;		
	}
	
}
