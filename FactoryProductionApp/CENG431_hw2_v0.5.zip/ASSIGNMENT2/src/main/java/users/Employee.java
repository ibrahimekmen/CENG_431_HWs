package users;

import assembly.Assembled;
import assembly.InProgressProduct;
import assembly.NotStartedProduct;
import assembly.Part;
import assembly.Product;

public class Employee extends User{

	private Product worksOn;
	
	private Manager boss;

	public Employee(String name,String password, Product p) {
		super(name, password);
		this.worksOn = p;
	}
	
//	public void startWork() {
//		if(worksOn.getState() instanceof NotStartedProduct) {
//			worksOn.nextState();
//		}else if(worksOn.getState() instanceof InProgressProduct){
//			System.out.println("This product already started production.");
//		}else {
//			System.out.println("This product is finished. You can't start to work on this product again.");
//		}
//	}
//	
//	public void finishWork() {
//		if(worksOn.getState() instanceof InProgressProduct) {
//			worksOn.nextState();
//		}else if(worksOn.getState() instanceof NotStartedProduct){
//			System.out.println("Before finishing work on the product you should start the work on product.");
//		}else {
//			System.out.println("Product already completed.");
//		}
//	}
	
	
	public void nextStateOfProduct() {
		worksOn.nextState();
	}
	
	public Product getProduct() {
		return worksOn;
	}
	
	public Manager getBoss() {
		return boss;
	}
	
	public void setBoss(Manager boss) {
		this.boss = boss;
	}
	
	public String toString() {
		return "Name: " + getName() + "\nEmail: " + getEmail();
	}

	@Override
	public void setProduct(Product p) {
		worksOn = p;
		
	}

	
}
