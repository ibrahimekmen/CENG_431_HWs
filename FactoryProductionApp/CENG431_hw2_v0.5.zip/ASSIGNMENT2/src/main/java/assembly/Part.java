package assembly;

import users.Employee;

public class Part extends Product{
	
	private Employee maker;
	
	public Part(String title, long id, Product parent, long height) {
		super(title,id,parent,height);
	}

	public void showProductDetails(int margin) {
		String offset = "";
		for (int i = 0; i < margin; i++) {
			offset += "\t";
		}
		System.out.print(offset + "Title: " + getTitle() + "    ID: " + getId() + "    Status: " );
		this.getState().printStatus();
	}
	
	
	public void setMaker(Employee e) {
		maker = e;
	}
	
	public Employee getMaker() {
		return maker;
	}

	
	
}
