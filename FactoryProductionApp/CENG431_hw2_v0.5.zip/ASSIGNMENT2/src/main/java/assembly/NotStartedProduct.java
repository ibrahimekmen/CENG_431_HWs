package assembly;

public class NotStartedProduct implements ProductState{

	@Override
	public void next(Product p) {
		p.setState(new InProgressProduct());
	}
	
	@Override
	public void prev(Product p) {
		System.out.println("This state does not have previous step. This step is the initial step");
		
	}

	@Override
	public void printStatus() {
		System.out.println("Product did not start production yet.");
	}
}
