package assembly;

public interface ProductState{
	void next(Product p);
	void prev(Product p);
	void printStatus();
	
}
