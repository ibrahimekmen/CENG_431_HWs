package assembly;

import java.util.ArrayList;
import java.util.List;

public class Assembled extends Product{
	
	private List<Product> childProducts;
	
	public Assembled(String title, long id, Product parent,long height) {
		super(title,id,parent,height);
		childProducts = new ArrayList<Product>();
	}
	
	// There can be more than one part 
	public void addProduct(Product p) {
		if(!childProducts.contains(p)) {
			childProducts.add(p);
		}else
			System.out.println("This product is already a part of this assmebled product.");
	}
	
	public void showProductDetails(int margin) {
		String offset = "";
		for (int i = 0; i < margin; i++) {
			offset += "\t";
		}
		System.out.println(offset + "Child parts of " + title + ": ");
		for (int i = 0; i < childProducts.size(); i++) {
			if(childProducts.get(i) instanceof Assembled) {
				System.out.println("-----------------------------");
				System.out.println(offset + "Assembly: " + childProducts.get(i).getTitle());
				System.out.print(offset + "Status: ");
				childProducts.get(i).getState().printStatus();
				System.out.println(offset + "Sub parts and sub assembiles of " + childProducts.get(i).getTitle());
				margin++;
				childProducts.get(i).showProductDetails(margin);
				System.out.println("-----------------------------");
				margin--;
			}else {
				System.out.println(offset + "Part: " + childProducts.get(i).getTitle());
				System.out.print(offset + "Status: ");
				childProducts.get(i).getState().printStatus();
				System.out.println(offset + "-------------");
			}

		}
	}
	
	public void checkProgress() {
		boolean completed = true;
		boolean inProgress = true;
		for (int i = 0; i < childProducts.size(); i++) {
			if(!(childProducts.get(i).getState() instanceof CompleteProduct)) {
				completed = false;
			}
			if(!(childProducts.get(i).getState() instanceof InProgressProduct)) {
				inProgress = false;
			}
		}		
		if(completed) {
			this.nextState();
		}else if(inProgress) {
			this.nextState();
		}
	}
	
	public List<Product> getChildProducts(){
		return childProducts;
	}
	
	
	
	
}
