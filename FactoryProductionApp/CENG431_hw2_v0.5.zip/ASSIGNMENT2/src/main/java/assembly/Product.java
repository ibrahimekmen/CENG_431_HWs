package assembly;

public abstract class Product{
	
	protected String title;
	protected long id;
	protected Product parent;
	protected ProductState state;
	protected long height;
	
	public Product(String title, long id, Product parent,long height) {
		this.title = title;
		this.id = id;
		this.parent = parent;
		this.height = height;
		state = new NotStartedProduct();
	}

	public abstract void showProductDetails(int margin);
	
	public Product getParent() {
		return parent;
	}
	
	public long getHeight() {
		return height;
	}
	
	public void setHeight(long height) {
		this.height = height;
	}
	
	public ProductState getState() {
		return state;
	}
	
	public void setState(ProductState s) {
		state = s;
	}

	public void previousState() {
		 state.prev(this);
	 }

	 public void nextState() {
		 state.next(this);
	 }

	 public void printStatus() {
		 state.printStatus();
	 }

	public String getTitle() {
		return title;
	}

	public long getId() {
		return id;
	}
	
	public boolean equals(Object o) {
		boolean result = false;
		
		if(o == null) {
			return false;
		}
		if(!(o instanceof Product)) {
			return false;
		}
		Product temp = (Product) o;
		if((temp.getId() == this.getId())) {
			result = true;
		}		
		
		return result;
	}
	
}
