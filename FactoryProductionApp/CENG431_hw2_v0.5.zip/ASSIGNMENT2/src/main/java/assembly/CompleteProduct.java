package assembly;

public class CompleteProduct implements ProductState {

	@Override
	public void next(Product p) {
		System.out.println("This product is completed. This is the final step.");
		
	}

	@Override
	public void prev(Product p) {
		p.setState(new InProgressProduct());
		
	}

	@Override
	public void printStatus() {
		System.out.println("Product completed production");
	}

}
