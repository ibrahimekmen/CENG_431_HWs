package assembly;

public class InProgressProduct implements ProductState{

	@Override
	public void next(Product p) {
		p.setState(new CompleteProduct());
		
	}

	@Override
	public void prev(Product p) {
		p.setState(new NotStartedProduct());
		
	}

	@Override
	public void printStatus() {
		System.out.println("Product is in production");
	}

}
