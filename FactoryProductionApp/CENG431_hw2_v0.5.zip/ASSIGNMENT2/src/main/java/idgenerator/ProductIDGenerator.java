package idgenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ProductIDGenerator {
	
	private static List<Integer> generatedNumbers = new ArrayList<Integer>();

	public static int generateID() {
		Random rand = new Random();
		int currentNumber;
		int maxLimit = 1000;
	
		currentNumber = rand.nextInt(maxLimit) + 1; //Generates numbers from 1 to max limit
		if(generatedNumbers.isEmpty()) { //Checks if the user has already has an id
			generatedNumbers.add(currentNumber);
		}else {
			while(generatedNumbers.contains(currentNumber)) { //Checks if an id already gotten from another product
				currentNumber = rand.nextInt(maxLimit) + 1;
			}
			generatedNumbers.add(currentNumber);
		}
		
		return currentNumber;
		
	}
}
