package workplaces;

import java.util.List;
import java.util.Scanner;

import assembly.Assembled;
import assembly.CompleteProduct;
import assembly.InProgressProduct;
import assembly.Part;
import assembly.Product;
import idgenerator.ProductIDGenerator;
import idgenerator.UserPasswordGenerator;
import users.Employee;
import users.Manager;
import users.User;

public class Office {

	public static void displayManagers(List<User> users) {
		Manager tempManager;
		System.out.println("Displaying all manangers and their products");
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i) instanceof Manager) {
				tempManager = (Manager) users.get(i);
				System.out.println(tempManager);
				System.out.println("Product name: " + tempManager.getProduct().getTitle());
				System.out.print("Product status: ");
				tempManager.getProduct().getState().printStatus();
				tempManager.getProduct().showProductDetails(0);
			}
		}
	}

	public static void displayEmployees(List<User> users) {
		System.out.println("Displaying all employees and their products");
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i) instanceof Employee) {
				System.out.println(users.get(i));
				users.get(i).getProduct().showProductDetails(0);
				System.out.println("--------------");
			}
		}
	}

	public static void planTheProduct(Manager currentUser, List<User> users, List<Product> products) {
		int partCount;
		System.out.println("How many parts/assemblies will your prouduct(" + currentUser.getProduct().getTitle()
				+ ") consists of: ");
		partCount = getIntInput();

		int which;
		for (int i = 0; i < partCount; i++) {
			System.out.println("Will this part be assembled or a regular part.");
			System.out.println("1) Assembled");
			System.out.println("2) Part");
			which = getIntInputWithLimit(2);

			if (which == 2) {
				currentUser.getProduct()
						.addProduct(createPart(currentUser, users, currentUser.getProduct(), products, 0));
			} else if (which == 1) {
				currentUser.getProduct()
						.addProduct(createAssembly(currentUser, users, currentUser.getProduct(), products, 0));
			}
		}

	}

	private static Product createAssembly(Manager currentUser, List<User> users, Assembled parent,
			List<Product> products, long height) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of the product you want to create");
		String input = sc.nextLine();
		height++;
		Assembled newProduct = new Assembled(input, ProductIDGenerator.generateID(), parent, height);

		System.out.println("How many parts or assemblies does the " + input + " have");
		int productCount = getIntInput();
		int which;
		for (int i = 0; i < productCount; i++) {
			System.out.println("1) Assembled");
			System.out.println("2) Part");
			which = getIntInputWithLimit(2);

			if (which == 2) {
				newProduct.addProduct(createPart(currentUser, users, newProduct, products, height));
			} else if (which == 1) {
				newProduct.addProduct(createAssembly(currentUser, users, newProduct, products, height));
			}
		}

		products.add(newProduct);
		return newProduct;
	}

	private static Product createPart(Manager currentUser, List<User> users, Assembled parent, List<Product> products,
			long height) {
		Scanner sc = new Scanner(System.in);
		height++;
		System.out.println("Enter the part name: ");
		String partName = sc.nextLine();
		System.out.println("Enter employee name: ");
		String employeeName = sc.nextLine();
		Part newPart = new Part(partName, ProductIDGenerator.generateID(), parent, height);
		Employee newEmployee = new Employee(employeeName, UserPasswordGenerator.generatePassword(), newPart);
		newPart.setMaker(newEmployee);
		newEmployee.setBoss(currentUser);
		users.add(newEmployee);
		currentUser.addEmployee(newEmployee);
		products.add(newPart);
		return newPart;
	}

	public static void displayEmployeesForManager(List<User> users, User currentUser) {
		Employee emp;
		System.out.println("Displaying all employees and their products");
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i) instanceof Employee) {
				emp = (Employee) users.get(i);
				if (emp.getBoss().equals(currentUser)) {
					System.out.println(emp);
					emp.getProduct().showProductDetails(0);
					System.out.println("--------------");
				}

			}
		}
	}

	private static int getIntInput() {
		int result;
		Scanner sc = new Scanner(System.in);
		while (true) {
			while (!sc.hasNextInt()) {
				System.out.println("Please enter an integer");
				sc.next();
			}
			result = sc.nextInt();
			if (result < 1) {
				System.out.println("Enter a valid choice!");
			} else
				break;
		}
		return result;
	}

	private static int getIntInputWithLimit(int maxLimit) {
		Scanner sc = new Scanner(System.in);
		int userChoice;
		while (true) {
			while (!sc.hasNextInt()) {
				System.out.println("Please enter an integer");
				sc.next();
			}
			userChoice = sc.nextInt();
			if (userChoice < 1 || userChoice > maxLimit) {
				System.out.println("Enter a valid choice!");
			} else
				break;
		}

		return userChoice;
	}

	public static void checkAssembly(List<Product> products) {

		for (int i = 0; i < products.size(); i++) {
			Product tempProduct = null;
			if (products.get(i) instanceof Part && products.get(i).getState() instanceof InProgressProduct) {
				tempProduct = products.get(i);
				for (int j = 0; j < products.get(i).getHeight() && !(tempProduct.getParent().getState() instanceof CompleteProduct); j++) {
					tempProduct.getParent().setState(new InProgressProduct());
					tempProduct = tempProduct.getParent();
				}
			}
		}

		for (int i = 0; i < products.size(); i++) {
			Product tempProduct;
			Assembled tempAssembled;
			boolean complete = true;
			tempProduct = products.get(i);
			if (tempProduct.getState() instanceof CompleteProduct && !(tempProduct.getParent() == null)) {

				tempAssembled = (Assembled) tempProduct.getParent();
				for (int j = 0; j < tempAssembled.getChildProducts().size(); j++) {
					if (!(tempAssembled.getChildProducts().get(j).getState() instanceof CompleteProduct)) {
						complete = false;
					}
				}
				if (complete) {
					tempAssembled.setState(new CompleteProduct());
				}

				tempProduct = tempProduct.getParent();

			}
		}

//		for (int i = 0; i < products.size(); i++) {
//			boolean inProgress = false;
//			boolean complete = true;
//			Assembled temp;
//			if (products.get(i) instanceof Assembled) {
//				temp = (Assembled) products.get(i);
//				if (temp.getChildProducts().isEmpty()) {
//					return;
//				}
//
//				for (int j = 0; j < temp.getChildProducts().size(); j++) {
//					if (temp.getChildProducts().get(j).getState() instanceof InProgressProduct) {
//						inProgress = true;
//
//					} else if (!(temp.getChildProducts().get(j).getState() instanceof CompleteProduct)) {
//						complete = false;
//					}
//				}
//				if (inProgress) {
//					products.get(i).setState(new InProgressProduct());
//				}
//				if (complete) {
//					products.get(i).setState(new CompleteProduct());
//				}
//			}
//		}

	}

}
