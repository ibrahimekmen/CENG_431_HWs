package iztechfactoryapp;

import menu.MainMenu;

public class IztechFactoryApp {

	public static void main(String[] args) {
		MainMenu.mainMenu();
	}

}
