package controller;

import java.io.IOException;
import java.util.List;

import models.Collection;
import models.User;
import view.LoginView;

public class MainController {

	private static List<User> allUsers;
	private static List<Collection> allCollections;
	public static  void init() {
		read();
		login();
	}
	
	public static void read() {
		allUsers = FileIO.readUsers();
		allCollections = FileIO.readOutfits();
	}
	
	public static void login() {
		LoginView login = new LoginView();
	}
	
	public static void write(){
		FileIO.writeOutfits(InformationMatcher.getAllCollections());
		FileIO.writeUsers(InformationMatcher.getAllUsers());
	}
}
