package view;

import java.util.List;

import javax.swing.*;

import controller.MainController;
import models.User;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainView extends JFrame {
	
	private JTabbedPane jTabbedPane;
	private User currentUser;
	private List<User> allUsers;
	
	public MainView(List<User> allUsers,User currentUser) {
		this.allUsers = allUsers;
		this.currentUser = currentUser;
	}

	
	public void initComponents() {
		HomePage homePage = new HomePage(currentUser);
		DiscoverPage discoverPage = new DiscoverPage(currentUser,allUsers);
		StatisticsPage statisticsPage = new StatisticsPage(allUsers);
		ProfilePage profilePage = new ProfilePage(currentUser);
		homePage.setDiscoverPage(discoverPage);
		discoverPage.setHomePage(homePage);
		homePage.setStatisticsPage(statisticsPage);
		discoverPage.setStatisticsPage(statisticsPage);
		jTabbedPane = new JTabbedPane();
		jTabbedPane.setBackground(new Color(153, 153, 255));
		jTabbedPane.addTab("Home Page", homePage.getHomePage());
		jTabbedPane.addTab("Discover", discoverPage.getDiscoverPage());
		jTabbedPane.addTab("Statistics", statisticsPage.getStatisticsPage());
		jTabbedPane.addTab("Profile Page", profilePage.getProfilePage());
		this.setResizable(false);
		 GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane, GroupLayout.PREFERRED_SIZE, 632, GroupLayout.PREFERRED_SIZE)
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane)
	        );
	    pack();
	    this.setVisible(true);
	    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	    this.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
                MainController.write();
                e.getWindow().dispose();
            }
        });
	}
	
	
	
}

