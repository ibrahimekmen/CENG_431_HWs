package view;

import javax.swing.JPanel;

public abstract class CommonView extends JPanel{
	public void populateComponents() {};
}
