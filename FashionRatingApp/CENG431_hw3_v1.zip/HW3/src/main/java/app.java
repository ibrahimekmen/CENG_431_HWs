
import java.util.ArrayList;

import controller.FileIO;
import controller.MainController;
import models.Collection;
import models.User;

public class app {
	public static void main(String args[]) {
		MainController.init();
		
		ArrayList<User> allUsers = new ArrayList<User>();
		ArrayList<Collection> allCollection = new ArrayList<Collection>();
		
		
		
		
		FileIO.writeOutfits(allCollection);
		FileIO.writeUsers(allUsers);
	}
}
