package controller;

import java.util.ArrayList;
import java.util.List;

import models.User;

public class XMLUsers{
	private List<User> users  = new ArrayList<User>();
	
	public void addUser(User u) {
		users.add(u);
	}
	
	public List<User> getUsers(){
		return users;
	}
}
