package models;

import java.util.ArrayList;
import java.util.List;

public class User{
	private String name;
	private String password;
	
	
	private List<String> followers; // holds the username of the followers
	private List<String> followed; // holds the username of the followers
	private List<Integer> collections; // 
	
	public User(String name, String password) {
		this.name = name;
		this.password = password;
		followers = new ArrayList<User>();
		followed = new ArrayList<User>();
		collectionIDs = new ArrayList<Integer>();
		collections = new ArrayList<Collection>();
	}
	
	
	public List<User> getAllFollowed(){
		return followed;
	}
	
	public Collection getCollection(int i) {
		return collections.get(i);
	}
	
	
	
	public int getCollectionID(int i) {
		return collectionIDs.get(i);
	}
	
	public void addCollection(Collection c) {
		collections.add(c);
	}
	
	public boolean addCollectionID(Integer collectionID) {
		if(collectionID == null) {
			return false;
		}else {
			collectionIDs.add(collectionID);
			return true;
		}
	}
	
	public int getCollectionSize() {
		int result = collections.size();
		return result;
	}
	
	
	public User getFollower(int i) {
		if(followers.isEmpty() == true) {
			return null;
		}else
			return followers.get(i);
	}
	
	public void addFollower(User u) {
		if(followers.contains(u)) {
			System.out.println("You already follow " + getName());
		}else
			followers.add(u);
	}
	
	public void removeFollowed(User u) {
		followed.remove(u);
	}
	
	
	public int getFollowerSize() {
		return followers.size();
	}
	
	
	public boolean addFollowed(User u) {
		if(u == null) {
			return false;
		}else {
			followed.add(u);
			return true;
		}
	}
	
	public User getFollowed(int i) {
		if(followed.isEmpty() == true) {
			return null;
		}else
			return followed.get(i);
	}
	
	public int getFollowedSize() {
		return followed.size();
	}
	
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}


	
}
