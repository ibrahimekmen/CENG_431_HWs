import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import controller.FileIO;
import models.Collection;
import models.Outfit;
import models.User;
import view.MainView;

public class app {
	public static void main(String args[]) throws JsonGenerationException, JsonMappingException, IOException {
		User currentUser = new User("ibo", "23");
		User u1 = new User("Deniz","31");
		User u2 = new User("serkan","34");
		User u3 = new User("koray","54");
		User u4 = new User("serap","31");
		User temp = new User("Caner", "123");
		User temp2 = new User("ege","321");
		User temp3 = new User("mert","213");
		User temp4 = new User("kaan","231");
		User temp5 = new User("tamer","132");
		Collection c = new Collection("Summer", 1);
		Collection c2 = new Collection("work",2);
		Collection c1 = new Collection("yarrak" ,3);
		Outfit o = new Outfit(1, "T-shirt", "yazl�k", "M", "XL", "Red");
		o.addComment("�ok ii");
		Outfit o1 = new Outfit(2,"g�mlek", "i�", "F", "L", "Whites");
		o1.addComment("ben b�le bi�e g�rmemei�eem");
		Outfit o2 = new Outfit(1, "�ort", "plaj", "M", "XS", "yellow");
		o2.addLike(temp);
		o2.addLike(temp2);
		o2.addLike(temp3);
		o2.addLike(temp4);
		o2.addLike(temp5);
		o2.addLike(temp);
		c.addOutfit(o);
		c.addOutfit(o1);
		c.addOutfit(o);
		c.addOutfit(o1);
		c2.addOutfit(o1);
		c2.addOutfit(o);
		temp.addCollection(c);
		temp2.addCollection(c);
		temp3.addCollection(c);
		temp4.addCollection(c);
		temp5.addCollection(c);
		u1.addCollection(c2);
		u2.addCollection(c2);
		u3.addCollection(c);
		u4.addCollection(c);
		c1.addOutfit(o2);
		temp.addCollection(c1);
		currentUser.addFollowed(temp);
		currentUser.addFollowed(temp2);
		currentUser.addFollowed(temp3);
		currentUser.addFollowed(temp4);
		currentUser.addFollowed(temp5);

		currentUser.addFollower(temp);
		currentUser.addFollower(temp2);
		currentUser.addFollower(temp3);
		currentUser.addFollower(temp4);
		currentUser.addFollower(temp5);
		currentUser.addCollection(c2);
		List<User> allUsers = new ArrayList<User>();
		allUsers.add(u3);
		allUsers.add(u4);
		allUsers.add(u2);
		allUsers.add(u1);
		allUsers.add(temp);
		allUsers.add(temp2);
		allUsers.add(temp3);
		allUsers.add(temp4);
		allUsers.add(temp5);
		List<Collection> collections = new ArrayList<Collection>();
		collections.add(c1);
		collections.add(c2);
		collections.add(c);
		FileIO.writeUsers(allUsers);
		//readUsers();
		//FileIO.writeOutfits(collections);
		//readOutfits(users);
		
		MainView mw = new MainView(allUsers,currentUser);
	}
}
