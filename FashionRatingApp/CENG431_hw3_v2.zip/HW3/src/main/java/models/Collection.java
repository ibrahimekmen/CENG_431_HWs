package models;

import java.util.ArrayList;
import java.util.List;

public class Collection {
	private String name;
	private int collectionID;
	private List<Outfit> outfits;
	
	public Collection(String name,int collectionID) {
		this.name = name;
		this.collectionID = collectionID;
		outfits = new ArrayList<Outfit>();
	}
	
	
	public Outfit removeOutfit(Outfit o) {
		Outfit result = o;
		outfits.remove(o);
		return result;
	}
	
	public boolean addOutfit(Outfit o) {
		if(o == null) {
			return false;
		}else {
			outfits.add(o);
			return true;
		}
	}
	
	public Outfit getOutfit(int i) {
		if(outfits.isEmpty()) {
			return null;
		}
		Outfit result = outfits.get(i);
		return result;
	}
	
	public int size() {
		int result = outfits.size();
		return result;
	}
	
	public String getName() {
		return name;
	}

	public int getCollectionID() {
		return collectionID;
	}
	

	
}
