package models;

import java.util.ArrayList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown=true)

public class User{
	private String name;
	private String password;
	
	
	private List<String> followers; // holds the username of the followers
	private List<String> followed; // holds the username of the followers
	private List<Integer> collections; //holds the ids of collections
	
	
	public User(String name, String password) {
		this.name = name;
		this.password = password;
		followers = new ArrayList<String>();
		followed = new ArrayList<String>();
		collections = new ArrayList<Integer>();
	}
	
	public User() {
		
	}
	
	@JsonIgnore
	public List<String> getAllFollowed(){
		return followed;
	}
	
	@JsonIgnore
	public List<String> getAllFollowers(){
		return followers;
	}
	
	@JsonIgnore
	public List<Integer> getAllCollections(){
		return collections;
	}
	
	public Integer getCollection(int i) {
		return collections.get(i);
	}
	

	public void addCollection(Collection c) {
		collections.add(c.getCollectionID());
	}
	
		
	public int getCollectionSize() {
		int result = collections.size();
		return result;
	}
	
	
	public String getFollower(int i) {
		if(followers.isEmpty() == true) {
			return null;
		}else
			return followers.get(i);
	}
	
	public void addFollower(User u) {
		if(followers.contains(u.getName())) {
			System.out.println("You already follow " + getName());
		}else
			followers.add(u.getName());
	}
	
	public void removeFollowed(User u) {
		followed.remove(u.getName());
	}
	
	
	public int getFollowerSize() {
		return followers.size();
	}
	
	
	public boolean addFollowed(User u) {
		if(u == null) {
			return false;
		}else {
			followed.add(u.getName());
			return true;
		}
	}
	
	public String getFollowed(int i) {
		if(followed.isEmpty() == true) {
			return null;
		}else
			return followed.get(i);
	}
	
	public int getFollowedSize() {
		return followed.size();
	}
	
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}

	public void setAllFollowers(ArrayList<String> allFollowers) {
		this.followers = allFollowers;
	}
	
	public void setAllFollowed(ArrayList<String> allFollowed) {
		this.followed = allFollowed;
	}

	public void setAllCollections(ArrayList<Integer> allCollections) {
		this.collections = allCollections;
	}

	
}
