package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.*;

import controller.InformationMatcher;
import models.Collection;
import models.Outfit;
import models.User;

public class DiscoverPage {

	private User currentUser;
	private ArrayList<JButton> collectionNameButtons = new ArrayList<JButton>();
	private ArrayList<JButton> outfitButtons = new ArrayList<JButton>();
	private ArrayList<JButton> userNameButtons = new ArrayList<JButton>();
	private ArrayList<JButton> commentButtons = new ArrayList<JButton>();
	private ArrayList<JTextField> commentStrings = new ArrayList<JTextField>();
	private ArrayList<JButton> likeButtons = new ArrayList<JButton>();
	private ArrayList<JButton> dislikeButtons = new ArrayList<JButton>();
	private ArrayList<Outfit> allOutfits = new ArrayList<Outfit>();
	private ArrayList<User> shownUsers = new ArrayList<User>();
	private ArrayList<User> notFollowedUsers = new ArrayList<User>();
	private List<User> allUsers;
	private boolean initialized;
	private DiscoverPage thisObject = this;
	private HomePage hp;
	private StatisticsPage sp;

	public DiscoverPage(User u, List<User> allUsers) {
		currentUser = u;
		this.allUsers = allUsers;
		setNotFollowed();
		initComponents();
		init();
		initButtons();
		populateComponents();

		discoverPage.setBackground(new java.awt.Color(153, 153, 255));
		discoverPage.setFocusable(false);
		initialized = true;
	}
	
	public void setStatisticsPage(StatisticsPage sp) {
		this.sp = sp;
	}
	public void setHomePage(HomePage h) {
		this.hp = h;
	}
	
	public void setNotFollowed() {
		notFollowedUsers.clear();
		for (int i = 0; i < allUsers.size(); i++) {
			if ((!currentUser.getAllFollowed().contains(allUsers.get(i).getName())) && (!allUsers.contains(currentUser)) ) {
				notFollowedUsers.add(allUsers.get(i));
			}
		}
	}

	private ActionListener actionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			for (int i = 0; i < outfitButtons.size(); i++) {
				if (outfitButtons.get(i) == e.getSource()) {
					JOptionPane.showMessageDialog(null, e.getActionCommand());
				}
			}

			for (int i = 0; i < likeButtons.size(); i++) {
				if (likeButtons.get(i) == e.getSource()) {
					if (!allOutfits.get(i).addLike(currentUser)) {
						JOptionPane.showMessageDialog(null, "You already liked this outfit");
					}
					if (allOutfits.get(i).getUserDisliked().contains(currentUser.getName())) {
						allOutfits.get(i).removeDislike(currentUser);
					}
					likeButtons.get(i).setEnabled(false);
					dislikeButtons.get(i).setEnabled(true);
					break;
				}
			}

			for (int i = 0; i < dislikeButtons.size(); i++) {
				if (dislikeButtons.get(i) == e.getSource()) {
					
					if (!allOutfits.get(i).addDislike(currentUser)) {
						JOptionPane.showMessageDialog(null, "You already disliked this outfit");
					}
					if (allOutfits.get(i).getUserLiked().contains(currentUser.getName())) {
						allOutfits.get(i).removeLike(currentUser);
					}
					dislikeButtons.get(i).setEnabled(false);
					likeButtons.get(i).setEnabled(true);
					break;
				}
			}

			for (int i = 0; i < commentButtons.size(); i++) {
				if (commentButtons.get(i) == e.getSource()) {
					allOutfits.get(i).addComment(commentStrings.get(i).getText());
					commentStrings.get(i).setText("");
				}
			}

			for (int i = 0; i < userNameButtons.size(); i++) {
				if (userNameButtons.get(i) == e.getSource()) {
					UserView userFrame = new UserView(hp,thisObject,currentUser, shownUsers.get(i));
				}
			}

			populateComponents();
			sp.calculateStats();
			discoverPage.revalidate();
			discoverPage.repaint();

		}
	};

	public void clear() {
		allOutfits.clear();
		shownUsers.clear();
	}

	public JPanel getDiscoverPage() {
		return discoverPage;
	}
	
	public void updateCurrentUser(User u) {
		this.currentUser = u;
	}

	private void initButtons() {
		outfitButtons.add(outfit1Dc);
		outfitButtons.add(outfit2Dc);
		outfitButtons.add(outfit3Dc);
		outfitButtons.add(outfit4Dc);
		outfitButtons.add(outfit5Dc);
		outfitButtons.add(outfit6Dc);
		outfitButtons.add(outfit7Dc);
		outfitButtons.add(outfit8Dc);
		outfitButtons.add(outfit9Dc);
		outfitButtons.add(outfit10Dc);
		outfitButtons.add(outfit11Dc);
		outfitButtons.add(outfit12Dc);
		outfitButtons.add(outfit13Dc);
		outfitButtons.add(outfit14Dc);
		outfitButtons.add(outfit15Dc);
		outfitButtons.add(outfit16Dc);
		outfitButtons.add(outfit17Dc);
		outfitButtons.add(outfit18Dc);
		outfitButtons.add(outfit19Dc);
		outfitButtons.add(outfit20Dc);
		outfitButtons.add(outfit21Dc);
		outfitButtons.add(outfit22Dc);
		outfitButtons.add(outfit23Dc);
		outfitButtons.add(outfit24Dc);
		userNameButtons.add(userName1Dc);
		userNameButtons.add(userName2Dc);
		userNameButtons.add(userName3Dc);
		userNameButtons.add(userName4Dc);
		collectionNameButtons.add(collectionName1Dc);
		collectionNameButtons.add(collectionName2Dc);
		collectionNameButtons.add(collectionName3Dc);
		collectionNameButtons.add(collectionName4Dc);
		commentButtons.add(enterComment1Dc);
		commentButtons.add(enterComment2Dc);
		commentButtons.add(enterComment3Dc);
		commentButtons.add(enterComment4Dc);
		commentButtons.add(enterComment5Dc);
		commentButtons.add(enterComment6Dc);
		commentButtons.add(enterComment7Dc);
		commentButtons.add(enterComment8Dc);
		commentButtons.add(enterComment9Dc);
		commentButtons.add(enterComment10Dc);
		commentButtons.add(enterComment11Dc);
		commentButtons.add(enterComment12Dc);
		commentButtons.add(enterComment13Dc);
		commentButtons.add(enterComment14Dc);
		commentButtons.add(enterComment15Dc);
		commentButtons.add(enterComment16Dc);
		commentButtons.add(enterComment17Dc);
		commentButtons.add(enterComment18Dc);
		commentButtons.add(enterComment19Dc);
		commentButtons.add(enterComment20Dc);
		commentButtons.add(enterComment21Dc);
		commentButtons.add(enterComment22Dc);
		commentButtons.add(enterComment23Dc);
		commentButtons.add(enterComment24Dc);
		commentStrings.add(comment1Dc);
		commentStrings.add(comment2Dc);
		commentStrings.add(comment3Dc);
		commentStrings.add(comment4Dc);
		commentStrings.add(comment5Dc);
		commentStrings.add(comment6Dc);
		commentStrings.add(comment7Dc);
		commentStrings.add(comment8Dc);
		commentStrings.add(comment9Dc);
		commentStrings.add(comment10Dc);
		commentStrings.add(comment11Dc);
		commentStrings.add(comment12Dc);
		commentStrings.add(comment13Dc);
		commentStrings.add(comment14Dc);
		commentStrings.add(comment15Dc);
		commentStrings.add(comment16Dc);
		commentStrings.add(comment17Dc);
		commentStrings.add(comment18Dc);
		commentStrings.add(comment19Dc);
		commentStrings.add(comment20Dc);
		commentStrings.add(comment21Dc);
		commentStrings.add(comment22Dc);
		commentStrings.add(comment23Dc);
		commentStrings.add(comment24Dc);
		likeButtons.add(like1Dc);
		likeButtons.add(like2Dc);
		likeButtons.add(like3Dc);
		likeButtons.add(like4Dc);
		likeButtons.add(like5Dc);
		likeButtons.add(like6Dc);
		likeButtons.add(like7Dc);
		likeButtons.add(like8Dc);
		likeButtons.add(like9Dc);
		likeButtons.add(like10Dc);
		likeButtons.add(like11Dc);
		likeButtons.add(like12Dc);
		likeButtons.add(like13Dc);
		likeButtons.add(like14Dc);
		likeButtons.add(like15Dc);
		likeButtons.add(like16Dc);
		likeButtons.add(like17Dc);
		likeButtons.add(like18Dc);
		likeButtons.add(like19Dc);
		likeButtons.add(like20Dc);
		likeButtons.add(like21Dc);
		likeButtons.add(like22Dc);
		likeButtons.add(like23Dc);
		likeButtons.add(like24Dc);
		dislikeButtons.add(dislike1Dc);
		dislikeButtons.add(dislike2Dc);
		dislikeButtons.add(dislike3Dc);
		dislikeButtons.add(dislike4Dc);
		dislikeButtons.add(dislike5Dc);
		dislikeButtons.add(dislike6Dc);
		dislikeButtons.add(dislike7Dc);
		dislikeButtons.add(dislike8Dc);
		dislikeButtons.add(dislike9Dc);
		dislikeButtons.add(dislike10Dc);
		dislikeButtons.add(dislike11Dc);
		dislikeButtons.add(dislike12Dc);
		dislikeButtons.add(dislike13Dc);
		dislikeButtons.add(dislike14Dc);
		dislikeButtons.add(dislike15Dc);
		dislikeButtons.add(dislike16Dc);
		dislikeButtons.add(dislike17Dc);
		dislikeButtons.add(dislike18Dc);
		dislikeButtons.add(dislike19Dc);
		dislikeButtons.add(dislike20Dc);
		dislikeButtons.add(dislike21Dc);
		dislikeButtons.add(dislike22Dc);
		dislikeButtons.add(dislike23Dc);
		dislikeButtons.add(dislike24Dc);

		for (int i = 0; i < likeButtons.size(); i++) {
			likeButtons.get(i).addActionListener(actionListener);
			dislikeButtons.get(i).addActionListener(actionListener);
			commentButtons.get(i).addActionListener(actionListener);
			likeButtons.get(i).setEnabled(false);
			dislikeButtons.get(i).setEnabled(false);
			commentButtons.get(i).setEnabled(false);
		}

		for (int i = 0; i < userNameButtons.size(); i++) {
			userNameButtons.get(i).addActionListener(actionListener);
			userNameButtons.get(i).setEnabled(false);
		}
	}

	public void populateComponents() {
		ArrayList<Collection> notfollowedCollections = new ArrayList<Collection>();
		ArrayList<String> notfollowedNames = new ArrayList<String>();

		
		
		for (int i = 0; i < userNameButtons.size(); i++) {
			shownUsers.add(null);
		}

		for (int i = 0; i < 24; i++) {
			allOutfits.add(null);
		}

		for (int i = 0; i < 4; i++) {

			if (i < notFollowedUsers.size()) {
				
				shownUsers.set(i, notFollowedUsers.get(i));
				for (int j = 0; j < notFollowedUsers.get(i).getCollectionSize(); j++) {
					notfollowedNames.add(notFollowedUsers.get(i).getName());
					notfollowedCollections.add(InformationMatcher.getCollection(notFollowedUsers.get(i), j));
				}
			} else
				shownUsers.set(i, null);
		}

		for (int i = 0; i < 4; i++) {
			if (i < notfollowedCollections.size()) {
				userNameButtons.get(i).setText(notfollowedNames.get(i));
				userNameButtons.get(i).setEnabled(true);
				collectionNameButtons.get(i).setText(notfollowedCollections.get(i).getName());
				for (int j = 0; j < notfollowedCollections.get(i).size() && j < 6; j++) {
					Outfit temp = notfollowedCollections.get(i).getOutfit(j);
					allOutfits.set((j) + (6 * i), temp);
					outfitButtons.get((j) + (6 * i)).setText(temp.getName());
					likeButtons.get((j) + (6 * i)).setEnabled(true);
					dislikeButtons.get((j) + (6 * i)).setEnabled(true);
					commentButtons.get((j) + (6 * i)).setEnabled(true);
					outfitButtons.get((j) + (6 * i)).setEnabled(true);
					commentStrings.get((j) + (6 * i)).setEnabled(true);
					String comments = "";
					for (int k = 0; k < temp.getCommentSize(); k++) {
						comments += "    " + temp.getComment(k) + "\n";
					}
					String actionString = "Gender: " + temp.getGender() + "\nType: " + temp.getClothingType()
							+ "\nOccasion: " + temp.getOccasion() + "\nColor: " + temp.getColor() + "\nSize: " + temp.getSize() + "\nLikes: "
							+ temp.getNumberOfLikes() + "   Dislikes: " + temp.getNumberOfDislikes() + "\nComments:\n"
							+ comments;

					outfitButtons.get((j) + (6 * i)).setActionCommand(actionString);
					if (!initialized) {
						outfitButtons.get((j) + (6 * i)).addActionListener(actionListener);
					}

				}
			} else {
				userNameButtons.get(i).setText("");
				userNameButtons.get(i).setEnabled(false);
				collectionNameButtons.get(i).setText("");
				for (int j = 0; j < 6; j++) {
					allOutfits.set((j) + (6 * i), null);
					outfitButtons.get((j) + (6 * i)).setText("");
					likeButtons.get((j) + (6 * i)).setEnabled(false);
					dislikeButtons.get((j) + (6 * i)).setEnabled(false);
					commentButtons.get((j) + (6 * i)).setEnabled(false);
					outfitButtons.get((j) + (6 * i)).setEnabled(false);
					commentStrings.get((j) + (6 * i)).setEnabled(false);
				}
			}
		}
	}
	
	

	private javax.swing.JPanel collection1PaneDc;
	private javax.swing.JScrollPane collection1ScrollPaneDc;
	private javax.swing.JPanel collection2PaneDc;
	private javax.swing.JScrollPane collection2ScrollPaneDc;
	private javax.swing.JPanel collection3PaneDc;
	private javax.swing.JScrollPane collection3ScrollPaneDc;
	private javax.swing.JPanel collection4PaneDc;
	private javax.swing.JScrollPane collection4ScrollPaneDc;
	private javax.swing.JButton collectionName1Dc;
	private javax.swing.JButton collectionName2Dc;
	private javax.swing.JButton collectionName3Dc;
	private javax.swing.JButton collectionName4Dc;
	private javax.swing.JTextField comment10Dc;
	private javax.swing.JTextField comment11Dc;
	private javax.swing.JTextField comment12Dc;
	private javax.swing.JTextField comment13Dc;
	private javax.swing.JTextField comment14Dc;
	private javax.swing.JTextField comment15Dc;
	private javax.swing.JTextField comment16Dc;
	private javax.swing.JTextField comment17Dc;
	private javax.swing.JTextField comment18Dc;
	private javax.swing.JTextField comment19Dc;
	private javax.swing.JTextField comment1Dc;
	private javax.swing.JTextField comment20Dc;
	private javax.swing.JTextField comment21Dc;
	private javax.swing.JTextField comment22Dc;
	private javax.swing.JTextField comment23Dc;
	private javax.swing.JTextField comment24Dc;
	private javax.swing.JTextField comment2Dc;
	private javax.swing.JTextField comment3Dc;
	private javax.swing.JTextField comment4Dc;
	private javax.swing.JTextField comment5Dc;
	private javax.swing.JTextField comment6Dc;
	private javax.swing.JTextField comment7Dc;
	private javax.swing.JTextField comment8Dc;
	private javax.swing.JTextField comment9Dc;
	private javax.swing.JButton dislike10Dc;
	private javax.swing.JButton dislike11Dc;
	private javax.swing.JButton dislike12Dc;
	private javax.swing.JButton dislike13Dc;
	private javax.swing.JButton dislike14Dc;
	private javax.swing.JButton dislike15Dc;
	private javax.swing.JButton dislike16Dc;
	private javax.swing.JButton dislike17Dc;
	private javax.swing.JButton dislike18Dc;
	private javax.swing.JButton dislike19Dc;
	private javax.swing.JButton dislike1Dc;
	private javax.swing.JButton dislike20Dc;
	private javax.swing.JButton dislike21Dc;
	private javax.swing.JButton dislike22Dc;
	private javax.swing.JButton dislike23Dc;
	private javax.swing.JButton dislike24Dc;
	private javax.swing.JButton dislike2Dc;
	private javax.swing.JButton dislike3Dc;
	private javax.swing.JButton dislike4Dc;
	private javax.swing.JButton dislike5Dc;
	private javax.swing.JButton dislike6Dc;
	private javax.swing.JButton dislike7Dc;
	private javax.swing.JButton dislike8Dc;
	private javax.swing.JButton dislike9Dc;
	private javax.swing.JButton enterComment10Dc;
	private javax.swing.JButton enterComment11Dc;
	private javax.swing.JButton enterComment12Dc;
	private javax.swing.JButton enterComment13Dc;
	private javax.swing.JButton enterComment14Dc;
	private javax.swing.JButton enterComment15Dc;
	private javax.swing.JButton enterComment16Dc;
	private javax.swing.JButton enterComment17Dc;
	private javax.swing.JButton enterComment18Dc;
	private javax.swing.JButton enterComment19Dc;
	private javax.swing.JButton enterComment1Dc;
	private javax.swing.JButton enterComment20Dc;
	private javax.swing.JButton enterComment21Dc;
	private javax.swing.JButton enterComment22Dc;
	private javax.swing.JButton enterComment23Dc;
	private javax.swing.JButton enterComment24Dc;
	private javax.swing.JButton enterComment2Dc;
	private javax.swing.JButton enterComment3Dc;
	private javax.swing.JButton enterComment4Dc;
	private javax.swing.JButton enterComment5Dc;
	private javax.swing.JButton enterComment6Dc;
	private javax.swing.JButton enterComment7Dc;
	private javax.swing.JButton enterComment8Dc;
	private javax.swing.JButton enterComment9Dc;
	private JPanel discoverPage;
	private javax.swing.JButton like10Dc;
	private javax.swing.JButton like11Dc;
	private javax.swing.JButton like12Dc;
	private javax.swing.JButton like13Dc;
	private javax.swing.JButton like14Dc;
	private javax.swing.JButton like15Dc;
	private javax.swing.JButton like16Dc;
	private javax.swing.JButton like17Dc;
	private javax.swing.JButton like18Dc;
	private javax.swing.JButton like19Dc;
	private javax.swing.JButton like1Dc;
	private javax.swing.JButton like20Dc;
	private javax.swing.JButton like21Dc;
	private javax.swing.JButton like22Dc;
	private javax.swing.JButton like23Dc;
	private javax.swing.JButton like24Dc;
	private javax.swing.JButton like2Dc;
	private javax.swing.JButton like3Dc;
	private javax.swing.JButton like4Dc;
	private javax.swing.JButton like5Dc;
	private javax.swing.JButton like6Dc;
	private javax.swing.JButton like7Dc;
	private javax.swing.JButton like8Dc;
	private javax.swing.JButton like9Dc;
	private javax.swing.JButton outfit10Dc;
	private javax.swing.JButton outfit11Dc;
	private javax.swing.JButton outfit12Dc;
	private javax.swing.JButton outfit13Dc;
	private javax.swing.JButton outfit14Dc;
	private javax.swing.JButton outfit15Dc;
	private javax.swing.JButton outfit16Dc;
	private javax.swing.JButton outfit17Dc;
	private javax.swing.JButton outfit18Dc;
	private javax.swing.JButton outfit19Dc;
	private javax.swing.JButton outfit1Dc;
	private javax.swing.JButton outfit20Dc;
	private javax.swing.JButton outfit21Dc;
	private javax.swing.JButton outfit22Dc;
	private javax.swing.JButton outfit23Dc;
	private javax.swing.JButton outfit24Dc;
	private javax.swing.JButton outfit2Dc;
	private javax.swing.JButton outfit3Dc;
	private javax.swing.JButton outfit4Dc;
	private javax.swing.JButton outfit5Dc;
	private javax.swing.JButton outfit6Dc;
	private javax.swing.JButton outfit7Dc;
	private javax.swing.JButton outfit8Dc;
	private javax.swing.JButton outfit9Dc;
	private javax.swing.JButton userName1Dc;
	private javax.swing.JButton userName2Dc;
	private javax.swing.JButton userName3Dc;
	private javax.swing.JButton userName4Dc;

	private void initComponents() {
		discoverPage = new javax.swing.JPanel();
		collection1ScrollPaneDc = new javax.swing.JScrollPane();
		collection1PaneDc = new javax.swing.JPanel();
		comment1Dc = new javax.swing.JTextField();
		outfit1Dc = new javax.swing.JButton();
		enterComment1Dc = new javax.swing.JButton();
		like1Dc = new javax.swing.JButton();
		dislike1Dc = new javax.swing.JButton();
		outfit2Dc = new javax.swing.JButton();
		comment2Dc = new javax.swing.JTextField();
		enterComment2Dc = new javax.swing.JButton();
		like2Dc = new javax.swing.JButton();
		dislike2Dc = new javax.swing.JButton();
		outfit3Dc = new javax.swing.JButton();
		comment3Dc = new javax.swing.JTextField();
		enterComment3Dc = new javax.swing.JButton();
		like3Dc = new javax.swing.JButton();
		dislike3Dc = new javax.swing.JButton();
		outfit4Dc = new javax.swing.JButton();
		comment4Dc = new javax.swing.JTextField();
		enterComment4Dc = new javax.swing.JButton();
		like4Dc = new javax.swing.JButton();
		dislike4Dc = new javax.swing.JButton();
		outfit5Dc = new javax.swing.JButton();
		comment5Dc = new javax.swing.JTextField();
		enterComment5Dc = new javax.swing.JButton();
		like5Dc = new javax.swing.JButton();
		dislike5Dc = new javax.swing.JButton();
		outfit6Dc = new javax.swing.JButton();
		comment6Dc = new javax.swing.JTextField();
		enterComment6Dc = new javax.swing.JButton();
		like6Dc = new javax.swing.JButton();
		dislike6Dc = new javax.swing.JButton();
		userName1Dc = new javax.swing.JButton();
		collectionName1Dc = new javax.swing.JButton();
		collectionName2Dc = new javax.swing.JButton();
		userName2Dc = new javax.swing.JButton();
		userName3Dc = new javax.swing.JButton();
		collectionName3Dc = new javax.swing.JButton();
		collectionName4Dc = new javax.swing.JButton();
		userName4Dc = new javax.swing.JButton();
		collection3ScrollPaneDc = new javax.swing.JScrollPane();
		collection3PaneDc = new javax.swing.JPanel();
		comment13Dc = new javax.swing.JTextField();
		outfit13Dc = new javax.swing.JButton();
		enterComment13Dc = new javax.swing.JButton();
		like13Dc = new javax.swing.JButton();
		dislike13Dc = new javax.swing.JButton();
		outfit14Dc = new javax.swing.JButton();
		comment14Dc = new javax.swing.JTextField();
		like14Dc = new javax.swing.JButton();
		dislike14Dc = new javax.swing.JButton();
		outfit15Dc = new javax.swing.JButton();
		comment15Dc = new javax.swing.JTextField();
		like15Dc = new javax.swing.JButton();
		dislike15Dc = new javax.swing.JButton();
		outfit16Dc = new javax.swing.JButton();
		comment16Dc = new javax.swing.JTextField();
		like16Dc = new javax.swing.JButton();
		dislike16Dc = new javax.swing.JButton();
		outfit17Dc = new javax.swing.JButton();
		comment17Dc = new javax.swing.JTextField();
		like17Dc = new javax.swing.JButton();
		dislike17Dc = new javax.swing.JButton();
		outfit18Dc = new javax.swing.JButton();
		comment18Dc = new javax.swing.JTextField();
		like18Dc = new javax.swing.JButton();
		dislike18Dc = new javax.swing.JButton();
		enterComment14Dc = new javax.swing.JButton();
		enterComment15Dc = new javax.swing.JButton();
		enterComment16Dc = new javax.swing.JButton();
		enterComment17Dc = new javax.swing.JButton();
		enterComment18Dc = new javax.swing.JButton();
		collection2ScrollPaneDc = new javax.swing.JScrollPane();
		collection2PaneDc = new javax.swing.JPanel();
		comment7Dc = new javax.swing.JTextField();
		outfit7Dc = new javax.swing.JButton();
		enterComment7Dc = new javax.swing.JButton();
		like7Dc = new javax.swing.JButton();
		dislike7Dc = new javax.swing.JButton();
		outfit8Dc = new javax.swing.JButton();
		comment8Dc = new javax.swing.JTextField();
		enterComment8Dc = new javax.swing.JButton();
		like8Dc = new javax.swing.JButton();
		dislike8Dc = new javax.swing.JButton();
		outfit9Dc = new javax.swing.JButton();
		comment9Dc = new javax.swing.JTextField();
		enterComment9Dc = new javax.swing.JButton();
		like9Dc = new javax.swing.JButton();
		dislike9Dc = new javax.swing.JButton();
		outfit10Dc = new javax.swing.JButton();
		comment10Dc = new javax.swing.JTextField();
		enterComment10Dc = new javax.swing.JButton();
		like10Dc = new javax.swing.JButton();
		dislike10Dc = new javax.swing.JButton();
		outfit11Dc = new javax.swing.JButton();
		comment11Dc = new javax.swing.JTextField();
		enterComment11Dc = new javax.swing.JButton();
		like11Dc = new javax.swing.JButton();
		dislike11Dc = new javax.swing.JButton();
		outfit12Dc = new javax.swing.JButton();
		comment12Dc = new javax.swing.JTextField();
		enterComment12Dc = new javax.swing.JButton();
		like12Dc = new javax.swing.JButton();
		dislike12Dc = new javax.swing.JButton();
		collection4ScrollPaneDc = new javax.swing.JScrollPane();
		collection4PaneDc = new javax.swing.JPanel();
		comment19Dc = new javax.swing.JTextField();
		outfit19Dc = new javax.swing.JButton();
		enterComment19Dc = new javax.swing.JButton();
		like19Dc = new javax.swing.JButton();
		dislike19Dc = new javax.swing.JButton();
		outfit20Dc = new javax.swing.JButton();
		comment20Dc = new javax.swing.JTextField();
		enterComment20Dc = new javax.swing.JButton();
		like20Dc = new javax.swing.JButton();
		dislike20Dc = new javax.swing.JButton();
		outfit21Dc = new javax.swing.JButton();
		comment21Dc = new javax.swing.JTextField();
		enterComment21Dc = new javax.swing.JButton();
		like21Dc = new javax.swing.JButton();
		dislike21Dc = new javax.swing.JButton();
		outfit22Dc = new javax.swing.JButton();
		comment22Dc = new javax.swing.JTextField();
		enterComment22Dc = new javax.swing.JButton();
		like22Dc = new javax.swing.JButton();
		dislike22Dc = new javax.swing.JButton();
		outfit23Dc = new javax.swing.JButton();
		comment23Dc = new javax.swing.JTextField();
		enterComment23Dc = new javax.swing.JButton();
		like23Dc = new javax.swing.JButton();
		dislike23Dc = new javax.swing.JButton();
		outfit24Dc = new javax.swing.JButton();
		comment24Dc = new javax.swing.JTextField();
		enterComment24Dc = new javax.swing.JButton();
		like24Dc = new javax.swing.JButton();
		dislike24Dc = new javax.swing.JButton();

	}

	private void init() {
		javax.swing.GroupLayout discoverPageLayout = new javax.swing.GroupLayout(discoverPage);
		discoverPage.setLayout(discoverPageLayout);
		discoverPageLayout.setHorizontalGroup(discoverPageLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(discoverPageLayout.createSequentialGroup().addGap(67, 67, 67).addGroup(discoverPageLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(discoverPageLayout.createSequentialGroup()
								.addGroup(discoverPageLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(userName1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(collectionName1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(discoverPageLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(collectionName2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(userName2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGroup(discoverPageLayout.createSequentialGroup().addGroup(discoverPageLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
								.addComponent(collectionName3Dc, javax.swing.GroupLayout.DEFAULT_SIZE, 156,
										Short.MAX_VALUE)
								.addComponent(userName3Dc, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(discoverPageLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(collectionName4Dc, javax.swing.GroupLayout.Alignment.TRAILING,
												javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(userName4Dc, javax.swing.GroupLayout.Alignment.TRAILING,
												javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE))))
						.addGap(91, 91, 91))
				.addGroup(discoverPageLayout.createSequentialGroup().addGap(20, 20, 20)
						.addGroup(discoverPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(discoverPageLayout.createSequentialGroup()
										.addComponent(collection3ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32,
												Short.MAX_VALUE)
										.addComponent(collection4ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(discoverPageLayout.createSequentialGroup()
										.addComponent(collection1ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(collection2ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGap(35, 35, 35)));
		discoverPageLayout.setVerticalGroup(discoverPageLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(discoverPageLayout.createSequentialGroup().addContainerGap()
						.addGroup(discoverPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(userName1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(userName2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(discoverPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(collectionName2Dc, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(collectionName1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(discoverPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(collection1ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(collection2ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
						.addGroup(discoverPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, discoverPageLayout
										.createSequentialGroup()
										.addGroup(discoverPageLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(userName3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(userName4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(discoverPageLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(collectionName3Dc,
														javax.swing.GroupLayout.Alignment.TRAILING,
														javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(collectionName4Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														20, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(collection3ScrollPaneDc, javax.swing.GroupLayout.PREFERRED_SIZE,
												117, javax.swing.GroupLayout.PREFERRED_SIZE))
								.addComponent(collection4ScrollPaneDc, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));
		comment1Dc.setText("Comment1");

		outfit1Dc.setText("Outfit1");

		enterComment1Dc.setText("jButton16");

		like1Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike1Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit2Dc.setText("Outfit 2");

		comment2Dc.setText("Comment2");

		enterComment2Dc.setText("jButton16");

		like2Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike2Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit3Dc.setText("Outfit 3");

		comment3Dc.setText("Comment3");

		enterComment3Dc.setText("jButton16");

		like3Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike3Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit4Dc.setText("Outfit 4");

		comment4Dc.setText("Comment4");

		enterComment4Dc.setText("jButton16");

		like4Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike4Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit5Dc.setText("Outfit 5");

		comment5Dc.setText("Comment5");

		enterComment5Dc.setText("jButton16");

		like5Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike5Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit6Dc.setText("Outfit 6");

		comment6Dc.setText("Comment6");

		enterComment6Dc.setText("jButton16");

		like6Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike6Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		javax.swing.GroupLayout collection1PaneDcLayout = new javax.swing.GroupLayout(collection1PaneDc);
		collection1PaneDc.setLayout(collection1PaneDcLayout);
		collection1PaneDcLayout.setHorizontalGroup(collection1PaneDcLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection1PaneDcLayout.createSequentialGroup()
						.addGroup(collection1PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(comment1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(outfit6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection1PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(enterComment1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(242, 242, 242)));
		collection1PaneDcLayout.setVerticalGroup(collection1PaneDcLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection1PaneDcLayout.createSequentialGroup().addGap(1, 1, 1)
						.addGroup(collection1PaneDcLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike1Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit1Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like1Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment1Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment1Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike2Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit2Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like2Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment2Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment2Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike3Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit3Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like3Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment3Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment3Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike4Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit4Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like4Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment4Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment4Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit5Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like5Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(comment5Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneDcLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit6Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like6Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(comment6Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGroup(collection1PaneDcLayout.createSequentialGroup()
										.addComponent(enterComment5Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(enterComment6Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(1, 1, 1)))
						.addContainerGap()));

		collection1ScrollPaneDc.setViewportView(collection1PaneDc);

		userName1Dc.setText("User Name 1");

		collectionName1Dc.setText("Collection Name 1");

		collectionName2Dc.setText("Collection Name 2");

		userName2Dc.setText("User Name2");

		userName3Dc.setText("User Name 3");

		collectionName3Dc.setText("Collection Name 3");

		collectionName4Dc.setText("Collection Name 4");

		userName4Dc.setText("User Name 4");

		collection3ScrollPaneDc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection3ScrollPaneDc
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection3ScrollPaneDc.setToolTipText("");
		collection3ScrollPaneDc.setRequestFocusEnabled(false);

		collection3PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

		comment13Dc.setText("Comment13");

		outfit13Dc.setText("Outfit13");

		enterComment13Dc.setText("jButton16");

		like13Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike13Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit14Dc.setText("Outfit14");

		comment14Dc.setText("Comment14");

		like14Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike14Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit15Dc.setText("Outfit15");

		comment15Dc.setText("Comment15");

		like15Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike15Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit16Dc.setText("Outfit16");

		comment16Dc.setText("Comment16");

		like16Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike16Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit17Dc.setText("Outfit 17");

		comment17Dc.setText("Comment17");

		like17Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike17Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit18Dc.setText("Outfit 18");

		comment18Dc.setText("Comment18");

		like18Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike18Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		enterComment14Dc.setText("jButton16");

		enterComment15Dc.setText("jButton16");

		enterComment16Dc.setText("jButton16");

		enterComment17Dc.setText("jButton16");

		enterComment18Dc.setText("jButton16");

		javax.swing.GroupLayout collection3PaneDcLayout = new javax.swing.GroupLayout(collection3PaneDc);
		collection3PaneDc.setLayout(collection3PaneDcLayout);
		collection3PaneDcLayout.setHorizontalGroup(
				collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection3PaneDcLayout.createSequentialGroup()
								.addComponent(outfit13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(242, 242, 242))
						.addGroup(collection3PaneDcLayout.createSequentialGroup()
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection3PaneDcLayout.createSequentialGroup()
												.addComponent(outfit14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment14Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneDcLayout.createSequentialGroup()
												.addComponent(outfit15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment15Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneDcLayout.createSequentialGroup()
												.addComponent(outfit18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment18Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneDcLayout.createSequentialGroup()
												.addGroup(collection3PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addGroup(collection3PaneDcLayout
																.createSequentialGroup()
																.addComponent(outfit16Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 99,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(like16Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(dislike16Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		comment16Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 65,
																		javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(collection3PaneDcLayout.createSequentialGroup()
																.addComponent(outfit17Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 99,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(like17Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(dislike17Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(comment17Dc,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 65,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addGroup(collection3PaneDcLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(enterComment17Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 17,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment16Dc,
																javax.swing.GroupLayout.PREFERRED_SIZE, 17,
																javax.swing.GroupLayout.PREFERRED_SIZE))))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection3PaneDcLayout.setVerticalGroup(collection3PaneDcLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection3PaneDcLayout.createSequentialGroup().addGroup(collection3PaneDcLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection3PaneDcLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment13Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment13Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment14Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment14Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment15Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment15Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike16Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit16Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like16Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment16Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment16Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike17Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit17Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like17Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment17Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment17Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment18Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment18Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection3ScrollPaneDc.setViewportView(collection3PaneDc);

		collection2ScrollPaneDc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection2ScrollPaneDc
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection2ScrollPaneDc.setToolTipText("");
		collection2ScrollPaneDc.setRequestFocusEnabled(false);

		collection2PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

		comment7Dc.setText("Comment7");

		outfit7Dc.setText("Outfit7");

		enterComment7Dc.setText("jButton16");

		like7Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike7Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit8Dc.setText("Outfit8");

		comment8Dc.setText("Comment8");

		enterComment8Dc.setText("jButton16");

		like8Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike8Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit9Dc.setText("Outfit9");

		comment9Dc.setText("Comment9");

		enterComment9Dc.setText("jButton16");

		like9Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike9Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit10Dc.setText("Outfit10");

		comment10Dc.setText("Comment10");

		enterComment10Dc.setText("jButton16");

		like10Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike10Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit11Dc.setText("Outfit 11");

		comment11Dc.setText("Comment11");

		enterComment11Dc.setText("jButton16");

		like11Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike11Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit12Dc.setText("Outfit 12");

		comment12Dc.setText("Comment12");

		enterComment12Dc.setText("jButton16");

		like12Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike12Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		javax.swing.GroupLayout collection2PaneDcLayout = new javax.swing.GroupLayout(collection2PaneDc);
		collection2PaneDc.setLayout(collection2PaneDcLayout);
		collection2PaneDcLayout.setHorizontalGroup(
				collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection2PaneDcLayout.createSequentialGroup()
								.addComponent(outfit7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(242, 242, 242))
						.addGroup(collection2PaneDcLayout.createSequentialGroup()
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection2PaneDcLayout.createSequentialGroup()
												.addComponent(outfit8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment8Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneDcLayout.createSequentialGroup()
												.addComponent(outfit9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment9Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneDcLayout.createSequentialGroup()
												.addComponent(outfit10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment10Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneDcLayout.createSequentialGroup()
												.addComponent(outfit11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment11Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneDcLayout.createSequentialGroup()
												.addComponent(outfit12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment12Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection2PaneDcLayout.setVerticalGroup(collection2PaneDcLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection2PaneDcLayout.createSequentialGroup().addGroup(collection2PaneDcLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection2PaneDcLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment7Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment7Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment8Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment8Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment9Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment9Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment10Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment10Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment11Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment11Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment12Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment12Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection2ScrollPaneDc.setViewportView(collection2PaneDc);

		collection4ScrollPaneDc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection4ScrollPaneDc
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection4ScrollPaneDc.setToolTipText("");
		collection4ScrollPaneDc.setRequestFocusEnabled(false);

		collection4PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

		comment19Dc.setText("Comment19");

		outfit19Dc.setText("Outfit19");

		enterComment19Dc.setText("jButton16");

		like19Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike19Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit20Dc.setText("Outfit20");

		comment20Dc.setText("Comment20");

		enterComment20Dc.setText("jButton16");

		like20Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike20Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit21Dc.setText("Outfit21");

		comment21Dc.setText("Comment21");

		enterComment21Dc.setText("jButton16");

		like21Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike21Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit22Dc.setText("Outfit22");

		comment22Dc.setText("Comment22");

		enterComment22Dc.setText("jButton16");

		like22Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike22Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit23Dc.setText("Outfit 23");

		comment23Dc.setText("Comment23");

		enterComment23Dc.setText("jButton16");

		like23Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike23Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit24Dc.setText("Outfit 24");

		comment24Dc.setText("");

		enterComment24Dc.setText("jButton16");

		like24Dc.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike24Dc.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		javax.swing.GroupLayout collection4PaneDcLayout = new javax.swing.GroupLayout(collection4PaneDc);
		collection4PaneDc.setLayout(collection4PaneDcLayout);
		collection4PaneDcLayout.setHorizontalGroup(
				collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection4PaneDcLayout.createSequentialGroup()
								.addComponent(outfit19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(238, 238, 238))
						.addGroup(collection4PaneDcLayout.createSequentialGroup()
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection4PaneDcLayout.createSequentialGroup()
												.addComponent(outfit20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment20Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneDcLayout.createSequentialGroup()
												.addComponent(outfit21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment21Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneDcLayout.createSequentialGroup()
												.addComponent(outfit22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment22Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneDcLayout.createSequentialGroup()
												.addComponent(outfit23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment23Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneDcLayout.createSequentialGroup()
												.addComponent(outfit24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment24Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection4PaneDcLayout.setVerticalGroup(collection4PaneDcLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection4PaneDcLayout.createSequentialGroup().addGroup(collection4PaneDcLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection4PaneDcLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment19Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment19Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment20Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment20Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment21Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment21Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment22Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment22Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment23Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment23Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneDcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneDcLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment24Dc, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment24Dc, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection4ScrollPaneDc.setViewportView(collection4PaneDc);

		collection1ScrollPaneDc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection1ScrollPaneDc
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection1ScrollPaneDc.setToolTipText("");
		collection1ScrollPaneDc.setRequestFocusEnabled(false);
		collection1PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

	}

}
