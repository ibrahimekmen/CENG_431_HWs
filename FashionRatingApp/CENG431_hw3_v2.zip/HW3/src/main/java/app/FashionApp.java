package app;

import java.util.ArrayList;

import controller.FileIO;
import controller.MainController;
import models.Collection;
import models.Outfit;
import models.User;

public class FashionApp {
	public static void main(String args[]) {
		MainController.init();
		
	}
}
