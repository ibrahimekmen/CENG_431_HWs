package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import models.Collection;
import models.User;

public class FileIO {
	
	public static List<User> readUsers() {
		XMLUsers xmlUsers = new XMLUsers();
		XmlMapper xmlMapper = new XmlMapper();
        try {
            String xml = inputStreamToString(new FileInputStream("users.xml"));
            xmlUsers = xmlMapper.readValue(xml, xmlUsers.getClass());
            List<User> allUsers = xmlUsers.getUsers();
            for (User user : allUsers) {
                if (user.getAllFollowers() == null) {
                    user.setAllFollowers(new ArrayList<String>());
                }
                if (user.getAllFollowed() == null) {
                    user.setAllFollowed(new ArrayList<String>());
                }
                if (user.getAllCollections() == null) {
                    user.setAllCollections(new ArrayList<Integer>());
                }
            }
            InformationMatcher.setAllUsers(allUsers);
            return allUsers;
        } catch (IOException e) {
            
            System.out.println(e.getMessage());
        }
        return null;
    }
	
	

	private static String inputStreamToString(InputStream is) throws IOException {
		StringBuilder sb = new StringBuilder();
		String line;
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}

		br.close();
		return sb.toString();
	}
	
	
	public static void writeUsers(List<User> allUsers){
        XMLUsers xmlUsers = new XMLUsers();
        xmlUsers.setUsers(allUsers);
		XmlMapper xmlMapper=new XmlMapper();
        try {
        	
            xmlMapper.writeValue(new File("users.xml"),xmlUsers);
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	

	
	public static void writeOutfits(List<Collection> collections){
		
		Gson allOutfits = new GsonBuilder().setPrettyPrinting().create();
		Writer writer;
		try {
			writer = new FileWriter("Outfits.json");
			allOutfits.toJson(collections, writer);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		};
		
	}
	
	public static List<Collection> readOutfits()  {
		
		Gson gson = new Gson();
		List<Collection> collections = null;
		try {
			Reader reader = new FileReader("Outfits.json");
			collections = gson.fromJson(reader,  new TypeToken<List<Collection>>() {}.getType());
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		InformationMatcher.setAllCollection(collections);
		
		return collections;
	}
	
	
}
