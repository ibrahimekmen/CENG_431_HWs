package models;

import java.util.ArrayList;
import java.util.List;

public class User{
	private String name;
	private String password;
	
	
	private List<User> followers;
	private List<User> followed;
	private List<Integer> collectionIDs;
	private List<Collection> collections;
	
	public User(String name, String password) {
		this.name = name;
		this.password = password;
		followers = new ArrayList<User>();
		followed = new ArrayList<User>();
		collectionIDs = new ArrayList<Integer>();
		collections = new ArrayList<Collection>();
	}
	
	
	public Collection getCollection(int i) {
		return collections.get(i);
	}
	
	public List<Integer> getCollectionIDs() {
		return collectionIDs;
	}

	public void setCollectionIDs(List<Integer> collectionIDs) {
		this.collectionIDs = collectionIDs;
	}
	
	public boolean addFollowed(User u) {
		if(u == null) {
			return false;
		}else {
			followed.add(u);
			return true;
		}
	}
	
	public boolean addCollection(Integer collectionID) {
		if(collectionID == null) {
			return false;
		}else {
			collectionIDs.add(collectionID);
			return true;
		}
	}
	
	public int collectionSize() {
		int result = collectionIDs.size();
		return result;
	}
	
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}
	public List<User> getFollowers() {
		return followers;
	}
	public List<User> getFollowed() {
		return followed;
	}



	
}
