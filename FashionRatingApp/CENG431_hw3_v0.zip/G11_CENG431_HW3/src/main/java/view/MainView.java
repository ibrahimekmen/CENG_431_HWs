package view;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JTabbedPane;

import models.User;

@SuppressWarnings("serial")
public class MainView extends JFrame{
	
	private User currentUser;

	JTabbedPane allPanels = new JTabbedPane();
	
	public MainView(User u) {
		currentUser = u;
		setComponents();
		addToFrame();
		init();
		
	}
	
	private void setComponents() {
		allPanels.setSize(860,600);
		allPanels.addTab("Home Page",new HomePage(currentUser));
		allPanels.addTab("Discover", new HomePage(currentUser));
		allPanels.addTab("Profile Page", new ProfilePage(currentUser));
		this.setResizable(false);
		this.setLayout(new GridLayout(0,5));
	}
	
	public void init() {

		setBounds(400,200,860,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	
	public void addToFrame() {
		this.add(allPanels);
	}

}
