package view;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import models.Collection;
import models.Outfit;
import models.User;

public class HomePage extends JPanel implements ActionListener{

	private User currentUser;
	
	public HomePage(User u){
		this.currentUser = u;
		Collection col = new Collection("123",12);
		col.addOutfit(new Outfit(1,"asd","sada","asda","sda","sadas"));
		User u1 = new User("ibo","123");
		u1.addCollection(col.getCollectionID());
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		for (int i = 0; i < u.getFollowed().size();i++) {
			addFollowedFunc(i);
		}
		setLayoutManger();
		setComponents();
		addToContainer();
		addActionEvent();
		init();
	}	
	
	private void addFollowedFunc(int i) {
		int namePosX, namePosY;
		namePosX = 20 + 200*(i % 4);
		namePosY = 30 + 200*((int)(i/4));
		JTextField nameLabel = new JTextField("User:");
		nameLabel.setBounds(namePosX, namePosY, 60, 15);
		JButton name = new JButton(currentUser.getFollowed().get(i).getName());
		name.setBounds(namePosX + 70,namePosY,70,15);
		JTextField collectionLabel = new JTextField("Collection:");
		JButton collection = new JButton(currentUser.getFollowed().get(i).getCollection(0).getName());
		collectionLabel.setBounds(namePosX, namePosY+20, 60, 15);
		collection.setBounds(namePosX + 70,namePosY+20,70,15);
		collectionLabel.setEditable(false);
		nameLabel.setEditable(false);
		collectionLabel.setBorder(null);
		nameLabel.setBorder(null);
		ButtonGroup bg = new ButtonGroup();
		for (int j = 0; j < currentUser.getFollowed().get(i).collectionSize(); j++) {
			Outfit o = currentUser.getFollowed().get(i).getCollection(0).getOutfit(j);
			JRadioButton newButton = new JRadioButton(o.getName());
			String actionString = "Gender: " + o.getGender() + "\nType: " + o.getClothingType() + "\nColor: " + o.getColor() + "\nSize: " + o.getSize() + "\nLikes: " +o.getNumberOfLikes() + "   Dislikes: " +
			o.getNumberOfDislikes() + "\n" + o.getComment(0);
			newButton.setActionCommand(actionString);
			newButton.addActionListener(this);
			newButton.setBounds(namePosX, namePosY + 40 + (j * 20), 70, 15);
			bg.add(newButton);
			this.add(newButton);
		}
		this.add(collectionLabel);
		this.add(nameLabel);
		this.add(name);
		this.add(collection);
	}
	
	
	private void setLayoutManger() {
		setLayout(null);
	}
	
	private void setComponents() {
	}

	private void addToContainer() {
	}
	
	private void init() {
		this.setBounds(400,200,900,600);
		this.setLayout(null);
		this.setVisible(true);
	}
	
	private void addActionEvent() {
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String[] arr = e.getActionCommand().split("\n");
		JList<String> outfitList = new JList<String>(arr);
		JRadioButton btn = (JRadioButton) e.getSource();
		outfitList.setBounds(btn.getX()+70,btn.getY(),120,130);
		outfitList.setVisibleRowCount(6);
		this.add(outfitList);
		this.revalidate();
		this.repaint();
		
	}

}
