import view.MainView;

public class app {
	public static void main(String args[]) {
		MainView mw = new MainView();
	}
}
