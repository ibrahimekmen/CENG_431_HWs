package models;

import java.util.ArrayList;
import java.util.List;

public class Outfit {

	private int outfitID;
	private String name;
	private String clothingType;
	private String gender;
	private String size;
	private String color;
	private List<String> comments;
	private List<Integer> commentIDs;
	private List<User> userLiked;
	private List<User> userDisliked;
	
	
	public Outfit(int outfitID, String name, String clothingType, String gender, String size, String color) {
		this.outfitID = outfitID;
		this.name = name;
		this.clothingType = clothingType;
		this.gender = gender;
		this.size = size;
		this.color = color;
		commentIDs = new ArrayList<Integer>();
		userLiked = new ArrayList<User>();
		userDisliked = new ArrayList<User>();
		comments = new ArrayList<String>();
	}
	
	
	public int getCommentSize() {
		return comments.size();
	}
	
	public void addComment(String text) {
		comments.add(text);
	}
	
	public String getComment(int i) {
		return comments.get(i);
	}

	public boolean addComment(Integer commentID) {
		if(commentID == null) {
			return false;
		}else {
			commentIDs.add(commentID);
			return true;
		}
	}
	
	public boolean addLike(User u) {
		if(!(userLiked.contains(u))) {
			userLiked.add(u);
			return true;
		}else
			return false;
	}
	
	public boolean addDislike(User u) {
		if(!(userDisliked.contains(u))) {
			userDisliked.add(u);
			return true;
		}else
			return false;
	}
	
	public boolean removeDislike(User u) {
		if(userDisliked.contains(u)) {
			userDisliked.remove(u);
			return true;
		}else
			return false;
	}
	
	public boolean removeLike(User u) {
		if(userLiked.contains(u)) {
			userLiked.remove(u);
			return true;
		}else
			return false;
	}
	
	
	public int size() {
		int result = commentIDs.size();
		return result;
	}

	public int getOutfitID() {
		return outfitID;
	}


	public String getName() {
		return name;
	}


	public String getClothingType() {
		return clothingType;
	}


	public String getGender() {
		return gender;
	}


	public String getSize() {
		return size;
	}


	public String getColor() {
		return color;
	}


	public int getNumberOfLikes() {
		int result = userLiked.size();
		return result;
	}


	public int getNumberOfDislikes() {
		int result = userDisliked.size();
		return result;
	}
	
	public List<User> getUserLiked() {
		return userLiked;
	}

	public List<User> getUserDisliked() {
		return userDisliked;
	}
	
	
}
