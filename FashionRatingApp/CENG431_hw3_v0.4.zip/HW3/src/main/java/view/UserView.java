package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.*;

import models.Outfit;
import models.User;

public class UserView extends JFrame {

	private User viewedUser;
	private User currentUser;
	private HomePage currentPane;
   
    public UserView(HomePage currentPane, User currentUser, User viewedUser) {
    	this.viewedUser = viewedUser;
    	this.currentUser = currentUser;
    	this.currentPane = currentPane;
        initComponents();
        initComboBox();
        this.setLayout(null);
        this.setVisible(true);
    }

   
    public JPanel getUserView() {
    	return userPagePanel;
    }
    
    
    
    private void initComboBox() {
    	String collectionText[] = new String[viewedUser.getCollectionSize()];
    	if(viewedUser.getCollectionSize() == 0) {
    		collectionComboBox.setEnabled(false);
    		collectionInfo.setText(viewedUser.getName() + " has no collections");
    	}else {
    		collectionInfo.setText(viewedUser.getCollection(0).getName() + "\n" + viewedUser.getCollection(0).getName());
    		for (int i = 0; i < viewedUser.getCollectionSize();i++) {
    			collectionText[i] = viewedUser.getCollection(i).getName();
    			
    		}
        	collectionComboBox.setModel(new DefaultComboBoxModel<>(collectionText));
        	collectionComboBox.addActionListener(actionListener);
    	}
    }
    
    
    private ActionListener actionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == followButton) {
				currentUser.addFollowed(viewedUser);
				followButton.setEnabled(false);
				unfollowButton.setEnabled(true);
			}
			
			if(e.getSource() == unfollowButton) {
				currentUser.removeFollowed(viewedUser);
				followButton.setEnabled(true);
				unfollowButton.setEnabled(false);
			}
			
			if(e.getSource() == collectionComboBox) {
				for (int i = 0; i < viewedUser.getCollectionSize(); i++) {
					if(viewedUser.getCollection(i).getName().equals((String) collectionComboBox.getSelectedItem())) {
						String allOutfits = "";
						for (int j = 0; j < viewedUser.getCollection(i).size(); j++) {
							Outfit temp = viewedUser.getCollection(i).getOutfit(j);
							String comments = "";
							for (int k = 0; k < temp.getCommentSize(); k++) {
								comments += "    " + temp.getComment(k) + "\n";
							}
							String outfit = "Name: "+ temp.getName() + "\nGender: " + temp.getGender() + "\nType: " + temp.getClothingType()
							+ "\nColor: " + temp.getColor() + "\nSize: " + temp.getSize() + "\nLikes: "
							+ temp.getNumberOfLikes() + "   Dislikes: " + temp.getNumberOfDislikes() + "\nComments:\n"
							+ comments;
							allOutfits += outfit;
						}

						collectionInfo.setText(allOutfits);
						
						break;
						
					}
				}
			}
			userPagePanel.revalidate();
			userPagePanel.repaint();
		}
	};
                
    private void initComponents() {

        userPagePanel = new JPanel();
        followButton = new JButton();
        unfollowButton = new JButton();
        collectionComboBox = new JComboBox<>();
        userNameLabel = new JLabel();
        userNameVal = new JTextField();
        collectionsLabel = new JLabel();
        collectionInfo = new JTextArea();
        
        collectionInfo.setBounds(175, 180, 300, 200);
        collectionInfo.setEditable(false);
        userPagePanel.add(collectionInfo);
        
        
        

        followButton.addActionListener(actionListener);
        unfollowButton.addActionListener(actionListener);
        
        boolean found = false;
        for (int i = 0; i < currentUser.getFollowedSize(); i++) {
			if(currentUser.getFollowed(i) == viewedUser) {
				followButton.setEnabled(false);
				found = true;
				break;
			}
		}
        
        if(!found) {
        	unfollowButton.setEnabled(false);
        }
        
        followButton.setText("FOLLOW  +");

        unfollowButton.setText("UNFOLLOW  -");

       

        userNameLabel.setText("USERNAME:  ");

        userNameVal.setEditable(false);
        userNameVal.setText(viewedUser.getName());

        collectionsLabel.setText("COLLECTIONS");

        GroupLayout userPagePanelLayout = new GroupLayout(userPagePanel);
        userPagePanel.setLayout(userPagePanelLayout);
        userPagePanelLayout.setHorizontalGroup(
            userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(userPagePanelLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(userNameLabel)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(userNameVal, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(collectionsLabel, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
                    .addGroup(userPagePanelLayout.createSequentialGroup()
                        .addComponent(followButton, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(unfollowButton, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(GroupLayout.Alignment.TRAILING, userPagePanelLayout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(collectionComboBox, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE)
                .addGap(172, 172, 172))
        );
        userPagePanelLayout.setVerticalGroup(
            userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(userPagePanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                        .addComponent(userNameLabel, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(GroupLayout.Alignment.TRAILING, userPagePanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(userNameVal)
                            .addComponent(followButton, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)))
                    .addComponent(unfollowButton, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(collectionsLabel, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(collectionComboBox, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(230, Short.MAX_VALUE))
        );

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(userPagePanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(userPagePanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        
    }
   

    private JTextArea collectionInfo;           
    private JComboBox<String> collectionComboBox;
    private JLabel collectionsLabel;
    private JButton followButton;
    private JButton unfollowButton;
    private JLabel userNameLabel;
    private JTextField userNameVal;
    private JPanel userPagePanel;                  
}
