package view;

import java.awt.EventQueue;

import javax.swing.*;

import models.User;

import java.awt.Color;

public class MainView extends JFrame {
	
	JTabbedPane jTabbedPane;
	User currentUser = new User("Caner","12");
	
	
	public MainView() {
		initComponents();
	}

	private void initComponents() {
		HomePage homePage = new HomePage(currentUser);
		DiscoverPage discoverPage = new DiscoverPage(currentUser);
		StatisticsPage statisticsPage = new StatisticsPage(currentUser);
		ProfilePage profilePage = new ProfilePage(currentUser);
		jTabbedPane = new JTabbedPane();
		jTabbedPane.setBackground(new Color(153, 153, 255));
		jTabbedPane.addTab("Home Page", homePage.getHomePage());
		jTabbedPane.addTab("Discover", discoverPage.getDiscoverPage());
		jTabbedPane.addTab("Statistics", statisticsPage.getStatisticsPage());
		jTabbedPane.addTab("Profile Page", profilePage.getProfilePage());
		this.setResizable(false);
		 GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane, GroupLayout.PREFERRED_SIZE, 632, GroupLayout.PREFERRED_SIZE)
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane)
	        );
	    pack();
	    this.setVisible(true);
	    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
	
}

