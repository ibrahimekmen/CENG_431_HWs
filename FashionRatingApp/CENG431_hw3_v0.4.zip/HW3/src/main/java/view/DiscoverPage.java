package view;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import models.User;

public class DiscoverPage {
	
	User currentUser;
	
	public JPanel getDiscoverPage() {
		return discover;
	}
	
	public DiscoverPage(User u) {
		this.currentUser = u;
		initComponenets();
		init();
	}

    private void initComponenets() {
    	 discover = new JPanel();
         paneDiscover = new JPanel();
         collection1ScrollPaneDc = new JScrollPane();
         collection1PaneDc = new JPanel();
         comment1Dc = new JTextField();
         outfit1Dc = new JButton();
         enterComment1Dc = new JButton();
         like1Dc = new JButton();
         dislike1Dc = new JButton();
         outfit2Dc = new JButton();
         comment2Dc = new JTextField();
         enterComment2Dc = new JButton();
         like2Dc = new JButton();
         dislike2Dc = new JButton();
         outfit3Dc = new JButton();
         commen3tDc = new JTextField();
         enterComment3Dc = new JButton();
         like3Dc = new JButton();
         dislike3Dc = new JButton();
         outfit4Dc = new JButton();
         comment4Dc = new JTextField();
         enterComment4Dc = new JButton();
         like4Dc = new JButton();
         dislike4Dc = new JButton();
         outfit5Dc = new JButton();
         comment5Dc = new JTextField();
         enterComment5Dc = new JButton();
         like5Dc = new JButton();
         dislike5Dc = new JButton();
         outfit6Dc = new JButton();
         comment6Dc = new JTextField();
         enterComment6Dc = new JButton();
         like6Dc = new JButton();
         dislike6Dc = new JButton();
         userName1Dc = new JButton();
         collectionName1Dc = new JButton();
         collectionName2Dc = new JButton();
         userName2Dc = new JButton();
         userName3Dc = new JButton();
         collectionName3Dc = new JButton();
         collectionName4Dc = new JButton();
         userName4Dc = new JButton();
         collection3ScrollPaneDc = new JScrollPane();
         collection3PaneDc = new JPanel();
         comment13Dc = new JTextField();
         outfit13Dc = new JButton();
         enterComment13Dc = new JButton();
         like13Dc = new JButton();
         dislike13Dc = new JButton();
         outfit14Dc = new JButton();
         comment14Dc = new JTextField();
         enterComment14Dc = new JButton();
         like14Dc = new JButton();
         dislike14Dc = new JButton();
         outfit15Dc = new JButton();
         comment15Dc = new JTextField();
         enterComment15Dc = new JButton();
         like15Dc = new JButton();
         dislike15Dc = new JButton();
         outfit16Dc = new JButton();
         comment16Dc = new JTextField();
         enterComment16Dc = new JButton();
         like16Dc = new JButton();
         dislike16Dc = new JButton();
         outfit17Dc = new JButton();
         comment17Dc = new JTextField();
         enterComment17Dc = new JButton();
         like17Dc = new JButton();
         dislike17Dc = new JButton();
         outfit18Dc = new JButton();
         comment18Dc = new JTextField();
         enterComment18Dc = new JButton();
         like18Dc = new JButton();
         dislike18Dc = new JButton();
         collection2ScrollPaneDc = new JScrollPane();
         collection2PaneDc = new JPanel();
         comment7Dc = new JTextField();
         outfit7Dc = new JButton();
         enterComment7Dc = new JButton();
         like7Dc = new JButton();
         dislike7Dc = new JButton();
         outfit8Dc = new JButton();
         comment8Dc = new JTextField();
         enterComment8Dc = new JButton();
         like8Dc = new JButton();
         dislike8Dc = new JButton();
         outfit9Dc = new JButton();
         comment9Dc = new JTextField();
         enterComment9Dc = new JButton();
         like9Dc = new JButton();
         dislike9Dc = new JButton();
         outfit10Dc = new JButton();
         comment10Dc = new JTextField();
         enterComment10Dc = new JButton();
         like10Dc = new JButton();
         dislike10Dc = new JButton();
         outfit11Dc = new JButton();
         comment11Dc = new JTextField();
         enterComment11Dc = new JButton();
         like11Dc = new JButton();
         dislike11Dc = new JButton();
         outfit12Dc = new JButton();
         comment12Dc = new JTextField();
         enterComment12Dc = new JButton();
         like12Dc = new JButton();
         dislike12Dc = new JButton();
         collection4ScrollPaneDc = new JScrollPane();
         collection4PaneDc = new JPanel();
         comment19Dc = new JTextField();
         outfit19Dc = new JButton();
         enterComment19Dc = new JButton();
         like19Dc = new JButton();
         dislike19Dc = new JButton();
         outfit20Dc = new JButton();
         comment20Dc = new JTextField();
         enterComment20Dc = new JButton();
         like20Dc = new JButton();
         dislike20Dc = new JButton();
         outfit21Dc = new JButton();
         comment21Dc = new JTextField();
         enterComment21Dc = new JButton();
         like21Dc = new JButton();
         dislike21Dc = new JButton();
         outfit22Dc = new JButton();
         comment22Dc = new JTextField();
         enterComment22Dc = new JButton();
         like22Dc = new JButton();
         dislike22Dc = new JButton();
         outfit23Dc = new JButton();
         comment23Dc = new JTextField();
         enterComment23Dc = new JButton();
         like23Dc = new JButton();
         dislike23Dc = new JButton();
         outfit24Dc = new JButton();
         comment24Dc = new JTextField();
         enterComment24Dc = new JButton();
         like24Dc = new JButton();
         dislike24Dc = new JButton();
		
	}

	private void init() {
    	 paneDiscover.setBackground(new java.awt.Color(153, 153, 255));

         collection1ScrollPaneDc.setBorder(new SoftBevelBorder(BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.green, null, null));
         collection1ScrollPaneDc.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
         collection1ScrollPaneDc.setToolTipText("");
         collection1ScrollPaneDc.setRequestFocusEnabled(false);

         collection1PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

         comment1Dc.setText("Comment1");
         comment1Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment1DcActionPerformed(evt);
             }
         });

         outfit1Dc.setText("D Outfit1");

         enterComment1Dc.setText("jButton16");

         like1Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike1Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike1Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike1DcActionPerformed(evt);
             }
         });

         outfit2Dc.setText("D Outfit2");

         comment2Dc.setText("Comment2");
         comment2Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment2DcActionPerformed(evt);
             }
         });

         enterComment2Dc.setText("jButton16");

         like2Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike2Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike2Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike2DcActionPerformed(evt);
             }
         });

         outfit3Dc.setText("D Outfit3");
         outfit3Dc.setToolTipText("");

         commen3tDc.setText("Comment3");
         commen3tDc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 commen3tDcActionPerformed(evt);
             }
         });

         enterComment3Dc.setText("jButton16");

         like3Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike3Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike3Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike3DcActionPerformed(evt);
             }
         });

         outfit4Dc.setText("D Outfit4");

         comment4Dc.setText("Comment4");
         comment4Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment4DcActionPerformed(evt);
             }
         });

         enterComment4Dc.setText("jButton16");

         like4Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike4Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike4Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike4DcActionPerformed(evt);
             }
         });

         outfit5Dc.setText("D Outfit5");

         comment5Dc.setText("Comment5");
         comment5Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment5DcActionPerformed(evt);
             }
         });

         enterComment5Dc.setText("jButton16");

         like5Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike5Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike5Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike5DcActionPerformed(evt);
             }
         });

         outfit6Dc.setText("D Outfit6");

         comment6Dc.setText("Comment6");
         comment6Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment6DcActionPerformed(evt);
             }
         });

         enterComment6Dc.setText("jButton16");

         like6Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike6Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike6Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike6DcActionPerformed(evt);
             }
         });

         GroupLayout collection1PaneDcLayout = new GroupLayout(collection1PaneDc);
         collection1PaneDc.setLayout(collection1PaneDcLayout);
         collection1PaneDcLayout.setHorizontalGroup(
             collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection1PaneDcLayout.createSequentialGroup()
                 .addComponent(outfit1Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(like1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(dislike1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(comment1Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(enterComment1Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
                 .addGap(238, 238, 238))
             .addGroup(collection1PaneDcLayout.createSequentialGroup()
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(collection1PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit2Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment2Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment2Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit3Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(commen3tDc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment3Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit4Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment4Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment4Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit5Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment5Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment5Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit6Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment6Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment6Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
         );
         collection1PaneDcLayout.setVerticalGroup(
             collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection1PaneDcLayout.createSequentialGroup()
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment1Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment1Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment2Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment2Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(commen3tDc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment3Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment4Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment4Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment5Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment5Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection1PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment6Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment6Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap())
         );

         collection1ScrollPaneDc.setViewportView(collection1PaneDc);

         userName1Dc.setText("D UserName1");

         collectionName1Dc.setText("D Collection Name1");

         collectionName2Dc.setText("D Collection Name2");

         userName2Dc.setText("D UserName2");
         userName2Dc.setToolTipText("");

         userName3Dc.setText("D UserName3");

         collectionName3Dc.setText("D Collection Name 3");

         collectionName4Dc.setText("D Collection Name4");

         userName4Dc.setText("D UserName4");

         collection3ScrollPaneDc.setBorder(new SoftBevelBorder(BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.green, null, null));
         collection3ScrollPaneDc.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
         collection3ScrollPaneDc.setToolTipText("");
         collection3ScrollPaneDc.setRequestFocusEnabled(false);

         collection3PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

         comment13Dc.setText("Comment13");
         comment13Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment13DcActionPerformed(evt);
             }
         });

         outfit13Dc.setText("D Outfit13");

         enterComment13Dc.setText("jButton16");

         like13Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike13Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike13Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike13DcActionPerformed(evt);
             }
         });

         outfit14Dc.setText("D Outfit14");

         comment14Dc.setText("Comment14");
         comment14Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment14DcActionPerformed(evt);
             }
         });

         enterComment14Dc.setText("jButton16");

         like14Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike14Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike14Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike14DcActionPerformed(evt);
             }
         });

         outfit15Dc.setText("D Outfit15");

         comment15Dc.setText("Comment15");
         comment15Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment15DcActionPerformed(evt);
             }
         });

         enterComment15Dc.setText("jButton16");

         like15Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike15Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike15Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike15DcActionPerformed(evt);
             }
         });

         outfit16Dc.setText("D Outfit16");

         comment16Dc.setText("Comment16");
         comment16Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment16DcActionPerformed(evt);
             }
         });

         enterComment16Dc.setText("jButton16");

         like16Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike16Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike16Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike16DcActionPerformed(evt);
             }
         });

         outfit17Dc.setText("D Outfit17");

         comment17Dc.setText("Comment17");
         comment17Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment17DcActionPerformed(evt);
             }
         });

         enterComment17Dc.setText("jButton16");

         like17Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike17Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike17Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike17DcActionPerformed(evt);
             }
         });

         outfit18Dc.setText("D Outfit18");

         comment18Dc.setText("Comment18");
         comment18Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment18DcActionPerformed(evt);
             }
         });

         enterComment18Dc.setText("jButton16");

         like18Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike18Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike18Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike18DcActionPerformed(evt);
             }
         });

         GroupLayout collection3PaneDcLayout = new GroupLayout(collection3PaneDc);
         collection3PaneDc.setLayout(collection3PaneDcLayout);
         collection3PaneDcLayout.setHorizontalGroup(
             collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection3PaneDcLayout.createSequentialGroup()
                 .addComponent(outfit13Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(like13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(dislike13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(comment13Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(enterComment13Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
                 .addGap(238, 238, 238))
             .addGroup(collection3PaneDcLayout.createSequentialGroup()
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(collection3PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit14Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment14Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment14Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit15Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment15Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment15Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit16Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment16Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment16Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit17Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment17Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment17Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit18Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment18Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment18Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
         );
         collection3PaneDcLayout.setVerticalGroup(
             collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection3PaneDcLayout.createSequentialGroup()
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment13Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment13Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment14Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment14Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment15Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment15Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment16Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment16Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment17Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment17Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection3PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment18Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment18Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap())
         );

         collection3ScrollPaneDc.setViewportView(collection3PaneDc);

         collection2ScrollPaneDc.setBorder(new SoftBevelBorder(BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.green, null, null));
         collection2ScrollPaneDc.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
         collection2ScrollPaneDc.setToolTipText("");
         collection2ScrollPaneDc.setRequestFocusEnabled(false);

         collection2PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

         comment7Dc.setText("Comment7");
         comment7Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment7DcActionPerformed(evt);
             }
         });

         outfit7Dc.setText("D Outfit7");

         enterComment7Dc.setText("jButton16");

         like7Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike7Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike7Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike7DcActionPerformed(evt);
             }
         });

         outfit8Dc.setText("D Outfit8");

         comment8Dc.setText("Comment8");
         comment8Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment8DcActionPerformed(evt);
             }
         });

         enterComment8Dc.setText("jButton16");

         like8Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike8Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike8Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike8DcActionPerformed(evt);
             }
         });

         outfit9Dc.setText("D Outfit9");
         outfit9Dc.setToolTipText("");

         comment9Dc.setText("Comment9");
         comment9Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment9DcActionPerformed(evt);
             }
         });

         enterComment9Dc.setText("jButton16");

         like9Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike9Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike9Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike9DcActionPerformed(evt);
             }
         });

         outfit10Dc.setText("D Outfit10");

         comment10Dc.setText("Comment10");
         comment10Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment10DcActionPerformed(evt);
             }
         });

         enterComment10Dc.setText("jButton16");

         like10Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike10Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike10Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike10DcActionPerformed(evt);
             }
         });

         outfit11Dc.setText("D Outfit11");

         comment11Dc.setText("Comment11");
         comment11Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment11DcActionPerformed(evt);
             }
         });

         enterComment11Dc.setText("jButton16");

         like11Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike11Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike11Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike11DcActionPerformed(evt);
             }
         });

         outfit12Dc.setText("D Outfit12");

         comment12Dc.setText("Comment12");
         comment12Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment12DcActionPerformed(evt);
             }
         });

         enterComment12Dc.setText("jButton16");

         like12Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike12Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike12Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike12DcActionPerformed(evt);
             }
         });

         GroupLayout collection2PaneDcLayout = new GroupLayout(collection2PaneDc);
         collection2PaneDc.setLayout(collection2PaneDcLayout);
         collection2PaneDcLayout.setHorizontalGroup(
             collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection2PaneDcLayout.createSequentialGroup()
                 .addComponent(outfit7Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(like7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(dislike7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(comment7Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(enterComment7Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
                 .addGap(238, 238, 238))
             .addGroup(collection2PaneDcLayout.createSequentialGroup()
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(collection2PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit8Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment8Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment8Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit9Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment9Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment9Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit10Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment10Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment10Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit11Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment11Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment11Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit12Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment12Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment12Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
         );
         collection2PaneDcLayout.setVerticalGroup(
             collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection2PaneDcLayout.createSequentialGroup()
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment7Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment7Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment8Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment8Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment9Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment9Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment10Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment10Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment11Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment11Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection2PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment12Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment12Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap())
         );

         collection2ScrollPaneDc.setViewportView(collection2PaneDc);

         collection4ScrollPaneDc.setBorder(new SoftBevelBorder(BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.green, null, null));
         collection4ScrollPaneDc.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
         collection4ScrollPaneDc.setToolTipText("");
         collection4ScrollPaneDc.setRequestFocusEnabled(false);

         collection4PaneDc.setPreferredSize(new java.awt.Dimension(425, 200));

         comment19Dc.setText("Comment19");
         comment19Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment19DcActionPerformed(evt);
             }
         });

         outfit19Dc.setText("D Outfit19");

         enterComment19Dc.setText("jButton16");

         like19Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike19Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike19Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike19DcActionPerformed(evt);
             }
         });

         outfit20Dc.setText("D Outfit20");

         comment20Dc.setText("Comment20");
         comment20Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment20DcActionPerformed(evt);
             }
         });

         enterComment20Dc.setText("jButton16");

         like20Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike20Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike20Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike20DcActionPerformed(evt);
             }
         });

         outfit21Dc.setText("D Outfit21");

         comment21Dc.setText("Comment21");
         comment21Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment21DcActionPerformed(evt);
             }
         });

         enterComment21Dc.setText("jButton16");

         like21Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike21Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike21Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike21DcActionPerformed(evt);
             }
         });

         outfit22Dc.setText("D Outfit22");

         comment22Dc.setText("Comment22");
         comment22Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment22DcActionPerformed(evt);
             }
         });

         enterComment22Dc.setText("jButton16");

         like22Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike22Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike22Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike22DcActionPerformed(evt);
             }
         });

         outfit23Dc.setText("D Outfit23");

         comment23Dc.setText("Comment23");
         comment23Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment23DcActionPerformed(evt);
             }
         });

         enterComment23Dc.setText("jButton16");

         like23Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike23Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike23Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike23DcActionPerformed(evt);
             }
         });

         outfit24Dc.setText("D Outfit24");

         comment24Dc.setText("Comment24");
         comment24Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 comment24DcActionPerformed(evt);
             }
         });

         enterComment24Dc.setText("jButton16");

         like24Dc.setIcon(new ImageIcon("like.png")); // NOI18N

         dislike24Dc.setIcon(new ImageIcon("dislike.png")); // NOI18N
         dislike24Dc.addActionListener(new java.awt.event.ActionListener() {
             public void actionPerformed(java.awt.event.ActionEvent evt) {
                 dislike24DcActionPerformed(evt);
             }
         });

         GroupLayout collection4PaneDcLayout = new GroupLayout(collection4PaneDc);
         collection4PaneDc.setLayout(collection4PaneDcLayout);
         collection4PaneDcLayout.setHorizontalGroup(
             collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection4PaneDcLayout.createSequentialGroup()
                 .addComponent(outfit19Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(like19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(dislike19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                 .addComponent(comment19Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addComponent(enterComment19Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
                 .addGap(238, 238, 238))
             .addGroup(collection4PaneDcLayout.createSequentialGroup()
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(collection4PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit20Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment20Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment20Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit21Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment21Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment21Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit22Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment22Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment22Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit23Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment23Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment23Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createSequentialGroup()
                         .addComponent(outfit24Dc, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(like24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(dislike24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(comment24Dc, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(enterComment24Dc, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
         );
         collection4PaneDcLayout.setVerticalGroup(
             collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(collection4PaneDcLayout.createSequentialGroup()
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment19Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment19Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment20Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment20Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment21Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment21Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment22Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment22Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment23Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment23Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(dislike24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(outfit24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
                         .addComponent(like24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
                     .addGroup(collection4PaneDcLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                         .addComponent(comment24Dc, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                         .addComponent(enterComment24Dc, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)))
                 .addContainerGap())
         );

         collection4ScrollPaneDc.setViewportView(collection4PaneDc);

         GroupLayout paneDiscoverLayout = new GroupLayout(paneDiscover);
         paneDiscover.setLayout(paneDiscoverLayout);
         paneDiscoverLayout.setHorizontalGroup(
             paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(paneDiscoverLayout.createSequentialGroup()
                 .addGap(67, 67, 67)
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(paneDiscoverLayout.createSequentialGroup()
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                             .addComponent(userName1Dc, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE)
                             .addComponent(collectionName1Dc, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE))
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                             .addComponent(collectionName2Dc, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE)
                             .addComponent(userName2Dc, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE)))
                     .addGroup(paneDiscoverLayout.createSequentialGroup()
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                             .addComponent(collectionName3Dc, GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                             .addComponent(userName3Dc, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                             .addComponent(collectionName4Dc, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE)
                             .addComponent(userName4Dc, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE))))
                 .addGap(91, 91, 91))
             .addGroup(paneDiscoverLayout.createSequentialGroup()
                 .addGap(20, 20, 20)
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(paneDiscoverLayout.createSequentialGroup()
                         .addComponent(collection3ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 270, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                         .addComponent(collection4ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 270, GroupLayout.PREFERRED_SIZE))
                     .addGroup(paneDiscoverLayout.createSequentialGroup()
                         .addComponent(collection1ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 270, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                         .addComponent(collection2ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 270, GroupLayout.PREFERRED_SIZE)))
                 .addGap(35, 35, 35))
         );
         paneDiscoverLayout.setVerticalGroup(
             paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(paneDiscoverLayout.createSequentialGroup()
                 .addContainerGap()
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                     .addComponent(userName1Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
                     .addComponent(userName2Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(collectionName2Dc, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
                     .addComponent(collectionName1Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(collection1ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE)
                     .addComponent(collection2ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE))
                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                 .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(GroupLayout.Alignment.TRAILING, paneDiscoverLayout.createSequentialGroup()
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                             .addComponent(userName3Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
                             .addComponent(userName4Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addGroup(paneDiscoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                             .addComponent(collectionName3Dc, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
                             .addComponent(collectionName4Dc, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(collection3ScrollPaneDc, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE))
                     .addComponent(collection4ScrollPaneDc, GroupLayout.Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE))
                 .addContainerGap())
         );

         GroupLayout discoverLayout = new GroupLayout(discover);
         discover.setLayout(discoverLayout);
         discoverLayout.setHorizontalGroup(
             discoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGap(0, 627, Short.MAX_VALUE)
             .addGroup(discoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                 .addGroup(discoverLayout.createSequentialGroup()
                     .addComponent(paneDiscover, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                     .addGap(0, 0, Short.MAX_VALUE)))
         );
         discoverLayout.setVerticalGroup(
             discoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGap(0, 409, Short.MAX_VALUE)
             .addGroup(discoverLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                 .addGroup(discoverLayout.createSequentialGroup()
                     .addComponent(paneDiscover, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                     .addGap(0, 0, Short.MAX_VALUE)))
         );
	}
    
    private void comment1DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike1DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment2DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike2DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void commen3tDcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike3DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment4DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike4DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment5DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike5DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment6DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike6DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment13DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike13DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment14DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike14DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment15DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike15DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment16DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike16DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment17DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike17DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment18DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike18DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment7DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike7DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment8DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike8DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment9DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void dislike9DcActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void comment10DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike10DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment11DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike11DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment12DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike12DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment19DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike19DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment20DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike20DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment21DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike21DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment22DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike22DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment23DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike23DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void comment24DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                                           

    private void dislike24DcActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
    }                           

	private JPanel collection1PaneDc;
    private JScrollPane collection1ScrollPaneDc;
    private JPanel collection2PaneDc;
    private JScrollPane collection2ScrollPaneDc;
    private JPanel collection3PaneDc;
    private JScrollPane collection3ScrollPaneDc;
    private JPanel collection4PaneDc;
    private JScrollPane collection4ScrollPaneDc;
    private JButton collectionName1Dc;
    private JButton collectionName2Dc;
    private JButton collectionName3Dc;
    private JButton collectionName4Dc;    
    private JTextField commen3tDc;
    private JTextField comment10Dc;
    private JTextField comment11Dc;
    private JTextField comment12Dc;
    private JTextField comment13Dc;
    private JTextField comment14Dc;
    private JTextField comment15Dc;
    private JTextField comment16Dc;
    private JTextField comment17Dc;
    private JTextField comment18Dc;
    private JTextField comment19Dc;
    private JTextField comment1Dc;
    private JTextField comment20Dc;
    private JTextField comment21Dc;
    private JTextField comment22Dc;
    private JTextField comment23Dc;
    private JTextField comment24Dc;
    private JTextField comment2Dc;
    private JTextField comment4Dc;
    private JTextField comment5Dc;
    private JTextField comment6Dc;
    private JTextField comment7Dc;
    private JTextField comment8Dc;
    private JTextField comment9Dc;
    private JPanel discover;
    private JButton dislike10Dc;
    private JButton dislike11Dc;
    private JButton dislike12Dc;
    private JButton dislike13Dc;
    private JButton dislike14Dc;
    private JButton dislike15Dc;
    private JButton dislike16Dc;
    private JButton dislike17Dc;
    private JButton dislike18Dc;
    private JButton dislike19Dc;
    private JButton dislike1Dc;
    private JButton dislike20Dc;
    private JButton dislike21Dc;
    private JButton dislike22Dc;
    private JButton dislike23Dc;
    private JButton dislike24Dc;
    private JButton dislike2Dc;
    private JButton dislike3Dc;
    private JButton dislike4Dc;
    private JButton dislike5Dc;
    private JButton dislike6Dc;
    private JButton dislike7Dc;
    private JButton dislike8Dc;
    private JButton dislike9Dc;
    private JButton enterComment10Dc;
    private JButton enterComment11Dc;
    private JButton enterComment12Dc;
    private JButton enterComment13Dc;
    private JButton enterComment14Dc;
    private JButton enterComment15Dc;
    private JButton enterComment16Dc;
    private JButton enterComment17Dc;
    private JButton enterComment18Dc;
    private JButton enterComment19Dc;
    private JButton enterComment1Dc;
    private JButton enterComment20Dc;
    private JButton enterComment21Dc;
    private JButton enterComment22Dc;
    private JButton enterComment23Dc;
    private JButton enterComment24Dc;
    private JButton enterComment2Dc;
    private JButton enterComment3Dc;
    private JButton enterComment4Dc;
    private JButton enterComment5Dc;
    private JButton enterComment6Dc;
    private JButton enterComment7Dc;
    private JButton enterComment8Dc;
    private JButton enterComment9Dc;
    private JButton like10Dc;
    private JButton like11Dc;
    private JButton like12Dc;
    private JButton like13Dc;
    private JButton like14Dc;
    private JButton like15Dc;
    private JButton like16Dc;
    private JButton like17Dc;
    private JButton like18Dc;
    private JButton like19Dc;
    private JButton like1Dc;
    private JButton like20Dc;
    private JButton like21Dc;
    private JButton like22Dc;
    private JButton like23Dc;
    private JButton like24Dc;
    private JButton like2Dc;
    private JButton like3Dc;
    private JButton like4Dc;
    private JButton like5Dc;
    private JButton like6Dc;
    private JButton like7Dc;
    private JButton like8Dc;
    private JButton like9Dc;
    private JButton outfit10Dc;
    private JButton outfit11Dc;
    private JButton outfit12Dc;
    private JButton outfit13Dc;
    private JButton outfit14Dc;
    private JButton outfit15Dc;
    private JButton outfit16Dc;
    private JButton outfit17Dc;
    private JButton outfit18Dc;
    private JButton outfit19Dc;
    private JButton outfit1Dc;
    private JButton outfit20Dc;
    private JButton outfit21Dc;
    private JButton outfit22Dc;
    private JButton outfit23Dc;
    private JButton outfit24Dc;
    private JButton outfit2Dc;
    private JButton outfit3Dc;
    private JButton outfit4Dc;
    private JButton outfit5Dc;
    private JButton outfit6Dc;
    private JButton outfit7Dc;
    private JButton outfit8Dc;
    private JButton outfit9Dc;
    private JPanel paneDiscover;
    private JButton userName1Dc;
    private JButton userName2Dc;
    private JButton userName3Dc;
    private JButton userName4Dc;
    
    

}
