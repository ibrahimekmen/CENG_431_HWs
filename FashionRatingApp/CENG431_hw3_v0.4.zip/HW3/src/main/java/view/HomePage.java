package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.*;

import models.Collection;
import models.Comment;
import models.Outfit;
import models.User;

public class HomePage {

	private User currentUser;
	private ArrayList<JButton> collectionNameButtons = new ArrayList<JButton>();
	private ArrayList<JButton> outfitButtons = new ArrayList<JButton>();
	private ArrayList<JButton> userNameButtons = new ArrayList<JButton>();
	private ArrayList<JButton> commentButtons = new ArrayList<JButton>();
	private ArrayList<JTextField> commentStrings = new ArrayList<JTextField>();
	private ArrayList<JButton> likeButtons = new ArrayList<JButton>();
	private ArrayList<JButton> dislikeButtons = new ArrayList<JButton>();
	private ArrayList<Outfit> allOutfits = new ArrayList<Outfit>();
	private ArrayList<User> shownUsers = new ArrayList<User>();
	private boolean initialized;
	private HomePage thisObject = this;

	public HomePage(User u) {
		currentUser = u;
		currentUser = new User("ibo", "23");
		User temp = new User("Caner", "123");
		User temp2 = new User("ege","321");
		User temp3 = new User("mert","213");
		User temp4 = new User("kaan","231");
		User temp5 = new User("tamer","132");
		Collection c = new Collection("Summer", 1);
		Collection c2 = new Collection("work",2);
		Outfit o = new Outfit(1, "T-shirt", "yazl�k", "M", "XL", "Red");
		o.addComment("�ok ii");
		Outfit o1 = new Outfit(2,"g�mlek", "i�", "S", "L", "Whites");
		o1.addComment("ben b�le bi�e g�rmemei�eem");
		c.addOutfit(o);
		c.addOutfit(o1);
		c.addOutfit(o);
		c.addOutfit(o1);
		c2.addOutfit(o1);
		c2.addOutfit(o);
		temp.addCollection(c);
		temp.addCollection(c2);
		temp2.addCollection(c);
		temp3.addCollection(c);
		temp4.addCollection(c);
		temp5.addCollection(c);
		currentUser.addFollowed(temp);
		currentUser.addFollowed(temp2);
		currentUser.addFollowed(temp3);
		currentUser.addFollowed(temp4);
		currentUser.addFollowed(temp5);

		initComponents();
		if (currentUser.getFollowedSize() == -23) {
			JLabel noFollowed = new JLabel("You have no followed users go to discover page.");
			noFollowed.setBounds(200, 300, 200, 40);
			noFollowed.setVisible(true);
			homePage.add(noFollowed);
		} else {
			init();
			initButtons();
			populateComponents();
		}
		homePage.setBackground(new java.awt.Color(153, 153, 255));
		homePage.setFocusable(false);
		initialized = true;
	}

	private ActionListener actionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			for (int i = 0; i < outfitButtons.size(); i++) {
				if (outfitButtons.get(i) == e.getSource()) {
					JOptionPane.showMessageDialog(null, e.getActionCommand());
				}
			}
			
			for (int i = 0; i < likeButtons.size(); i++) {
				if(likeButtons.get(i) == e.getSource()) {
					System.out.println();
					if(!allOutfits.get(i).addLike(currentUser)) {
						JOptionPane.showMessageDialog(null,"You already liked this outfit");
					}
					if(allOutfits.get(i).getUserDisliked().contains(currentUser)) {
						allOutfits.get(i).removeDislike(currentUser);
					}
					System.out.println("index "+i);
					System.out.println("likes: " + allOutfits.get(i).getNumberOfLikes());
					System.out.println("dislikes: " + allOutfits.get(i).getNumberOfDislikes());
					likeButtons.get(i).setEnabled(false);
					dislikeButtons.get(i).setEnabled(true);
					break;
				}
			}
			
			for (int i = 0; i < dislikeButtons.size(); i++) {
				if(dislikeButtons.get(i) == e.getSource()) {
					System.out.println();
					if(!allOutfits.get(i).addDislike(currentUser)) {
						JOptionPane.showMessageDialog(null,"You already disliked this outfit");
					}
					if(allOutfits.get(i).getUserLiked().contains(currentUser)) {
						allOutfits.get(i).removeLike(currentUser);
					}
					for (Outfit outfit : allOutfits) {
						if(outfit != null) {
							System.out.println(outfit.getNumberOfDislikes());
						}
						
					}
					System.out.println("index "+i);
					System.out.println("likes: " + allOutfits.get(i).getNumberOfLikes());
					System.out.println("dislikes: " + allOutfits.get(i).getNumberOfDislikes());
					dislikeButtons.get(i).setEnabled(false);
					likeButtons.get(i).setEnabled(true);
					break;
				}
			}
			
			for (int i = 0; i < commentButtons.size(); i++) {
				if(commentButtons.get(i) == e.getSource()) {
					allOutfits.get(i).addComment(commentStrings.get(i).getText());
					commentStrings.get(i).setText("");
				}
			}
			
			for (int i = 0; i < userNameButtons.size(); i++) {
				if(userNameButtons.get(i) == e.getSource()) {
					UserView userFrame = new UserView(thisObject,currentUser, shownUsers.get(i));
				}
			}
			populateComponents();
			homePage.revalidate();
			homePage.repaint();

		}
	};

	public void clear() {
		allOutfits.clear();
		shownUsers.clear();
	}
	
	public JPanel getHomePage() {
		return homePage;
	}
	
	private void initButtons() {
		outfitButtons.add(outfit1Hp);
		outfitButtons.add(outfit2Hp);
		outfitButtons.add(outfit3Hp);
		outfitButtons.add(outfit4Hp);
		outfitButtons.add(outfit5Hp);
		outfitButtons.add(outfit6Hp);
		outfitButtons.add(outfit7Hp);
		outfitButtons.add(outfit8Hp);
		outfitButtons.add(outfit9Hp);
		outfitButtons.add(outfit10Hp);
		outfitButtons.add(outfit11Hp);
		outfitButtons.add(outfit12Hp);
		outfitButtons.add(outfit13Hp);
		outfitButtons.add(outfit14Hp);
		outfitButtons.add(outfit15Hp);
		outfitButtons.add(outfit16Hp);
		outfitButtons.add(outfit17Hp);
		outfitButtons.add(outfit18Hp);
		outfitButtons.add(outfit19Hp);
		outfitButtons.add(outfit20Hp);
		outfitButtons.add(outfit21Hp);
		outfitButtons.add(outfit22Hp);
		outfitButtons.add(outfit23Hp);
		outfitButtons.add(outfit24Hp);
		userNameButtons.add(userName1Hp);
		userNameButtons.add(userName2Hp);
		userNameButtons.add(userName3Hp);
		userNameButtons.add(userName4Hp);
		collectionNameButtons.add(collectionName1Hp);
		collectionNameButtons.add(collectionName2Hp);
		collectionNameButtons.add(collectionName3Hp);
		collectionNameButtons.add(collectionName4Hp);
		commentButtons.add(enterComment1Hp);
		commentButtons.add(enterComment2Hp);
		commentButtons.add(enterComment3Hp);
		commentButtons.add(enterComment4Hp);
		commentButtons.add(enterComment5Hp);
		commentButtons.add(enterComment6Hp);
		commentButtons.add(enterComment7Hp);
		commentButtons.add(enterComment8Hp);
		commentButtons.add(enterComment9Hp);
		commentButtons.add(enterComment10Hp);
		commentButtons.add(enterComment11Hp);
		commentButtons.add(enterComment12Hp);
		commentButtons.add(enterComment13Hp);
		commentButtons.add(enterComment14Hp);
		commentButtons.add(enterComment15Hp);
		commentButtons.add(enterComment16Hp);
		commentButtons.add(enterComment17Hp);
		commentButtons.add(enterComment18Hp);
		commentButtons.add(enterComment19Hp);
		commentButtons.add(enterComment20Hp);
		commentButtons.add(enterComment21Hp);
		commentButtons.add(enterComment22Hp);
		commentButtons.add(enterComment23Hp);
		commentButtons.add(enterComment24Hp);
		commentStrings.add(comment1Hp);
		commentStrings.add(comment2Hp);
		commentStrings.add(comment3Hp);
		commentStrings.add(comment4Hp);
		commentStrings.add(comment5Hp);
		commentStrings.add(comment6Hp);
		commentStrings.add(comment7Hp);
		commentStrings.add(comment8Hp);
		commentStrings.add(comment9Hp);
		commentStrings.add(comment10Hp);
		commentStrings.add(comment11Hp);
		commentStrings.add(comment12Hp);
		commentStrings.add(comment13Hp);
		commentStrings.add(comment14Hp);
		commentStrings.add(comment15Hp);
		commentStrings.add(comment16Hp);
		commentStrings.add(comment17Hp);
		commentStrings.add(comment18Hp);
		commentStrings.add(comment19Hp);
		commentStrings.add(comment20Hp);
		commentStrings.add(comment21Hp);
		commentStrings.add(comment22Hp);
		commentStrings.add(comment23Hp);
		commentStrings.add(comment24Hp);
		likeButtons.add(like1Hp);
		likeButtons.add(like2Hp);
		likeButtons.add(like3Hp);
		likeButtons.add(like4Hp);
		likeButtons.add(like5Hp);
		likeButtons.add(like6Hp);
		likeButtons.add(like7Hp);
		likeButtons.add(like8Hp);
		likeButtons.add(like9Hp);
		likeButtons.add(like10Hp);
		likeButtons.add(like11Hp);
		likeButtons.add(like12Hp);
		likeButtons.add(like13Hp);
		likeButtons.add(like14Hp);
		likeButtons.add(like15Hp);
		likeButtons.add(like16Hp);
		likeButtons.add(like17Hp);
		likeButtons.add(like18Hp);
		likeButtons.add(like19Hp);
		likeButtons.add(like20Hp);
		likeButtons.add(like21Hp);
		likeButtons.add(like22Hp);
		likeButtons.add(like23Hp);
		likeButtons.add(like24Hp);
		dislikeButtons.add(dislike1Hp);
		dislikeButtons.add(dislike2Hp);
		dislikeButtons.add(dislike3Hp);
		dislikeButtons.add(dislike4Hp);
		dislikeButtons.add(dislike5Hp);
		dislikeButtons.add(dislike6Hp);
		dislikeButtons.add(dislike7Hp);
		dislikeButtons.add(dislike8Hp);
		dislikeButtons.add(dislike9Hp);
		dislikeButtons.add(dislike10Hp);
		dislikeButtons.add(dislike11Hp);
		dislikeButtons.add(dislike12Hp);
		dislikeButtons.add(dislike13Hp);
		dislikeButtons.add(dislike14Hp);
		dislikeButtons.add(dislike15Hp);
		dislikeButtons.add(dislike16Hp);
		dislikeButtons.add(dislike17Hp);
		dislikeButtons.add(dislike18Hp);
		dislikeButtons.add(dislike19Hp);
		dislikeButtons.add(dislike20Hp);
		dislikeButtons.add(dislike21Hp);
		dislikeButtons.add(dislike22Hp);
		dislikeButtons.add(dislike23Hp);
		dislikeButtons.add(dislike24Hp);

		
		for (int i = 0; i < likeButtons.size(); i++) {
			likeButtons.get(i).addActionListener(actionListener);
			dislikeButtons.get(i).addActionListener(actionListener);
			commentButtons.get(i).addActionListener(actionListener);
			likeButtons.get(i).setEnabled(false);
			dislikeButtons.get(i).setEnabled(false);
			commentButtons.get(i).setEnabled(false);
		}
		
		for (int i = 0; i < userNameButtons.size(); i++) {
			userNameButtons.get(i).addActionListener(actionListener);
			userNameButtons.get(i).setEnabled(false);
		}
	}
	
	public void populateComponents() {
		ArrayList<Collection> followedCollections = new ArrayList<Collection>();
		ArrayList<String> followedNames = new ArrayList<String>();
				
		for (int i = 0; i < userNameButtons.size(); i++) {
			shownUsers.add(null);
		}
		
		
		for (int i = 0; i < 24; i++) {
			allOutfits.add(null);
		}
		
		
		for (int i = 0; i < 4; i++) {
			
			if (i < currentUser.getFollowedSize()) {
				shownUsers.set(i, currentUser.getFollowed(i));
				for (int j = 0; j < currentUser.getFollowed(i).getCollectionSize(); j++) {
					followedNames.add(currentUser.getFollowed(i).getName());
					followedCollections.add(currentUser.getFollowed(i).getCollection(j));
				} 
			}else
				shownUsers.set(i, null);
		}

		for (int i = 0; i < 4; i++) {
			if (i < followedCollections.size()) {
				userNameButtons.get(i).setText(followedNames.get(i));
				userNameButtons.get(i).setEnabled(true);
				collectionNameButtons.get(i).setText(followedCollections.get(i).getName());
				for (int j = 0; j < followedCollections.get(i).size() && j < 6; j++) {
					Outfit temp = followedCollections.get(i).getOutfit(j);
					allOutfits.set((j) + (6 * i), temp);
					outfitButtons.get((j) + (6 * i)).setText(temp.getName());
					likeButtons.get((j) + (6 * i)).setEnabled(true);
					dislikeButtons.get((j) + (6 * i)).setEnabled(true);
					commentButtons.get((j) + (6 * i)).setEnabled(true);
					outfitButtons.get((j) + (6 * i)).setEnabled(true);
					commentStrings.get((j) + (6 * i)).setEnabled(true);
					String comments = "";
					for (int k = 0; k < temp.getCommentSize(); k++) {
						comments += "    " + temp.getComment(k) + "\n";
					}
					String actionString = "Gender: " + temp.getGender() + "\nType: " + temp.getClothingType()
							+ "\nColor: " + temp.getColor() + "\nSize: " + temp.getSize() + "\nLikes: "
							+ temp.getNumberOfLikes() + "   Dislikes: " + temp.getNumberOfDislikes() + "\nComments:\n"
							+ comments;

					outfitButtons.get((j) + (6 * i)).setActionCommand(actionString);
					if (!initialized) {
						outfitButtons.get((j) + (6 * i)).addActionListener(actionListener);
					}

				} 
			}else {
				userNameButtons.get(i).setText("");
				userNameButtons.get(i).setEnabled(false);
				collectionNameButtons.get(i).setText("");
				for (int j = 0; j < 6; j++) {
					allOutfits.set((j) + (6 * i), null);
					outfitButtons.get((j) + (6 * i)).setText("");
					likeButtons.get((j) + (6 * i)).setEnabled(false);
					dislikeButtons.get((j) + (6 * i)).setEnabled(false);
					commentButtons.get((j) + (6 * i)).setEnabled(false);
					outfitButtons.get((j) + (6 * i)).setEnabled(false);
					commentStrings.get((j) + (6 * i)).setEnabled(false);
				}
			}
		}
	}
	

	private javax.swing.JPanel collection1PaneHp;
	private javax.swing.JScrollPane collection1ScrollPaneHp;
	private javax.swing.JPanel collection2PaneHp;
	private javax.swing.JScrollPane collection2ScrollPaneHp;
	private javax.swing.JPanel collection3PaneHp;
	private javax.swing.JScrollPane collection3ScrollPaneHp;
	private javax.swing.JPanel collection4PaneHp;
	private javax.swing.JScrollPane collection4ScrollPaneHp;
	private javax.swing.JButton collectionName1Hp;
	private javax.swing.JButton collectionName2Hp;
	private javax.swing.JButton collectionName3Hp;
	private javax.swing.JButton collectionName4Hp;
	private javax.swing.JTextField comment10Hp;
	private javax.swing.JTextField comment11Hp;
	private javax.swing.JTextField comment12Hp;
	private javax.swing.JTextField comment13Hp;
	private javax.swing.JTextField comment14Hp;
	private javax.swing.JTextField comment15Hp;
	private javax.swing.JTextField comment16Hp;
	private javax.swing.JTextField comment17Hp;
	private javax.swing.JTextField comment18Hp;
	private javax.swing.JTextField comment19Hp;
	private javax.swing.JTextField comment1Hp;
	private javax.swing.JTextField comment20Hp;
	private javax.swing.JTextField comment21Hp;
	private javax.swing.JTextField comment22Hp;
	private javax.swing.JTextField comment23Hp;
	private javax.swing.JTextField comment24Hp;
	private javax.swing.JTextField comment2Hp;
	private javax.swing.JTextField comment3Hp;
	private javax.swing.JTextField comment4Hp;
	private javax.swing.JTextField comment5Hp;
	private javax.swing.JTextField comment6Hp;
	private javax.swing.JTextField comment7Hp;
	private javax.swing.JTextField comment8Hp;
	private javax.swing.JTextField comment9Hp;
	private javax.swing.JButton dislike10Hp;
	private javax.swing.JButton dislike11Hp;
	private javax.swing.JButton dislike12Hp;
	private javax.swing.JButton dislike13Hp;
	private javax.swing.JButton dislike14Hp;
	private javax.swing.JButton dislike15Hp;
	private javax.swing.JButton dislike16Hp;
	private javax.swing.JButton dislike17Hp;
	private javax.swing.JButton dislike18Hp;
	private javax.swing.JButton dislike19Hp;
	private javax.swing.JButton dislike1Hp;
	private javax.swing.JButton dislike20Hp;
	private javax.swing.JButton dislike21Hp;
	private javax.swing.JButton dislike22Hp;
	private javax.swing.JButton dislike23Hp;
	private javax.swing.JButton dislike24Hp;
	private javax.swing.JButton dislike2Hp;
	private javax.swing.JButton dislike3Hp;
	private javax.swing.JButton dislike4Hp;
	private javax.swing.JButton dislike5Hp;
	private javax.swing.JButton dislike6Hp;
	private javax.swing.JButton dislike7Hp;
	private javax.swing.JButton dislike8Hp;
	private javax.swing.JButton dislike9Hp;
	private javax.swing.JButton enterComment10Hp;
	private javax.swing.JButton enterComment11Hp;
	private javax.swing.JButton enterComment12Hp;
	private javax.swing.JButton enterComment13Hp;
	private javax.swing.JButton enterComment14Hp;
	private javax.swing.JButton enterComment15Hp;
	private javax.swing.JButton enterComment16Hp;
	private javax.swing.JButton enterComment17Hp;
	private javax.swing.JButton enterComment18Hp;
	private javax.swing.JButton enterComment19Hp;
	private javax.swing.JButton enterComment1Hp;
	private javax.swing.JButton enterComment20Hp;
	private javax.swing.JButton enterComment21Hp;
	private javax.swing.JButton enterComment22Hp;
	private javax.swing.JButton enterComment23Hp;
	private javax.swing.JButton enterComment24Hp;
	private javax.swing.JButton enterComment2Hp;
	private javax.swing.JButton enterComment3Hp;
	private javax.swing.JButton enterComment4Hp;
	private javax.swing.JButton enterComment5Hp;
	private javax.swing.JButton enterComment6Hp;
	private javax.swing.JButton enterComment7Hp;
	private javax.swing.JButton enterComment8Hp;
	private javax.swing.JButton enterComment9Hp;
	private JPanel homePage;
	private javax.swing.JButton like10Hp;
	private javax.swing.JButton like11Hp;
	private javax.swing.JButton like12Hp;
	private javax.swing.JButton like13Hp;
	private javax.swing.JButton like14Hp;
	private javax.swing.JButton like15Hp;
	private javax.swing.JButton like16Hp;
	private javax.swing.JButton like17Hp;
	private javax.swing.JButton like18Hp;
	private javax.swing.JButton like19Hp;
	private javax.swing.JButton like1Hp;
	private javax.swing.JButton like20Hp;
	private javax.swing.JButton like21Hp;
	private javax.swing.JButton like22Hp;
	private javax.swing.JButton like23Hp;
	private javax.swing.JButton like24Hp;
	private javax.swing.JButton like2Hp;
	private javax.swing.JButton like3Hp;
	private javax.swing.JButton like4Hp;
	private javax.swing.JButton like5Hp;
	private javax.swing.JButton like6Hp;
	private javax.swing.JButton like7Hp;
	private javax.swing.JButton like8Hp;
	private javax.swing.JButton like9Hp;
	private javax.swing.JButton outfit10Hp;
	private javax.swing.JButton outfit11Hp;
	private javax.swing.JButton outfit12Hp;
	private javax.swing.JButton outfit13Hp;
	private javax.swing.JButton outfit14Hp;
	private javax.swing.JButton outfit15Hp;
	private javax.swing.JButton outfit16Hp;
	private javax.swing.JButton outfit17Hp;
	private javax.swing.JButton outfit18Hp;
	private javax.swing.JButton outfit19Hp;
	private javax.swing.JButton outfit1Hp;
	private javax.swing.JButton outfit20Hp;
	private javax.swing.JButton outfit21Hp;
	private javax.swing.JButton outfit22Hp;
	private javax.swing.JButton outfit23Hp;
	private javax.swing.JButton outfit24Hp;
	private javax.swing.JButton outfit2Hp;
	private javax.swing.JButton outfit3Hp;
	private javax.swing.JButton outfit4Hp;
	private javax.swing.JButton outfit5Hp;
	private javax.swing.JButton outfit6Hp;
	private javax.swing.JButton outfit7Hp;
	private javax.swing.JButton outfit8Hp;
	private javax.swing.JButton outfit9Hp;
	private javax.swing.JButton userName1Hp;
	private javax.swing.JButton userName2Hp;
	private javax.swing.JButton userName3Hp;
	private javax.swing.JButton userName4Hp;

	private void initComponents() {
		homePage = new javax.swing.JPanel();
		collection1ScrollPaneHp = new javax.swing.JScrollPane();
		collection1PaneHp = new javax.swing.JPanel();
		comment1Hp = new javax.swing.JTextField();
		outfit1Hp = new javax.swing.JButton();
		enterComment1Hp = new javax.swing.JButton();
		like1Hp = new javax.swing.JButton();
		dislike1Hp = new javax.swing.JButton();
		outfit2Hp = new javax.swing.JButton();
		comment2Hp = new javax.swing.JTextField();
		enterComment2Hp = new javax.swing.JButton();
		like2Hp = new javax.swing.JButton();
		dislike2Hp = new javax.swing.JButton();
		outfit3Hp = new javax.swing.JButton();
		comment3Hp = new javax.swing.JTextField();
		enterComment3Hp = new javax.swing.JButton();
		like3Hp = new javax.swing.JButton();
		dislike3Hp = new javax.swing.JButton();
		outfit4Hp = new javax.swing.JButton();
		comment4Hp = new javax.swing.JTextField();
		enterComment4Hp = new javax.swing.JButton();
		like4Hp = new javax.swing.JButton();
		dislike4Hp = new javax.swing.JButton();
		outfit5Hp = new javax.swing.JButton();
		comment5Hp = new javax.swing.JTextField();
		enterComment5Hp = new javax.swing.JButton();
		like5Hp = new javax.swing.JButton();
		dislike5Hp = new javax.swing.JButton();
		outfit6Hp = new javax.swing.JButton();
		comment6Hp = new javax.swing.JTextField();
		enterComment6Hp = new javax.swing.JButton();
		like6Hp = new javax.swing.JButton();
		dislike6Hp = new javax.swing.JButton();
		userName1Hp = new javax.swing.JButton();
		collectionName1Hp = new javax.swing.JButton();
		collectionName2Hp = new javax.swing.JButton();
		userName2Hp = new javax.swing.JButton();
		userName3Hp = new javax.swing.JButton();
		collectionName3Hp = new javax.swing.JButton();
		collectionName4Hp = new javax.swing.JButton();
		userName4Hp = new javax.swing.JButton();
		collection3ScrollPaneHp = new javax.swing.JScrollPane();
		collection3PaneHp = new javax.swing.JPanel();
		comment13Hp = new javax.swing.JTextField();
		outfit13Hp = new javax.swing.JButton();
		enterComment13Hp = new javax.swing.JButton();
		like13Hp = new javax.swing.JButton();
		dislike13Hp = new javax.swing.JButton();
		outfit14Hp = new javax.swing.JButton();
		comment14Hp = new javax.swing.JTextField();
		like14Hp = new javax.swing.JButton();
		dislike14Hp = new javax.swing.JButton();
		outfit15Hp = new javax.swing.JButton();
		comment15Hp = new javax.swing.JTextField();
		like15Hp = new javax.swing.JButton();
		dislike15Hp = new javax.swing.JButton();
		outfit16Hp = new javax.swing.JButton();
		comment16Hp = new javax.swing.JTextField();
		like16Hp = new javax.swing.JButton();
		dislike16Hp = new javax.swing.JButton();
		outfit17Hp = new javax.swing.JButton();
		comment17Hp = new javax.swing.JTextField();
		like17Hp = new javax.swing.JButton();
		dislike17Hp = new javax.swing.JButton();
		outfit18Hp = new javax.swing.JButton();
		comment18Hp = new javax.swing.JTextField();
		like18Hp = new javax.swing.JButton();
		dislike18Hp = new javax.swing.JButton();
		enterComment14Hp = new javax.swing.JButton();
		enterComment15Hp = new javax.swing.JButton();
		enterComment16Hp = new javax.swing.JButton();
		enterComment17Hp = new javax.swing.JButton();
		enterComment18Hp = new javax.swing.JButton();
		collection2ScrollPaneHp = new javax.swing.JScrollPane();
		collection2PaneHp = new javax.swing.JPanel();
		comment7Hp = new javax.swing.JTextField();
		outfit7Hp = new javax.swing.JButton();
		enterComment7Hp = new javax.swing.JButton();
		like7Hp = new javax.swing.JButton();
		dislike7Hp = new javax.swing.JButton();
		outfit8Hp = new javax.swing.JButton();
		comment8Hp = new javax.swing.JTextField();
		enterComment8Hp = new javax.swing.JButton();
		like8Hp = new javax.swing.JButton();
		dislike8Hp = new javax.swing.JButton();
		outfit9Hp = new javax.swing.JButton();
		comment9Hp = new javax.swing.JTextField();
		enterComment9Hp = new javax.swing.JButton();
		like9Hp = new javax.swing.JButton();
		dislike9Hp = new javax.swing.JButton();
		outfit10Hp = new javax.swing.JButton();
		comment10Hp = new javax.swing.JTextField();
		enterComment10Hp = new javax.swing.JButton();
		like10Hp = new javax.swing.JButton();
		dislike10Hp = new javax.swing.JButton();
		outfit11Hp = new javax.swing.JButton();
		comment11Hp = new javax.swing.JTextField();
		enterComment11Hp = new javax.swing.JButton();
		like11Hp = new javax.swing.JButton();
		dislike11Hp = new javax.swing.JButton();
		outfit12Hp = new javax.swing.JButton();
		comment12Hp = new javax.swing.JTextField();
		enterComment12Hp = new javax.swing.JButton();
		like12Hp = new javax.swing.JButton();
		dislike12Hp = new javax.swing.JButton();
		collection4ScrollPaneHp = new javax.swing.JScrollPane();
		collection4PaneHp = new javax.swing.JPanel();
		comment19Hp = new javax.swing.JTextField();
		outfit19Hp = new javax.swing.JButton();
		enterComment19Hp = new javax.swing.JButton();
		like19Hp = new javax.swing.JButton();
		dislike19Hp = new javax.swing.JButton();
		outfit20Hp = new javax.swing.JButton();
		comment20Hp = new javax.swing.JTextField();
		enterComment20Hp = new javax.swing.JButton();
		like20Hp = new javax.swing.JButton();
		dislike20Hp = new javax.swing.JButton();
		outfit21Hp = new javax.swing.JButton();
		comment21Hp = new javax.swing.JTextField();
		enterComment21Hp = new javax.swing.JButton();
		like21Hp = new javax.swing.JButton();
		dislike21Hp = new javax.swing.JButton();
		outfit22Hp = new javax.swing.JButton();
		comment22Hp = new javax.swing.JTextField();
		enterComment22Hp = new javax.swing.JButton();
		like22Hp = new javax.swing.JButton();
		dislike22Hp = new javax.swing.JButton();
		outfit23Hp = new javax.swing.JButton();
		comment23Hp = new javax.swing.JTextField();
		enterComment23Hp = new javax.swing.JButton();
		like23Hp = new javax.swing.JButton();
		dislike23Hp = new javax.swing.JButton();
		outfit24Hp = new javax.swing.JButton();
		comment24Hp = new javax.swing.JTextField();
		enterComment24Hp = new javax.swing.JButton();
		like24Hp = new javax.swing.JButton();
		dislike24Hp = new javax.swing.JButton();

	}

	
	private void init() {
		javax.swing.GroupLayout homePageLayout = new javax.swing.GroupLayout(homePage);
		homePage.setLayout(homePageLayout);
		homePageLayout.setHorizontalGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(homePageLayout.createSequentialGroup().addGap(67, 67, 67).addGroup(homePageLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(homePageLayout.createSequentialGroup()
								.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(userName1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(collectionName1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(collectionName2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(userName2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGroup(homePageLayout.createSequentialGroup().addGroup(homePageLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
								.addComponent(collectionName3Hp, javax.swing.GroupLayout.DEFAULT_SIZE, 156,
										Short.MAX_VALUE)
								.addComponent(userName3Hp, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(collectionName4Hp, javax.swing.GroupLayout.Alignment.TRAILING,
												javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(userName4Hp, javax.swing.GroupLayout.Alignment.TRAILING,
												javax.swing.GroupLayout.PREFERRED_SIZE, 156,
												javax.swing.GroupLayout.PREFERRED_SIZE))))
						.addGap(91, 91, 91))
				.addGroup(homePageLayout.createSequentialGroup().addGap(20, 20, 20)
						.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(homePageLayout.createSequentialGroup()
										.addComponent(collection3ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32,
												Short.MAX_VALUE)
										.addComponent(collection4ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(homePageLayout.createSequentialGroup()
										.addComponent(collection1ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(collection2ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE,
												270, javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGap(35, 35, 35)));
		homePageLayout.setVerticalGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(homePageLayout.createSequentialGroup().addContainerGap()
						.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(userName1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(userName2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(collectionName2Hp, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(collectionName1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(collection1ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(collection2ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
						.addGroup(homePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, homePageLayout
										.createSequentialGroup()
										.addGroup(homePageLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(userName3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(userName4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(homePageLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(collectionName3Hp,
														javax.swing.GroupLayout.Alignment.TRAILING,
														javax.swing.GroupLayout.PREFERRED_SIZE, 20,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(collectionName4Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														20, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(collection3ScrollPaneHp, javax.swing.GroupLayout.PREFERRED_SIZE,
												117, javax.swing.GroupLayout.PREFERRED_SIZE))
								.addComponent(collection4ScrollPaneHp, javax.swing.GroupLayout.Alignment.TRAILING,
										javax.swing.GroupLayout.PREFERRED_SIZE, 117,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));
		comment1Hp.setText("Comment1");
		

		outfit1Hp.setText("Outfit1");

		enterComment1Hp.setText("jButton16");

		like1Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike1Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit2Hp.setText("Outfit 2");

		comment2Hp.setText("Comment2");
		

		enterComment2Hp.setText("jButton16");

		like2Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike2Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit3Hp.setText("Outfit 3");

		comment3Hp.setText("Comment3");
		

		enterComment3Hp.setText("jButton16");

		like3Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike3Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit4Hp.setText("Outfit 4");

		comment4Hp.setText("Comment4");
		

		enterComment4Hp.setText("jButton16");

		like4Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike4Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit5Hp.setText("Outfit 5");

		comment5Hp.setText("Comment5");
		

		enterComment5Hp.setText("jButton16");

		like5Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike5Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		
		
		outfit6Hp.setText("Outfit 6");

		comment6Hp.setText("Comment6");
		

		enterComment6Hp.setText("jButton16");

		like6Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike6Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		javax.swing.GroupLayout collection1PaneHpLayout = new javax.swing.GroupLayout(collection1PaneHp);
		collection1PaneHp.setLayout(collection1PaneHpLayout);
		collection1PaneHpLayout.setHorizontalGroup(collection1PaneHpLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection1PaneHpLayout.createSequentialGroup()
						.addGroup(collection1PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(comment1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(outfit6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(like6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(dislike6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(comment6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection1PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(enterComment1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(242, 242, 242)));
		collection1PaneHpLayout.setVerticalGroup(collection1PaneHpLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection1PaneHpLayout.createSequentialGroup().addGap(1, 1, 1)
						.addGroup(collection1PaneHpLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike1Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit1Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like1Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment1Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment1Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike2Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit2Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like2Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment2Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment2Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike3Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit3Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like3Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment3Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment3Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike4Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit4Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like4Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(comment4Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment4Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 19,
																javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit5Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like5Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(comment5Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(collection1PaneHpLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(dislike6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGroup(collection1PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(outfit6Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(like6Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
																22, javax.swing.GroupLayout.PREFERRED_SIZE))
												.addComponent(comment6Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGroup(collection1PaneHpLayout.createSequentialGroup()
										.addComponent(enterComment5Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(enterComment6Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(1, 1, 1)))
						.addContainerGap()));

		collection1ScrollPaneHp.setViewportView(collection1PaneHp);

		userName1Hp.setText("User Name 1");

		collectionName1Hp.setText("Collection Name 1");

		collectionName2Hp.setText("Collection Name 2");

		userName2Hp.setText("User Name2");

		userName3Hp.setText("User Name 3");

		collectionName3Hp.setText("Collection Name 3");

		collectionName4Hp.setText("Collection Name 4");

		userName4Hp.setText("User Name 4");

		collection3ScrollPaneHp.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection3ScrollPaneHp
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection3ScrollPaneHp.setToolTipText("");
		collection3ScrollPaneHp.setRequestFocusEnabled(false);

		collection3PaneHp.setPreferredSize(new java.awt.Dimension(425, 200));

		comment13Hp.setText("Comment13");
		

		outfit13Hp.setText("Outfit13");

		enterComment13Hp.setText("jButton16");

		like13Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike13Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit14Hp.setText("Outfit14");

		comment14Hp.setText("Comment14");
		

		like14Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike14Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit15Hp.setText("Outfit15");

		comment15Hp.setText("Comment15");
		

		like15Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike15Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit16Hp.setText("Outfit16");

		comment16Hp.setText("Comment16");
		

		like16Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike16Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit17Hp.setText("Outfit 17");

		comment17Hp.setText("Comment17");
		

		like17Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike17Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit18Hp.setText("Outfit 18");

		comment18Hp.setText("Comment18");
		

		like18Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike18Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		
		enterComment14Hp.setText("jButton16");

		enterComment15Hp.setText("jButton16");

		enterComment16Hp.setText("jButton16");

		enterComment17Hp.setText("jButton16");

		enterComment18Hp.setText("jButton16");

		javax.swing.GroupLayout collection3PaneHpLayout = new javax.swing.GroupLayout(collection3PaneHp);
		collection3PaneHp.setLayout(collection3PaneHpLayout);
		collection3PaneHpLayout.setHorizontalGroup(
				collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection3PaneHpLayout.createSequentialGroup()
								.addComponent(outfit13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(242, 242, 242))
						.addGroup(collection3PaneHpLayout.createSequentialGroup()
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection3PaneHpLayout.createSequentialGroup()
												.addComponent(outfit14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment14Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneHpLayout.createSequentialGroup()
												.addComponent(outfit15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment15Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneHpLayout.createSequentialGroup()
												.addComponent(outfit18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 65,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment18Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection3PaneHpLayout.createSequentialGroup()
												.addGroup(collection3PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addGroup(collection3PaneHpLayout
																.createSequentialGroup()
																.addComponent(outfit16Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 99,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(like16Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(dislike16Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		comment16Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 65,
																		javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(collection3PaneHpLayout.createSequentialGroup()
																.addComponent(outfit17Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 99,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(like17Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(dislike17Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 22,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(comment17Hp,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 65,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addGroup(collection3PaneHpLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(enterComment17Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 17,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(enterComment16Hp,
																javax.swing.GroupLayout.PREFERRED_SIZE, 17,
																javax.swing.GroupLayout.PREFERRED_SIZE))))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection3PaneHpLayout.setVerticalGroup(collection3PaneHpLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection3PaneHpLayout.createSequentialGroup().addGroup(collection3PaneHpLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection3PaneHpLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment13Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment13Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment14Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment14Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment15Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment15Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike16Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit16Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like16Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment16Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment16Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike17Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit17Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like17Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment17Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment17Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection3PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection3PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment18Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment18Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 19,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection3ScrollPaneHp.setViewportView(collection3PaneHp);

		collection2ScrollPaneHp.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection2ScrollPaneHp
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection2ScrollPaneHp.setToolTipText("");
		collection2ScrollPaneHp.setRequestFocusEnabled(false);

		collection2PaneHp.setPreferredSize(new java.awt.Dimension(425, 200));

		comment7Hp.setText("Comment7");
		

		outfit7Hp.setText("Outfit7");

		enterComment7Hp.setText("jButton16");

		like7Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike7Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N

		outfit8Hp.setText("Outfit8");

		comment8Hp.setText("Comment8");
		

		enterComment8Hp.setText("jButton16");

		like8Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike8Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit9Hp.setText("Outfit9");

		comment9Hp.setText("Comment9");
		

		enterComment9Hp.setText("jButton16");

		like9Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike9Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit10Hp.setText("Outfit10");

		comment10Hp.setText("Comment10");
		

		enterComment10Hp.setText("jButton16");

		like10Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike10Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit11Hp.setText("Outfit 11");

		comment11Hp.setText("Comment11");
		

		enterComment11Hp.setText("jButton16");

		like11Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike11Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit12Hp.setText("Outfit 12");

		comment12Hp.setText("Comment12");
		

		enterComment12Hp.setText("jButton16");

		like12Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike12Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		javax.swing.GroupLayout collection2PaneHpLayout = new javax.swing.GroupLayout(collection2PaneHp);
		collection2PaneHp.setLayout(collection2PaneHpLayout);
		collection2PaneHpLayout.setHorizontalGroup(
				collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection2PaneHpLayout.createSequentialGroup()
								.addComponent(outfit7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(242, 242, 242))
						.addGroup(collection2PaneHpLayout.createSequentialGroup()
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection2PaneHpLayout.createSequentialGroup()
												.addComponent(outfit8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment8Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneHpLayout.createSequentialGroup()
												.addComponent(outfit9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment9Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneHpLayout.createSequentialGroup()
												.addComponent(outfit10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment10Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneHpLayout.createSequentialGroup()
												.addComponent(outfit11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment11Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection2PaneHpLayout.createSequentialGroup()
												.addComponent(outfit12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment12Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection2PaneHpLayout.setVerticalGroup(collection2PaneHpLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection2PaneHpLayout.createSequentialGroup().addGroup(collection2PaneHpLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection2PaneHpLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment7Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment7Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment8Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment8Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment9Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment9Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment10Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment10Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment11Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment11Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection2PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection2PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment12Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment12Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection2ScrollPaneHp.setViewportView(collection2PaneHp);

		collection4ScrollPaneHp.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection4ScrollPaneHp
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection4ScrollPaneHp.setToolTipText("");
		collection4ScrollPaneHp.setRequestFocusEnabled(false);

		collection4PaneHp.setPreferredSize(new java.awt.Dimension(425, 200));

		comment19Hp.setText("Comment19");
		
		outfit19Hp.setText("Outfit19");

		enterComment19Hp.setText("jButton16");

		like19Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike19Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
	

		outfit20Hp.setText("Outfit20");

		comment20Hp.setText("Comment20");
		

		enterComment20Hp.setText("jButton16");

		like20Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike20Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit21Hp.setText("Outfit21");

		comment21Hp.setText("Comment21");
		

		enterComment21Hp.setText("jButton16");

		like21Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike21Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit22Hp.setText("Outfit22");

		comment22Hp.setText("Comment22");
		

		enterComment22Hp.setText("jButton16");

		like22Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike22Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit23Hp.setText("Outfit 23");

		comment23Hp.setText("Comment23");
		

		enterComment23Hp.setText("jButton16");

		like23Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike23Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		outfit24Hp.setText("Outfit 24");

		comment24Hp.setText("");
		

		enterComment24Hp.setText("jButton16");

		like24Hp.setIcon(new javax.swing.ImageIcon("like.png")); // NOI18N

		dislike24Hp.setIcon(new javax.swing.ImageIcon("dislike.png")); // NOI18N
		

		javax.swing.GroupLayout collection4PaneHpLayout = new javax.swing.GroupLayout(collection4PaneHp);
		collection4PaneHp.setLayout(collection4PaneHpLayout);
		collection4PaneHpLayout.setHorizontalGroup(
				collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(collection4PaneHpLayout.createSequentialGroup()
								.addComponent(outfit19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(like19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(dislike19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(comment19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(enterComment19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 17,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(238, 238, 238))
						.addGroup(collection4PaneHpLayout.createSequentialGroup()
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(collection4PaneHpLayout.createSequentialGroup()
												.addComponent(outfit20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment20Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneHpLayout.createSequentialGroup()
												.addComponent(outfit21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment21Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneHpLayout.createSequentialGroup()
												.addComponent(outfit22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment22Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneHpLayout.createSequentialGroup()
												.addComponent(outfit23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment23Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(collection4PaneHpLayout.createSequentialGroup()
												.addComponent(outfit24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 99,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(like24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(dislike24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(comment24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 58,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(enterComment24Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
														17, javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		collection4PaneHpLayout.setVerticalGroup(collection4PaneHpLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(collection4PaneHpLayout.createSequentialGroup().addGroup(collection4PaneHpLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(dislike19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(
								collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGroup(collection4PaneHpLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(comment19Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(enterComment19Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment20Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment20Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment21Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment21Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment22Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment22Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment23Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment23Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(collection4PaneHpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(dislike24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(outfit24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(like24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(collection4PaneHpLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(comment24Hp, javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(enterComment24Hp, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap()));

		collection4ScrollPaneHp.setViewportView(collection4PaneHp);

		collection1ScrollPaneHp.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED,
				java.awt.Color.darkGray, java.awt.Color.green, null, null));
		collection1ScrollPaneHp
				.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		collection1ScrollPaneHp.setToolTipText("");
		collection1ScrollPaneHp.setRequestFocusEnabled(false);
		collection1PaneHp.setPreferredSize(new java.awt.Dimension(425, 200));

	}

}
