package view;

import javax.swing.JPanel;

import models.User;

public class StatisticsPage {
	
	User currentUser;
	
	public StatisticsPage(User currentUser) {
		this.currentUser = currentUser;
		initComponents();
		init();
	}
	
	private void initComponents() {
		statisctics = new javax.swing.JPanel();
	    paneSt = new javax.swing.JPanel();
	    mostLikedOutfitSt = new javax.swing.JRadioButton();
	    mostDislikedSt = new javax.swing.JRadioButton();
	    mostFollowedSt = new javax.swing.JRadioButton();
	}

	public JPanel getStatisticsPage() {
		return paneSt;
	}
   

	private javax.swing.JRadioButton mostDislikedSt;
    private javax.swing.JRadioButton mostFollowedSt;
    private javax.swing.JRadioButton mostLikedOutfitSt;
    private javax.swing.JPanel paneSt;
    private javax.swing.JPanel statisctics;
    
    private void init() {
    	paneSt.setBackground(new java.awt.Color(153, 153, 255));

        mostLikedOutfitSt.setBackground(new java.awt.Color(153, 153, 255));
        mostLikedOutfitSt.setText("MOST LIKED OUTFIT");

        mostDislikedSt.setBackground(new java.awt.Color(153, 153, 255));
        mostDislikedSt.setText("MOST DISLIKED OUTFIT");

        mostFollowedSt.setBackground(new java.awt.Color(153, 153, 255));
        mostFollowedSt.setText("MOST FOLLOWED USER");

        javax.swing.GroupLayout paneStLayout = new javax.swing.GroupLayout(paneSt);
        paneSt.setLayout(paneStLayout);
        paneStLayout.setHorizontalGroup(
            paneStLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneStLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(paneStLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mostFollowedSt, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(paneStLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(mostDislikedSt, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                        .addComponent(mostLikedOutfitSt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(368, Short.MAX_VALUE))
        );
        paneStLayout.setVerticalGroup(
            paneStLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneStLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(mostLikedOutfitSt, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(mostDislikedSt, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(mostFollowedSt, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout statiscticsLayout = new javax.swing.GroupLayout(statisctics);
        statisctics.setLayout(statiscticsLayout);
        statiscticsLayout.setHorizontalGroup(
            statiscticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 627, Short.MAX_VALUE)
            .addGroup(statiscticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(statiscticsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(paneSt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        statiscticsLayout.setVerticalGroup(
            statiscticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 409, Short.MAX_VALUE)
            .addGroup(statiscticsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(statiscticsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(paneSt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
		
	}
}
