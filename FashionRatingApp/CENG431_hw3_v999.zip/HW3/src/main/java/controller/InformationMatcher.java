package controller;

import java.util.ArrayList;
import java.util.List;

import models.Collection;
import models.User;

public class InformationMatcher {

	
	private static List<User> allUsers = new ArrayList<User>();
	private static List<Collection> allCollections = new ArrayList<Collection>();
	
	public static void setAllUsers(List<User> users) {
		for (User user : users) {
			allUsers.add(user);
		}
	}
	
	public static void setAllCollection(List<Collection> collections) {
		for (Collection collection : collections) {
			allCollections.add(collection);
		}
	}

	public static List<User> getAllUsers(){
		return allUsers;
	}
	
	public static List<Collection> getAllCollections(){
		return allCollections;
	}
	
	public static User getFollowed(User curr, int i) {
		for (User user : allUsers) {
			if(curr.getFollowed(i).equals(user.getName())) {
				return user;
			}
		}
		return null;
	}
	
	public static Collection getCollection(User curr, int i) {
		for(Collection c : allCollections) {
			if(curr.getCollection(i) == c.getCollectionID()) {
				return c;
			}
		}
		return null;
	}
	
	public static User getFollower(User curr, int i) {
		for (User user : allUsers) {
			if(curr.getFollower(i).equals(user.getName())) {
				return user;
			}
		}
		return null;
	}
	
}
