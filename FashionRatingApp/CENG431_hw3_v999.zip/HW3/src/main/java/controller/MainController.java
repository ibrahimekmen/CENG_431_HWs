package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import models.Collection;
import models.User;
import view.LoginView;

public class MainController {

	private static List<User> allUsers;
	private static List<Collection> allCollections;
	
	public static void init() {
		read();
		initGeneratedNumbers();
		login();
	}
	
	public static void initGeneratedNumbers() {
		List<Integer> generatedOutfitIDs = new ArrayList<Integer>();
		for (int i = 0; i < allCollections.size(); i++) {
			for (int j = 0; j < allCollections.get(i).size(); j++) {
				generatedOutfitIDs.add(allCollections.get(i).getOutfit(j).getOutfitID());
			}
		}
		List<Integer> generatedCollectionIDs = new ArrayList<Integer>();
		for (int i = 0; i < allCollections.size(); i++) {
			generatedCollectionIDs.add(allCollections.get(i).getCollectionID());
		}
		Generator.initCollectionID(generatedCollectionIDs);
		Generator.initOutfitID(generatedOutfitIDs);
		
	}

	public static void read() {
		allUsers = FileIO.readUsers();
		allCollections = FileIO.readOutfits();
	}
	
	public static void login() {
		LoginView login = new LoginView();
	}
	
	public static void write(){
		FileIO.writeOutfits(InformationMatcher.getAllCollections());
		FileIO.writeUsers(InformationMatcher.getAllUsers());
	}
}
