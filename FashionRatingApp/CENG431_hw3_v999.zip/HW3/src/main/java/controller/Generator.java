package controller;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Generator {
	
	private static List<Integer> generatedCollectionID = new LinkedList<Integer>();
	private static List<Integer> generatedOutfitID = new LinkedList<Integer>();
	
	
	
	public static void initCollectionID(List<Integer> generatedNumber) {
		for (int i = 0; i < generatedNumber.size(); i++) {
			generatedCollectionID.add(generatedNumber.get(i));	
		}
	}
	
	public static void initOutfitID(List<Integer> generatedNumber) {
		for (int i = 0; i < generatedNumber.size(); i++) {
			generatedOutfitID.add(generatedNumber.get(i));
		}
	}

	public static int generateCollectionID() {
		Random rand = new Random();
		int currentNumber;
		int maxLimit = 1000;
	
		currentNumber = rand.nextInt(maxLimit) + 1;
		if(generatedCollectionID.isEmpty()) {
			generatedCollectionID.add(currentNumber);
		}else {
			while(generatedCollectionID.contains(currentNumber)) {
				currentNumber = rand.nextInt(maxLimit) + 1;
			}
			generatedCollectionID.add(currentNumber);
		}
		return currentNumber;
	}
	
	public static int generateOutfitID() {
		Random rand = new Random();
		int currentNumber;
		int maxLimit = 1000;
	
		currentNumber = rand.nextInt(maxLimit) + 1;
		if(generatedOutfitID.isEmpty()) {
			generatedOutfitID.add(currentNumber);
		}else {
			while(generatedOutfitID.contains(currentNumber)) {
				currentNumber = rand.nextInt(maxLimit) + 1;
			}
			generatedOutfitID.add(currentNumber);
		}
		return currentNumber;
	}
}
