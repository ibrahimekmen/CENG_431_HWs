package models;

import java.util.ArrayList;
import java.util.List;

public class Outfit {

	private int outfitID;
	private String name;
	private String clothingType;
	private String occasion;
	private String gender;
	private String size;
	private String color;
	private List<String> comments;
	private List<String> userLiked; // holding user names that liked this outfit
	private List<String> userDisliked;// holding user names that disliked this outfit
 	
	
	public Outfit(int outfitID, String name, String clothingType,String occasion, String gender, String size, String color) {
		this.outfitID = outfitID;
		this.name = name;
		this.clothingType = clothingType;
		this.occasion = occasion;
		this.gender = gender;
		this.size = size;
		this.color = color;
		userLiked = new ArrayList<String>();
		userDisliked = new ArrayList<String>();
		comments = new ArrayList<String>();
	}
	
	
	public String getOccasion() {
		return occasion;
	}


	public int getCommentSize() {
		return comments.size();
	}
	
	public void addComment(String text) {
		comments.add(text);
	}
	
	public String getComment(int i) {
		return comments.get(i);
	}

	
	
	public boolean addLike(User u) {
		if(!(userLiked.contains(u.getName()))) {
			userLiked.add(u.getName());
			return true;
		}else
			return false;
	}
	
	public boolean addDislike(User u) {
		if(!(userDisliked.contains(u.getName()))) {
			userDisliked.add(u.getName());
			return true;
		}else
			return false;
	}
	
	public boolean removeDislike(User u) {
		if(userDisliked.contains(u.getName())) {
			userDisliked.remove(u.getName());
			return true;
		}else
			return false;
	}
	
	public boolean removeLike(User u) {
		if(userLiked.contains(u.getName())) {
			userLiked.remove(u.getName());
			return true;
		}else
			return false;
	}
	
	
	
	public int getOutfitID() {
		return outfitID;
	}


	public String getName() {
		return name;
	}


	public String getClothingType() {
		return clothingType;
	}


	public String getGender() {
		return gender;
	}


	public String getSize() {
		return size;
	}


	public String getColor() {
		return color;
	}


	public int getNumberOfLikes() {
		int result = userLiked.size();
		return result;
	}


	public int getNumberOfDislikes() {
		int result = userDisliked.size();
		return result;
	}
	
	public List<String> getUserLiked() {
		return userLiked;
	}

	public List<String> getUserDisliked() {
		return userDisliked;
	}
	
	
}
