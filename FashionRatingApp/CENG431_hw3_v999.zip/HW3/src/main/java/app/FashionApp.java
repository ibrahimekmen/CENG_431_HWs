package app;

import controller.MainController;

public class FashionApp {
	public static void main(String args[]) {
		MainController.init();
	}
}
