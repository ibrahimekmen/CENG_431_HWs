package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;

import javax.swing.*;
import javax.swing.border.*;

import controller.Generator;
import controller.InformationMatcher;
import models.Collection;
import models.Outfit;
import models.User;

public class ProfilePage {
	
	User currentUser;
	Collection collectionToEdit;
	public ProfilePage(User currentUser) {
		this.currentUser = currentUser;

		initComponents();
		setValues();
		init();
	}
	
	
	MouseListener mouseListener = new MouseAdapter() {
	    public void mouseClicked(MouseEvent e) {
	        if(e.getSource() == collectionListPp && e.getClickCount() == 2) {
	        	String selectedItem = (String) collectionListPp.getSelectedValue();
	        	for(int i = 0; i < currentUser.getCollectionSize(); i++) {
					if(selectedItem.equals(InformationMatcher.getCollection(currentUser, i).getName())) {
						if(e.getClickCount() == 2) {
							String allOutfits[] = new String[InformationMatcher.getCollection(currentUser, i).size()]; 
							for (int j = 0; j < InformationMatcher.getCollection(currentUser, i).size(); j++) {
								
								Outfit temp = InformationMatcher.getCollection(currentUser, i).getOutfit(j);
								String comments = "";
								for (int k = 0; k < temp.getCommentSize() && k < 5; k++) {
									comments += "    " + temp.getComment(k) + "\n";
								}
								String outfitInfo = "Name: " + temp.getName() + " Gender: " + temp.getGender() + " Type: "
										+ temp.getClothingType() + " Occasion: " + temp.getOccasion() +" Color: " + temp.getColor() + " Size: "
										+ temp.getSize() + " Likes: " + temp.getNumberOfLikes() + "   Dislikes: "
										+ temp.getNumberOfDislikes() + " Comments: " + comments;
								allOutfits[j] = outfitInfo;
							}
							JList<String> jlist = new JList<>(allOutfits);
							JOptionPane.showMessageDialog(null, jlist);
						}
						collectionToEdit = InformationMatcher.getCollection(currentUser, i);
						break;
					}
				}
	        }
	        if(e.getSource() == followersListPp) {
	        	String selectedItem = (String) collectionListPp.getSelectedValue();
	        	for (int i = 0; i < currentUser.getFollowerSize(); i++) {
					if(selectedItem.equals(InformationMatcher.getFollower(currentUser, i).getName())) {
						//UserView followerView = new UserView(currentUser,currentUser.getFollower(i));
					}
				}
	        }
	    }
	};
	
	private ActionListener actionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == addCollectionPp) {
				String collectionName = JOptionPane.showInputDialog(null,"Enter the name of the collection you want to add");
				if(collectionName != null) {
					Collection newCollection = new Collection(collectionName,Generator.generateCollectionID());
					currentUser.addCollection(newCollection);
				}
			}
			
			if(e.getSource() == addOutfitPp) {
				if(collectionToEdit == null) {
					JOptionPane.showMessageDialog(null, "Please double click on a collection for adding outfit operation.");
				}else {
					JPanel newPanel = new JPanel();
					JTextField name = new JTextField(5);
					JTextField gender = new JTextField(5);
					JTextField size = new JTextField(5);
					JTextField clothingType = new JTextField(5);
					JTextField color = new JTextField(5);
					JTextField occasion = new JTextField();
					
					newPanel.add(new JLabel("Name: "));
					newPanel.add(name);
					newPanel.add(Box.createHorizontalStrut(15)); 
					newPanel.add(new JLabel("Clothing Type: "));
					newPanel.add(clothingType);
					newPanel.add(Box.createHorizontalStrut(15)); 
					newPanel.add(new JLabel("Occasion"));
					newPanel.add(occasion);
					newPanel.add(new JLabel("Gender: "));
					newPanel.add(gender);
					newPanel.add(Box.createHorizontalStrut(15)); 
					newPanel.add(new JLabel("Size: "));
					newPanel.add(size);
					newPanel.add(Box.createHorizontalStrut(15)); 
					newPanel.add(new JLabel("Color"));
					newPanel.add(color);
					
					int result = JOptionPane.showConfirmDialog(null, newPanel,"Enter details for your outfit", JOptionPane.OK_CANCEL_OPTION);
					if(result == JOptionPane.OK_OPTION){
						Outfit newOutfit = new Outfit(Generator.generateOutfitID(),name.getText(),clothingType.getText(),occasion.getText(),gender.getText(),size.getText(),color.getText());
						collectionToEdit.addOutfit(newOutfit);
				    }
				}
					
			}
			if(e.getSource() == removeOutfitPp) {
				if(collectionToEdit == null) {
					JOptionPane.showMessageDialog(null, "Please double click on a collection for removing outfit operation.");
				}else {
					String options[] = new String[collectionToEdit.size()];
					for (int i = 0; i < options.length; i++) {
						options[i] = collectionToEdit.getOutfit(i).getName();
					}
					String selected = (String) JOptionPane.showInputDialog(panePp,"Choose outfit to remove","Remove outfit",JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
					for (int i = 0; i < options.length; i++) {
						if(selected == collectionToEdit.getOutfit(i).getName()) {
							collectionToEdit.removeOutfit(collectionToEdit.getOutfit(i));
							break;
						}
					}
					
				}
			}
			setValues();
			init();
			panePp.revalidate();
			panePp.repaint();
		}		
	};
	
	
	private void setValues() {
		
		DefaultListModel<String> l1 = new DefaultListModel<>();
		DefaultListModel<String> l2 = new DefaultListModel<>();
		DefaultListModel<String> l3 = new DefaultListModel<>();
		for (int i = 0; i < currentUser.getFollowerSize(); i++) {
			l1.addElement(InformationMatcher.getFollower(currentUser, i).getName());
		}
		
		for (int i = 0; i < currentUser.getFollowedSize(); i++) {
			l2.addElement(InformationMatcher.getFollowed(currentUser, i).getName());
		}
		
		for (int i = 0; i < currentUser.getCollectionSize(); i++) {
			l3.addElement(InformationMatcher.getCollection(currentUser, i).getName());
		}
		
		followersListPp = new JList<String>(l1);
		followingsListPp = new JList<String>(l2);
		collectionListPp = new JList<String>(l3);
        collectionListPp.addMouseListener(mouseListener);
        followersListPp.addMouseListener(mouseListener);
			
	}

	private void initComponents() {
		profilePage = new JPanel();
        panePp = new JPanel();
        userNamePp = new JLabel();
        numberFollowersPp = new JLabel();
        numberFollowersValPp = new JTextField();
        userNameValPp = new JTextField();
        numberFollowingsPp = new JLabel();
        numberFollowingsValPp = new JTextField();
        MostLikedOutfitPp = new JLabel();
        mostLikedOutfitValPp = new JTextField();
        addCollectionPp = new JButton();
        followersScrollPanePp = new JScrollPane();
        followersListPp = new JList<>();
        FollowingsScrollPanePp = new JScrollPane();
        followingsListPp = new JList<>();
        followersPp = new JLabel();
        followingsPp = new JLabel();
        collectionsScrollPanePp = new JScrollPane();
        collectionListPp = new JList<>();
        collectionsPp = new JLabel();
        addOutfitPp = new JButton();
        removeOutfitPp = new JButton();
        
        userNameValPp.setEditable(false);
        numberFollowersValPp.setEditable(false);
        numberFollowingsValPp.setEditable(false);
        mostLikedOutfitValPp.setEditable(false);
        addCollectionPp.addActionListener(actionListener);
        addOutfitPp.addActionListener(actionListener);
        removeOutfitPp.addActionListener(actionListener);
        panePp.add(followersListPp);
		panePp.add(followingsListPp);
		panePp.add(collectionListPp);
        
       
	}

	public JPanel getProfilePage() {
		return profilePage;
	}

	// Computer generated code from net beans
	
	private JPanel profilePage;    
    private JScrollPane FollowingsScrollPanePp;
    private JLabel MostLikedOutfitPp;
    private JButton addCollectionPp;
    private JButton addOutfitPp;
    private JList<String> collectionListPp;
    private JLabel collectionsPp;
    private JScrollPane collectionsScrollPanePp;
    private JList<String> followersListPp;
    private JLabel followersPp;
    private JScrollPane followersScrollPanePp;
    private JList<String> followingsListPp;
    private JLabel followingsPp;
    private JTextField mostLikedOutfitValPp;
    private JLabel numberFollowersPp;
    private JTextField numberFollowersValPp;
    private JLabel numberFollowingsPp;
    private JTextField numberFollowingsValPp;
    private JPanel panePp;
    private JButton removeOutfitPp;
    private JLabel userNamePp;
    private JTextField userNameValPp;
    
    
    private void init() {
    	panePp.setBackground(new java.awt.Color(153, 153, 255));

        userNamePp.setText("USERNAME: ");
        userNameValPp.setText(currentUser.getName());
        userNamePp.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        numberFollowersPp.setText("Number Of Followers: ");
        numberFollowersPp.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        numberFollowersValPp.setBackground(new java.awt.Color(153, 153, 255));
        numberFollowersValPp.setText(String.valueOf(currentUser.getFollowerSize()));
        numberFollowersValPp.setBorder(null);

        userNameValPp.setBackground(new java.awt.Color(153, 153, 255));
        userNameValPp.setBorder(null);

        numberFollowingsPp.setText("Number Of Followings: ");
        numberFollowingsValPp.setText(String.valueOf(currentUser.getFollowedSize()));
        numberFollowingsPp.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        numberFollowingsValPp.setBackground(new java.awt.Color(153, 153, 255));
        numberFollowingsValPp.setBorder(null);
       

        MostLikedOutfitPp.setText("Most Liked Outfit Of You: ");
        MostLikedOutfitPp.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        mostLikedOutfitValPp.setBackground(new java.awt.Color(153, 153, 255));
        int maxMostLiked = -1;
        String likedOutfitName = "";
        for (int i = 0; i < currentUser.getCollectionSize(); i++) {
			for (int j = 0; j < InformationMatcher.getCollection(currentUser, i).size(); j++) {
				if(InformationMatcher.getCollection(currentUser, i).getOutfit(j).getNumberOfLikes() > maxMostLiked) {
					maxMostLiked = InformationMatcher.getCollection(currentUser, i).getOutfit(j).getNumberOfLikes();
					likedOutfitName = InformationMatcher.getCollection(currentUser, i).getOutfit(j).getName();
				}
			}
		}
        mostLikedOutfitValPp.setText(likedOutfitName + " with " + maxMostLiked + " likes");
        mostLikedOutfitValPp.setBorder(null);

        addCollectionPp.setText("ADD COLLECTION   +");
       

       
        followersScrollPanePp.setViewportView(followersListPp);

     
        FollowingsScrollPanePp.setViewportView(followingsListPp);

        followersPp.setText("Followers");

        followingsPp.setText("Followings");

        
        collectionsScrollPanePp.setViewportView(collectionListPp);

        collectionsPp.setText("Collections");

        addOutfitPp.setText("ADD OUTFIT   +");

        removeOutfitPp.setText("REMOVE OUTFIT   -");

        GroupLayout panePpLayout = new GroupLayout(panePp);
        panePp.setLayout(panePpLayout);
        panePpLayout.setHorizontalGroup(
            panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panePpLayout.createSequentialGroup()
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(collectionsPp, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addComponent(followersPp, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(followingsPp, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(collectionsScrollPanePp, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(followersScrollPanePp, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(FollowingsScrollPanePp, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
            .addGroup(panePpLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(MostLikedOutfitPp)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(mostLikedOutfitValPp)
                        .addGap(141, 141, 141))
                    .addGroup(GroupLayout.Alignment.TRAILING, panePpLayout.createSequentialGroup()
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(panePpLayout.createSequentialGroup()
                                .addComponent(userNamePp, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(userNameValPp, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(panePpLayout.createSequentialGroup()
                                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addGroup(panePpLayout.createSequentialGroup()
                                        .addComponent(numberFollowingsPp, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(numberFollowingsValPp, GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                                    .addGroup(panePpLayout.createSequentialGroup()
                                        .addComponent(numberFollowersPp, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(numberFollowersValPp)))
                                .addGap(140, 140, 140)))
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                            .addComponent(addCollectionPp, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(addOutfitPp, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(removeOutfitPp, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        panePpLayout.setVerticalGroup(
            panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(panePpLayout.createSequentialGroup()
                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(userNamePp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
                            .addComponent(userNameValPp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(numberFollowersPp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
                            .addComponent(numberFollowersValPp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(addCollectionPp, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addOutfitPp, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeOutfitPp, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)))
                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(numberFollowingsPp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
                            .addComponent(numberFollowingsValPp, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(MostLikedOutfitPp, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
                            .addComponent(mostLikedOutfitValPp, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE))
                    .addGroup(GroupLayout.Alignment.TRAILING, panePpLayout.createSequentialGroup()
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                            .addComponent(followersPp)
                            .addComponent(followingsPp)
                            .addComponent(collectionsPp))
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(panePpLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(collectionsScrollPanePp)
                    .addComponent(FollowingsScrollPanePp, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                    .addComponent(followersScrollPanePp, GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
    	
    	GroupLayout profilePageLayout = new GroupLayout(profilePage);
        profilePage.setLayout(profilePageLayout);
        profilePageLayout.setHorizontalGroup(
            profilePageLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(panePp, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        profilePageLayout.setVerticalGroup(
            profilePageLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(panePp, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
		
	}
                                              

}
