package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import controller.InformationMatcher;
import models.User;

public class StatisticsPage {
	
	private List<User> allUsers;
	private int maxDislike = -1;
	private int maxLike = -1;
	private int mostFollowed = -1;
	private String userLiked;
	private String outfitLiked;
	private String userFollowed;
	private String userDisliked;
	private String outfitDisliked;
	
	public StatisticsPage(List<User> allUsers) {
		this.allUsers = allUsers;
		calculateStats();
		initComponents();
		init();
	}
	
	public void calculateStats() {
		
		for (int i = 0; i < allUsers.size(); i++) {
			for (int j = 0; j < allUsers.get(i).getCollectionSize(); j++) {
				for (int k = 0; k < InformationMatcher.getCollection(allUsers.get(i), j).size(); k++) {
					if(InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getNumberOfDislikes() > maxDislike) {
						maxDislike = InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getNumberOfDislikes();
						userDisliked = allUsers.get(i).getName();
						outfitDisliked = InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getName();
					}
					if(InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getNumberOfLikes() > maxLike) {
						maxLike = InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getNumberOfLikes();
						userLiked = allUsers.get(i).getName();
						outfitLiked = InformationMatcher.getCollection(allUsers.get(i), j).getOutfit(k).getName();
					}
				}
			}
			if(allUsers.get(i).getFollowerSize() > mostFollowed) {
				mostFollowed = allUsers.get(i).getFollowerSize();
				userFollowed = allUsers.get(i).getName();
			}
		}
		
	}

	private void initComponents() {
		statistics = new JPanel();
	    paneSt = new JPanel();
	    mostLikedOutfitSt = new JRadioButton();
	    mostDislikedSt = new JRadioButton();
	    mostFollowedSt = new JRadioButton();
	    userName = new JTextField();
		outfit = new JTextField();
		data = new JTextField();
		staticUserName = new JLabel("User: ");
		staticData = new JLabel("Data: ");
		staticOutfit = new JLabel("Outfit: ");
		radioButtons = new ButtonGroup();
	    radioButtons.add(mostDislikedSt);
	    radioButtons.add(mostFollowedSt);
	    radioButtons.add(mostLikedOutfitSt);
	    mostDislikedSt.addActionListener(actionListener);
	    mostFollowedSt.addActionListener(actionListener);
	    mostLikedOutfitSt.addActionListener(actionListener);
	    
	    staticUserName.setBounds(300, 100, 40, 30);
	    userName.setBounds(345,100,150,30);
	    staticData.setBounds(300,150,40,30);
	    data.setBounds(345,150,150,30);
	    staticOutfit.setBounds(300, 200, 40, 30);
	    outfit.setBounds(345,200,150,30);
	    userName.setVisible(true);
	    data.setVisible(true);
	    outfit.setVisible(true);
	    paneSt.add(userName);
	    paneSt.add(data);
	    paneSt.add(outfit);
	    paneSt.add(staticData);
	    paneSt.add(staticOutfit);
	    paneSt.add(staticUserName);
	    userName.setEditable(false);
	    data.setEditable(false);
	    outfit.setEditable(false);
	    
	}

	public JPanel getStatisticsPage() {
		return paneSt;
	}
   

	private ActionListener actionListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == mostDislikedSt) {
				userName.setText(userDisliked);
				outfit.setText(outfitDisliked);
				data.setText(String.valueOf(maxDislike));
				
			}
			if(e.getSource() == mostLikedOutfitSt) {
				userName.setText(userLiked);
				outfit.setText(outfitLiked);
				data.setText(String.valueOf(maxLike));
			}
			
			if(e.getSource() == mostFollowedSt) {
				userName.setText(userFollowed);
				outfit.setText("");
				data.setText(String.valueOf(mostFollowed));
			}
			paneSt.revalidate();
			paneSt.repaint();
		}
		
	};
	
	private JLabel staticUserName;
	private JLabel staticData;
	private JLabel staticOutfit;
	private JTextField data;
	private JTextField userName;
	private JTextField outfit;
	private ButtonGroup radioButtons;
	private JRadioButton mostDislikedSt;
    private JRadioButton mostFollowedSt;
    private JRadioButton mostLikedOutfitSt;
    private JPanel paneSt;
    private JPanel statistics;
    
    
    // Computer generated code from net beans
    
    private void init() {
    	paneSt.setBackground(new java.awt.Color(153, 153, 255));

        mostLikedOutfitSt.setBackground(new java.awt.Color(153, 153, 255));
        mostLikedOutfitSt.setText("MOST LIKED OUTFIT");

        mostDislikedSt.setBackground(new java.awt.Color(153, 153, 255));
        mostDislikedSt.setText("MOST DISLIKED OUTFIT");

        mostFollowedSt.setBackground(new java.awt.Color(153, 153, 255));
        mostFollowedSt.setText("MOST FOLLOWED USER");

        GroupLayout paneStLayout = new GroupLayout(paneSt);
        paneSt.setLayout(paneStLayout);
        paneStLayout.setHorizontalGroup(
            paneStLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(paneStLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(paneStLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(mostFollowedSt, GroupLayout.PREFERRED_SIZE, 168, GroupLayout.PREFERRED_SIZE)
                    .addGroup(paneStLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                        .addComponent(mostDislikedSt, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                        .addComponent(mostLikedOutfitSt, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(368, Short.MAX_VALUE))
        );
        paneStLayout.setVerticalGroup(
            paneStLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(paneStLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(mostLikedOutfitSt, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(mostDislikedSt, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(mostFollowedSt, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );

        GroupLayout statiscticsLayout = new GroupLayout(statistics);
        statistics.setLayout(statiscticsLayout);
        statiscticsLayout.setHorizontalGroup(
            statiscticsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 627, Short.MAX_VALUE)
            .addGroup(statiscticsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(statiscticsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(paneSt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        statiscticsLayout.setVerticalGroup(
            statiscticsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 409, Short.MAX_VALUE)
            .addGroup(statiscticsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(statiscticsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(paneSt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
		
	}
}
