package models;

import java.util.ArrayList;
import java.util.List;

public class Outfit {

	private int outfitID;
	private String name;
	private String clothingType;
	private String gender;
	private String size;
	private String color;
	private int numberOfLikes;
	private int numberOfDislikes;
	private List<Integer> commentIDs;
	
	
	public Outfit(int outfitID, String name, String clothingType, String gender, String size, String color) {
		this.outfitID = outfitID;
		this.name = name;
		this.clothingType = clothingType;
		this.gender = gender;
		this.size = size;
		this.color = color;
		commentIDs = new ArrayList<Integer>();
	}

	public boolean addComment(Integer commentID) {
		if(commentID == null) {
			return false;
		}else {
			commentIDs.add(commentID);
			return true;
		}
	}
	
	public int getComment(int i) {
		if(commentIDs.isEmpty()) {
			return -1;
		}
		int result = commentIDs.get(i);
		return result;
	}
	
	public int size() {
		int result = commentIDs.size();
		return result;
	}

	public int getOutfitID() {
		return outfitID;
	}


	public String getName() {
		return name;
	}


	public String getClothingType() {
		return clothingType;
	}


	public String getGender() {
		return gender;
	}


	public String getSize() {
		return size;
	}


	public String getColor() {
		return color;
	}


	public int getNumberOfLikes() {
		return numberOfLikes;
	}


	public int getNumberOfDislikes() {
		return numberOfDislikes;
	}
	
	
	
	
}
