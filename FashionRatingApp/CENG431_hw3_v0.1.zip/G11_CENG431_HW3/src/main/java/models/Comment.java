package models;

public class Comment {

	private int id;
	private String text;
	
	public Comment(int id, String text) {
		super();
		this.id = id;
		this.text = text;
	}

	public int getId() {
		return id;
	}

	public String getText() {
		return text;
	}	
	
}
