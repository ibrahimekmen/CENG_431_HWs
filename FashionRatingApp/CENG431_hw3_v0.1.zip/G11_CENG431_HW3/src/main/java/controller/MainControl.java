package controller;

import java.util.List;

import models.Collection;
import models.User;
import view.LoginView;
import view.MainView;

public class MainControl {

	private static User currentUser;
	private static List<User> users;
	private static List<Collection> collections;
	
	public static void mainFlow() {
		init();
		login();
	}

	private static void init() {
		users = FileIO.readUsers();
		collections = FileIO.readOutfits(users);
		
		for (User user: users) {
			for (int j = 0; j < user.getCollectionSize(); j++) {
				for (Collection collection : collections) {
					if(user.getCollectionID(j) == collection.getCollectionID()) {
						user.addCollection(collection);
					}
				}
			}
		}
	}
	
	private static void login() {
		LoginView lg = new LoginView();
		currentUser = lg.getCurrentUser();
	}
	
	private void initLogin() {
		MainView mv = new MainView(currentUser);
	}
	
	public static void main(String args[]){
		mainFlow();
	}
	
}
