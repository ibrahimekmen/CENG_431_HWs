package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import models.Collection;
import models.Outfit;
import models.User;

public class FileIO {
	
	public static void writeUsers(List<User> users) throws JsonGenerationException, JsonMappingException, IOException{
		XMLUsers xmlusers = new XMLUsers();
		for (User user : users) {
			xmlusers.addUser(user);
		}
		XmlMapper xmlMapper = new XmlMapper();
		xmlMapper.writeValue(new File("simple_bean.xml"), xmlusers);
	}
	
	public static List<User> readUsers() {
		List<User> users = new ArrayList<User>();
		try {
			File file = new File("simple_bean.xml");
		    XmlMapper xmlMapper = new XmlMapper();
		    String xml = inputStreamToString(new FileInputStream(file));
		    XMLUsers value= xmlMapper.readValue(xml, XMLUsers.class);
			
			for (User user : value.getUsers()) {
				System.out.println(user.getName() + " " + user.getPassword());
				users.add(user);
			}
			
		  	   
		}catch(Exception e) {
			e.printStackTrace();
		}
		return users;
	    
	}

	public static String inputStreamToString(InputStream is) throws IOException {
	    StringBuilder sb = new StringBuilder();
	    String line;
	    BufferedReader br = new BufferedReader(new InputStreamReader(is));
	    while ((line = br.readLine()) != null) {
	        sb.append(line);
	    }
	    br.close();
	    return sb.toString();
	}
	
	public static void writeOutfits(List<Collection> collections) throws IOException {
		Collection col = new Collection("Summer",12);
		col.addOutfit(new Outfit(1,"tshirt","yazl�k","M","XL","Red"));
		col.addOutfit(new Outfit(1,"tshirt","yazl�k","M","XL","Red"));
		col.addOutfit(new Outfit(1,"tshirt","yazl�k","M","XL","Red"));	
		col.addOutfit(new Outfit(1,"tshirt","yazl�k","M","XL","Red"));
		Gson allOutfits = new GsonBuilder().setPrettyPrinting().create();
		collections.add(col);
		collections.add(col);
		collections.add(col);
		collections.add(col);
		
		Writer writer = new FileWriter("Outfits.json");
		allOutfits.toJson(collections, writer);
		
		
		writer.close();
	}
	
	public static List<Collection> readOutfits(List<User> users)  {
		
		Gson gson = new Gson();
		List<Collection> collections = null;
		try {
			Reader reader = new FileReader("Outfits.json");
			collections = gson.fromJson(reader,  new TypeToken<List<Collection>>() {}.getType());
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return collections;
	}
	
	public static void main(String args[]) throws IOException {
		List<User> users = new ArrayList<User>();
		Collection col = new Collection("123",12);
		col.addOutfit(new Outfit(1,"asd","sada","asda","sda","sadas"));
		User u1 = new User("ibo","123");
		u1.addCollectionID(col.getCollectionID());
		User u = new User("Mehmet","43df");
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		u.addFollowed(u1);
		users.add(u);
		users.add(u);
		users.add(u);
		users.add(u);
		users.add(u);
		users.add(u);
		users.add(u);
		List<Collection> collections = new ArrayList<Collection>();
		writeUsers(users);
		readUsers();
		writeOutfits(collections);
		readOutfits(users);
	}
}
