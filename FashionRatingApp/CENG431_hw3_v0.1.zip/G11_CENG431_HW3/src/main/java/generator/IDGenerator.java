package generator;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class IDGenerator {
	
	private static List<Integer> generatedUserID = new LinkedList<Integer>();
	private static List<Integer> generatedOutfitID = new LinkedList<Integer>();
	
	public static void initUserID(List<Integer> generatedNumber) {
		for (int i = 0; i < generatedNumber.size(); i++) {
			generatedUserID.add(generatedNumber.get(i));	
		}
	}
	
	public static void initProductID(List<Integer> generatedNumber) {
		for (int i = 0; i < generatedNumber.size(); i++) {
			generatedOutfitID.add(generatedNumber.get(i));
		}
	}

	public static int generateUserID() {
		Random rand = new Random();
		int currentNumber;
		int maxLimit = 1000;
	
		currentNumber = rand.nextInt(maxLimit) + 1;
		if(generatedUserID.isEmpty()) {
			generatedUserID.add(currentNumber);
		}else {
			while(generatedUserID.contains(currentNumber)) {
				currentNumber = rand.nextInt(maxLimit) + 1;
			}
			generatedUserID.add(currentNumber);
		}
		return currentNumber;
	}
	
	public static int generateOutfitID() {
		Random rand = new Random();
		int currentNumber;
		int maxLimit = 1000;
	
		currentNumber = rand.nextInt(maxLimit) + 1;
		if(generatedOutfitID.isEmpty()) {
			generatedOutfitID.add(currentNumber);
		}else {
			while(generatedOutfitID.contains(currentNumber)) {
				currentNumber = rand.nextInt(maxLimit) + 1001;
			}
			generatedOutfitID.add(currentNumber);
		}
		return currentNumber;
	}
	
	
	//We took inspiration from this source
	//https://www.baeldung.com/java-random-string
	public static String generatePassword() {
		int leftLimit = 48; // numeral '0'
	    int rightLimit = 122; // letter 'z'
	    int targetStringLength = 4;
	    Random random = new Random();

	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();	   
	    return generatedString;
	}

}
