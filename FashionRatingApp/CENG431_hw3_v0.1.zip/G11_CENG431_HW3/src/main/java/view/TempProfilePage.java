package view;

import javax.swing.JPanel;

import models.User;

public class TempProfilePage {
	User currentUser;
	public TempProfilePage(User currentUser) {
		this.currentUser = currentUser;
		initComponents();
		init();
	}
	
	private void initComponents() {
		profilePage = new javax.swing.JPanel();
        panePp = new javax.swing.JPanel();
        userNamePp = new javax.swing.JLabel();
        numberFollowersPp = new javax.swing.JLabel();
        numberFollowersValPp = new javax.swing.JTextField();
        userNameValPp = new javax.swing.JTextField();
        numberFollowingsPp = new javax.swing.JLabel();
        numberFollowingsValPp = new javax.swing.JTextField();
        MostLikedOutfitPp = new javax.swing.JLabel();
        mostLikedOutfitValPp = new javax.swing.JTextField();
        addCollectionPp = new javax.swing.JButton();
        followersScrollPanePp = new javax.swing.JScrollPane();
        followersListPp = new javax.swing.JList<>();
        FollowingsScrollPanePp = new javax.swing.JScrollPane();
        followingsListPp = new javax.swing.JList<>();
        followersPp = new javax.swing.JLabel();
        followingsPp = new javax.swing.JLabel();
        collectionsScrollPanePp = new javax.swing.JScrollPane();
        collectionListPp = new javax.swing.JList<>();
        collectionsPp = new javax.swing.JLabel();
        addOutfitPp = new javax.swing.JButton();
        removeOutfitPp = new javax.swing.JButton();
		
	}

	public JPanel getProfilePage() {
		return profilePage;
	}

	private javax.swing.JPanel profilePage;    
    private javax.swing.JScrollPane FollowingsScrollPanePp;
    private javax.swing.JLabel MostLikedOutfitPp;
    private javax.swing.JButton addCollectionPp;
    private javax.swing.JButton addOutfitPp;
    private javax.swing.JList<String> collectionListPp;
    private javax.swing.JLabel collectionsPp;
    private javax.swing.JScrollPane collectionsScrollPanePp;
    private javax.swing.JList<String> followersListPp;
    private javax.swing.JLabel followersPp;
    private javax.swing.JScrollPane followersScrollPanePp;
    private javax.swing.JList<String> followingsListPp;
    private javax.swing.JLabel followingsPp;
    private javax.swing.JTextField mostLikedOutfitValPp;
    private javax.swing.JLabel numberFollowersPp;
    private javax.swing.JTextField numberFollowersValPp;
    private javax.swing.JLabel numberFollowingsPp;
    private javax.swing.JTextField numberFollowingsValPp;
    private javax.swing.JPanel panePp;
    private javax.swing.JButton removeOutfitPp;
    private javax.swing.JLabel userNamePp;
    private javax.swing.JTextField userNameValPp;
    
    private void init() {
    	panePp.setBackground(new java.awt.Color(153, 153, 255));

        userNamePp.setText("USERNAME: ");
        userNamePp.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        numberFollowersPp.setText("Number Of Followers: ");
        numberFollowersPp.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        numberFollowersValPp.setBackground(new java.awt.Color(153, 153, 255));
        numberFollowersValPp.setText("7 milyar milyon");
        numberFollowersValPp.setBorder(null);

        userNameValPp.setBackground(new java.awt.Color(153, 153, 255));
        userNameValPp.setText("431 Magdurlari");
        userNameValPp.setBorder(null);

        numberFollowingsPp.setText("Number Of Followings: ");
        numberFollowingsPp.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        numberFollowingsValPp.setBackground(new java.awt.Color(153, 153, 255));
        numberFollowingsValPp.setText("Bizi takip edenler zaten yanimizda");
        numberFollowingsValPp.setBorder(null);
        numberFollowingsValPp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numberFollowingsValPpActionPerformed(evt);
            }
        });

        MostLikedOutfitPp.setText("Most Liked Outfit Of You: ");
        MostLikedOutfitPp.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        mostLikedOutfitValPp.setBackground(new java.awt.Color(153, 153, 255));
        mostLikedOutfitValPp.setText("Yanlari Seritli Fosforlu Nike Ceket");
        mostLikedOutfitValPp.setBorder(null);

        addCollectionPp.setText("ADD COLLECTION   +");
        addCollectionPp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCollectionPpActionPerformed(evt);
            }
        });

        followersListPp.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        followersScrollPanePp.setViewportView(followersListPp);

        followingsListPp.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        FollowingsScrollPanePp.setViewportView(followingsListPp);

        followersPp.setText("Followers");

        followingsPp.setText("Followings");

        collectionListPp.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        collectionsScrollPanePp.setViewportView(collectionListPp);

        collectionsPp.setText("Collections");

        addOutfitPp.setText("ADD OUTFIT   +");

        removeOutfitPp.setText("REMOVE OUTFIT   -");

        javax.swing.GroupLayout panePpLayout = new javax.swing.GroupLayout(panePp);
        panePp.setLayout(panePpLayout);
        panePpLayout.setHorizontalGroup(
            panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panePpLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(collectionsPp, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addComponent(followersPp, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(followingsPp, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(collectionsScrollPanePp, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(followersScrollPanePp, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(FollowingsScrollPanePp, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
            .addGroup(panePpLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addComponent(MostLikedOutfitPp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(mostLikedOutfitValPp)
                        .addGap(141, 141, 141))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panePpLayout.createSequentialGroup()
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panePpLayout.createSequentialGroup()
                                .addComponent(userNamePp, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(userNameValPp, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(panePpLayout.createSequentialGroup()
                                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panePpLayout.createSequentialGroup()
                                        .addComponent(numberFollowingsPp, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(numberFollowingsValPp, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                                    .addGroup(panePpLayout.createSequentialGroup()
                                        .addComponent(numberFollowersPp, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(numberFollowersValPp)))
                                .addGap(140, 140, 140)))
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(addCollectionPp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(addOutfitPp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(removeOutfitPp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        panePpLayout.setVerticalGroup(
            panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panePpLayout.createSequentialGroup()
                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(userNamePp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userNameValPp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(numberFollowersPp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numberFollowersValPp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(addCollectionPp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addOutfitPp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(removeOutfitPp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panePpLayout.createSequentialGroup()
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(numberFollowingsPp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numberFollowingsValPp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(MostLikedOutfitPp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mostLikedOutfitValPp, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panePpLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(followersPp)
                            .addComponent(followingsPp)
                            .addComponent(collectionsPp))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(panePpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(collectionsScrollPanePp)
                    .addComponent(FollowingsScrollPanePp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                    .addComponent(followersScrollPanePp, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
    	
    	javax.swing.GroupLayout profilePageLayout = new javax.swing.GroupLayout(profilePage);
        profilePage.setLayout(profilePageLayout);
        profilePageLayout.setHorizontalGroup(
            profilePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panePp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        profilePageLayout.setVerticalGroup(
            profilePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panePp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
		
	}
    
    private void numberFollowingsValPpActionPerformed(java.awt.event.ActionEvent evt) {                                                      
        // TODO add your handling code here:
    }                                                     

    private void addCollectionPpActionPerformed(java.awt.event.ActionEvent evt) {                                                
        // TODO add your handling code here:
    }                                               

}
