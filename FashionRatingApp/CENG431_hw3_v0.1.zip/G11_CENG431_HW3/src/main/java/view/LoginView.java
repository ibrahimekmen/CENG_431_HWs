package view;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.Timer;

import models.User;

@SuppressWarnings("serial")
public class LoginView extends JFrame implements ActionListener{
	
	private User currentUser;
	private Container container = getContentPane();
	private JButton loginButton =new JButton("Log In");//creating instance of JButton  
	private JTextArea userName = new JTextArea();
	private JPasswordField password = new JPasswordField();
	private JTextField userText = new JTextField("User name:");
	private JCheckBox showPassword = new JCheckBox();
	private JTextField passwordText = new JTextField("Password:");
	private Icon icon = new ImageIcon("image1.png");
	private JButton showPasswordIcon = new JButton(icon);	
	
	
	public LoginView(){  
		setLayoutManger();
		setComponents();
		addToContainer();
		addActionEvent();
		init();
	}	
	
	public void init() {
		this.setTitle("Fash10");
		this.setVisible(true);
		this.setBounds(400,200,400,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
	}


	public void setLayoutManger() {
		container.setLayout(null);
	}
	
	public void setComponents() {
		loginButton.setBounds(150,200,100, 40);
		userName.setBounds(100, 50, 200, 20);
		userName.setBorder(BorderFactory.createLineBorder(Color.gray));
		password.setBounds(100, 80,200,20);
		showPassword.setBounds(310,75,30,30);
		showPasswordIcon.setBounds(340,75,46,27);
		showPasswordIcon.setEnabled(false);
		userText.setBounds(30,50,70,20);
		userText.setEditable(false);
		userText.setBorder(null);
		passwordText.setBounds(30,80,70,20);
		passwordText.setEditable(false);
		passwordText.setBorder(null);
	}

	public void addToContainer() {
		container.add(password);
		container.add(passwordText);
		container.add(userText);
		container.add(userName);
		container.add(loginButton);
		container.add(showPassword);
		container.add(showPasswordIcon);
		container.setSize(600,600); 
		container.setLayout(null);
		container.setVisible(true);
	}
	
	public void addActionEvent() {
		loginButton.addActionListener(this);
		showPassword.addActionListener(this);
	}
	

	public User getCurrentUser() {
		return currentUser;
	}
	
	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == loginButton) {
			String userInput;
			String pswrdInput;
			userInput = userName.getText();
			pswrdInput = password.getText();
			if(userInput.equalsIgnoreCase("Caner") && pswrdInput.equalsIgnoreCase("1234")) {
				JOptionPane optionPane = new JOptionPane("Login Successful",JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = optionPane.createDialog(null,"Title");
				dialog.setModal(false);
				dialog.setVisible(true);
				new Timer(2000, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.setVisible(false);
                    }
                }).start();
				container.setVisible(false);
				dispose();
				currentUser = new User("Caner" , "1234");
				MainView mv = new MainView(currentUser);
			}else
				JOptionPane.showMessageDialog(this, "Invalid Username or Password");
		}
		if(e.getSource() == showPassword) {
			if(showPassword.isSelected()) {
				password.setEchoChar((char) 0);
			}else
				password.setEchoChar('*');
		}
		
	}
}
