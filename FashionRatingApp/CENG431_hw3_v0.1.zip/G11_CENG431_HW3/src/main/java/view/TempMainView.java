package view;

import java.awt.EventQueue;

import javax.swing.*;

import models.User;

import java.awt.Color;

public class TempMainView extends JFrame {
	
	JTabbedPane jTabbedPane;
	User currentUser = new User("Caner","12");
	
	
	public TempMainView() {
		initComponents();
	}

	private void initComponents() {
		TempHomePage homePage = new TempHomePage(currentUser);
		TempDiscoverPage discoverPage = new TempDiscoverPage(currentUser);
		TempStatistics statisticsPage = new TempStatistics(currentUser);
		TempProfilePage profilePage = new TempProfilePage(currentUser);
		jTabbedPane = new JTabbedPane();
		jTabbedPane.setBackground(new Color(255, 0, 0));
		jTabbedPane.addTab("Home Page", homePage.getHomePage());
		jTabbedPane.addTab("Discover", discoverPage.getDiscoverPage());
		jTabbedPane.addTab("Statistics", statisticsPage.getStatisticsPage());
		jTabbedPane.addTab("Profile Page", profilePage.getProfilePage());
		this.setResizable(false);
		 GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane, GroupLayout.PREFERRED_SIZE, 632, GroupLayout.PREFERRED_SIZE)
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addComponent(jTabbedPane)
	        );
	    pack();
	}
	
	public static void main(String args[]) {
		EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
	}
}
