package view;

import javax.swing.JFrame;

public class test {

	public static void main(String[] args) {  
			LoginView lg = new LoginView();
		}  
}
