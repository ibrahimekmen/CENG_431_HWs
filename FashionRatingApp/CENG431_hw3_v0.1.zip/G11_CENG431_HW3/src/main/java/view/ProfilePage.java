package view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import models.User;

public class ProfilePage extends JPanel implements ActionListener{

	
	private User currentUser;
	
	private JLabel userName;
	private JButton myCollections;
	private JButton addCollection;
	private JButton editCollection;
	private JButton followed;
	private JButton followers;
	
	
	
	public ProfilePage(User u) {
		currentUser = u;
		setLayoutManager();
		setComponents();
		addToContainer();
		init();
	}
	
	private void init() {
		this.setVisible(true);
		this.setSize(900,800);
		
	}

	private void addActionEvent() {
		
	}
	
	private void addToContainer() {
		
	}

	private void setComponents() {
		userName = new JLabel(currentUser.getName());
		followers = new JButton("Followers");
		followed = new JButton("Followed");
		myCollections = new JButton("My Collections");
		addCollection = new JButton("Add Collection");
		editCollection = new JButton("Edit Collection");
		
		userName.setBounds(30,20,100,30);
		followers.setBounds(140,20,100,30);
		followed.setBounds(250,20,100,30);
		
		this.add(userName);
		this.add(followers);
		this.add(followed);
	}

	private void setLayoutManager() {
		this.setLayout(null);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
