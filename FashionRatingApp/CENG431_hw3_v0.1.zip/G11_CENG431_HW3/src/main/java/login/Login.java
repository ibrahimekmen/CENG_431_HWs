package login;
import java.util.List;
import java.util.Scanner;
import models.User;


public class Login {

	public static User login(List<User> users) {
		Scanner sc = new Scanner(System.in);
		String name;
		String password;
		boolean correctEmail = false;
		boolean correctPassword = false;
		
		while (true) {
			System.out.println("Enter your user name: ");
			name = sc.nextLine();
			System.out.println("Enter your password: ");
			password = sc.nextLine();
			for (int i = 0; i < users.size(); i++) {
				correctEmail = false;
				correctPassword = false;
				if (users.get(i).getName().equals(name)) {
					correctEmail = true;
					if (users.get(i).getPassword().equals(password)) {
						correctPassword = true;
						System.out.println("Successfully logged in");
						return users.get(i);
					}
				}

			}
			if (!correctEmail) {
				System.out.println("We couldn't find an email matching: " + name);
			} else if (correctEmail && !correctPassword) {
				System.out.println("Your password is incorrect!");
			} 
		}
		
		
	}
	
}
